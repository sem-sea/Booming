import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Button } from '@/components/ui/button';
import { ArrowRight, Check, Target, Zap, Globe, Package, TrendingUp, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';

const Pakketten = () => {
  const { language } = useLanguage();
  
  const content = {
    nl: {
      title: 'Pakketten',
      subtitle: 'Kies de perfecte marketingoplossing voor jouw bedrijf',
      description: 'Van een snelle start tot volledig uitbestede marketing. We hebben voor elke ondernemer de juiste oplossing.',
      quickPackagesTitle: 'Snelle Pakketten',
      googleAdsTitle: 'Google Ads Pakketten',
      packages: [
        {
          id: 1,
          name: 'Social Media Funnel Pack',
          price: '€600',
          description: 'Een profiel dat niet informeert, maar converteert.',
          icon: Target,
          features: [
            'Wervende profieltekst',
            'Lead magnet of intakebutton in je profiel',
            '3 DM-scripts om gesprekken te starten'
          ],
          image: '/lovable-uploads/8cd60c1b-0323-4872-bf95-8063f71492ee.png'
        },
        {
          id: 2,
          name: 'Lead Magnet Landingspagina',
          price: '€950',
          description: 'Een pagina die je magnet laat werken en leads oplevert.',
          icon: Zap,
          features: [
            'Landingspagina (copy + structuur)',
            'Intakeformulier of download',
            'Volledig geoptimaliseerd voor conversie'
          ],
          image: '/lovable-uploads/12f5314d-f5e2-4038-8fde-5c5ab0bef4b8.png'
        },
        {
          id: 3,
          name: 'One Page Funnel',
          price: '€1.200',
          description: 'Alles op één pagina om direct klanten te krijgen.',
          icon: Globe,
          features: [
            'Hero, pitch, pijnpunt + belofte',
            'Magnet of intakebutton',
            'Koppeling met e-mail/CRM'
          ],
          image: '/lovable-uploads/3a5b5085-513f-4587-8e42-b13eee3cde80.png'
        },
        {
          id: 4,
          name: 'Website Light',
          price: '€99',
          description: 'Binnen 1 week live met een professionele website.',
          icon: Globe,
          features: [
            'Tot 5 pagina\'s',
            'Conversiegerichte opbouw',
            'Werkend contactformulier',
            'Hulp bij domein + e-mail',
            '14 dagen gratis support'
          ],
          note: 'Optionele uitbreidingen zoals SEO, teksten, webshop, boekingssysteem, etc. beschikbaar.',
          image: '/lovable-uploads/4aa69807-6024-4c17-be50-0a6bd7f3cfb9.png'
        }
      ],
      googleAdsPackages: [
        {
          id: 1,
          name: 'Google Ads Kickstart',
          price: '€450 setup + €250/maand',
          description: 'Perfect om snel te starten met voorspelbare resultaten.',
          icon: Target,
          features: [
            'Keyword onderzoek & selectie',
            'Advertentie teksten schrijven',
            'Tracking & conversie setup',
            'Google Ads account inrichting',
            'Maandelijkse optimalisatie (1,5-2,5u)',
            'Maandrapportage via e-mail'
          ],
          note: 'Live binnen 7 dagen',
          excludeNote: '*Exclusief advertentiebudget',
          image: '/lovable-uploads/57623f4c-b048-4084-ab9b-a2c896628472.png'
        },
        {
          id: 2,
          name: 'Google Ads Groei Pack',
          price: '€600/maand',
          description: 'Voor bedrijven die serieus willen groeien.',
          icon: TrendingUp,
          features: [
            'Alles uit Kickstart pakket',
            'Wekelijkse optimalisatie',
            'A/B testing van advertenties',
            'Landing page feedback',
            'Conversie dashboard',
            'Call tracking setup',
            'Uitgebreide rapportage',
            'Prioriteit support'
          ],
          note: 'Ideaal voor ad budget €500-€2.000/maand',
          excludeNote: '*Exclusief advertentiebudget',
          image: '/lovable-uploads/cfaeade8-1f53-4306-b087-eb79af690f67.png'
        }
      ],
      bundle: {
        name: 'Klare Start Pack',
        price: 'vanaf €2.400',
        description: 'Snel van 0 naar professioneel online aanwezig.',
        icon: Package,
        features: [
          'Social Media Funnel Pack',
          'Lead magnet landingspagina',
          'Intakepagina of One Page Funnel',
          'Alles afgestemd op je doelgroep en conversiedoel'
        ],
        note: 'Klaar binnen 5 werkdagen',
        image: '/lovable-uploads/0970519e-7452-40f9-830d-5c8bca26f492.png'
      },
      cta: {
        title: 'Niet zeker welk pakket bij je past?',
        subtitle: 'Plan een gratis intakegesprek en we helpen je de juiste keuze te maken.',
        button: 'Plan gratis intake'
      }
    },
    en: {
      title: 'Packages',
      subtitle: 'Choose the perfect marketing solution for your business',
      description: 'From a quick start to fully outsourced marketing. We have the right solution for every entrepreneur.',
      quickPackagesTitle: 'Quick Packages',
      googleAdsTitle: 'Google Ads Packages',
      packages: [
        {
          id: 1,
          name: 'Social Media Funnel Pack',
          price: '€600',
          description: 'A profile that doesn\'t inform, but converts.',
          icon: Target,
          features: [
            'Compelling profile text',
            'Lead magnet or intake button in your profile',
            '3 DM scripts to start conversations'
          ],
          image: '/lovable-uploads/8cd60c1b-0323-4872-bf95-8063f71492ee.png'
        },
        {
          id: 2,
          name: 'Lead Magnet Landing Page',
          price: '€950',
          description: 'A page that makes your magnet work and generates leads.',
          icon: Zap,
          features: [
            'Landing page (copy + structure)',
            'Intake form or download',
            'Fully optimized for conversion'
          ],
          image: '/lovable-uploads/12f5314d-f5e2-4038-8fde-5c5ab0bef4b8.png'
        },
        {
          id: 3,
          name: 'One Page Funnel',
          price: '€1,200',
          description: 'Everything on one page to get customers directly.',
          icon: Globe,
          features: [
            'Hero, pitch, pain point + promise',
            'Magnet or intake button',
            'Connection with email/CRM'
          ],
          image: '/lovable-uploads/3a5b5085-513f-4587-8e42-b13eee3cde80.png'
        },
        {
          id: 4,
          name: 'Website Light',
          price: '€99',
          description: 'Live within 1 week with a professional website.',
          icon: Globe,
          features: [
            'Up to 5 pages',
            'Conversion-focused structure',
            'Working contact form',
            'Help with domain + email',
            '14 days free support'
          ],
          note: 'Optional extensions like SEO, copywriting, webshop, booking system, etc. available.',
          image: '/lovable-uploads/4aa69807-6024-4c17-be50-0a6bd7f3cfb9.png'
        }
      ],
      googleAdsPackages: [
        {
          id: 1,
          name: 'Google Ads Kickstart',
          price: '€450 setup + €250/month',
          description: 'Perfect to start quickly with predictable results.',
          icon: Target,
          features: [
            'Keyword research & selection',
            'Ad copywriting',
            'Tracking & conversion setup',
            'Google Ads account setup',
            'Monthly optimization (1.5-2.5h)',
            'Monthly email reporting'
          ],
          note: 'Live within 7 days',
          excludeNote: '*Excluding advertising budget',
          image: '/lovable-uploads/57623f4c-b048-4084-ab9b-a2c896628472.png'
        },
        {
          id: 2,
          name: 'Google Ads Growth Pack',
          price: '€600/month',
          description: 'For businesses that want to grow seriously.',
          icon: TrendingUp,
          features: [
            'Everything from Kickstart package',
            'Weekly optimization',
            'A/B testing of ads',
            'Landing page feedback',
            'Conversion dashboard',
            'Call tracking setup',
            'Extensive reporting',
            'Priority support'
          ],
          note: 'Ideal for ad budget €500-€2,000/month',
          excludeNote: '*Excluding advertising budget',
          image: '/lovable-uploads/cfaeade8-1f53-4306-b087-eb79af690f67.png'
        }
      ],
      bundle: {
        name: 'Ready Start Pack',
        price: 'from €2,400',
        description: 'Quickly from 0 to professionally online present.',
        icon: Package,
        features: [
          'Social Media Funnel Pack',
          'Lead magnet landing page',
          'Intake page or One Page Funnel',
          'Everything tailored to your target audience and conversion goal'
        ],
        note: 'Ready within 5 working days',
        image: '/lovable-uploads/0970519e-7452-40f9-830d-5c8bca26f492.png'
      },
      cta: {
        title: 'Not sure which package suits you?',
        subtitle: 'Schedule a free intake call and we\'ll help you make the right choice.',
        button: 'Schedule free intake'
      }
    }
  };
  
  const { title, subtitle, description, quickPackagesTitle, googleAdsTitle, packages, googleAdsPackages, bundle, cta } = content[language];
  
  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-28">
        {/* Hero Section */}
        <section className="py-12 md:py-16 bg-gray-light">
          <div className="container mx-auto text-center">
            <h1 className="mb-4">{title}</h1>
            <h2 className="text-xl md:text-2xl font-bold mb-4 text-primary-blue">{subtitle}</h2>
            <p className="max-w-2xl mx-auto text-gray-dark">{description}</p>
          </div>
        </section>
        
        {/* Quick Packages Grid */}
        <section className="py-16 bg-white">
          <div className="container mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-center text-primary-blue">{quickPackagesTitle}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              {packages.map((pkg) => {
                const Icon = pkg.icon;
                return (
                  <div key={pkg.id} className="bg-gray-light rounded-2xl p-8 hover:shadow-lg transition-shadow duration-300">
                    <div className="mb-6">
                      <img 
                        src={pkg.image} 
                        alt={pkg.name} 
                        className="w-full h-48 object-cover rounded-lg mb-4"
                      />
                      <Icon className="h-12 w-12 text-accent-orange mb-4" />
                    </div>
                    <h3 className="text-2xl font-bold mb-3 text-primary-blue">{pkg.name}</h3>
                    <p className="text-gray-dark mb-4">{pkg.description}</p>
                    <div className="text-3xl font-bold text-primary-blue mb-6">{pkg.price}</div>
                    
                    <div className="mb-6">
                      <h4 className="font-bold mb-3">{language === 'nl' ? 'Inclusief:' : 'Includes:'}</h4>
                      <ul className="space-y-2">
                        {pkg.features.map((feature, index) => (
                          <li key={index} className="flex items-start">
                            <Check className="h-5 w-5 text-accent-orange mr-2 mt-0.5 flex-shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    {pkg.note && (
                      <p className="text-sm text-gray-dark mb-6 italic">{pkg.note}</p>
                    )}
                    
                    <Button asChild className="w-full bg-primary-blue hover:bg-primary-blue/90 text-white">
                      <Link to="/contact">
                        {language === 'nl' ? 'Bestellen' : 'Order'} <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Google Ads Packages */}
        <section className="py-16 bg-gray-light">
          <div className="container mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-center text-primary-blue">{googleAdsTitle}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {googleAdsPackages.map((pkg) => {
                const Icon = pkg.icon;
                return (
                  <div key={pkg.id} className="bg-white rounded-2xl p-8 hover:shadow-lg transition-shadow duration-300">
                    <div className="mb-6">
                      <img 
                        src={pkg.image} 
                        alt={pkg.name} 
                        className="w-full h-48 object-cover rounded-lg mb-4"
                      />
                      <Icon className="h-12 w-12 text-accent-orange mb-4" />
                    </div>
                    <h3 className="text-2xl font-bold mb-3 text-primary-blue">{pkg.name}</h3>
                    <p className="text-gray-dark mb-4">{pkg.description}</p>
                    <div className="text-2xl font-bold text-primary-blue mb-2">{pkg.price}</div>
                    <div className="text-sm text-red-600 font-medium mb-6">{pkg.excludeNote}</div>
                    
                    <div className="mb-6">
                      <h4 className="font-bold mb-3">{language === 'nl' ? 'Inclusief:' : 'Includes:'}</h4>
                      <ul className="space-y-2">
                        {pkg.features.map((feature, index) => (
                          <li key={index} className="flex items-start">
                            <Check className="h-5 w-5 text-accent-orange mr-2 mt-0.5 flex-shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    {pkg.note && (
                      <p className="text-sm text-gray-dark mb-6 italic">{pkg.note}</p>
                    )}
                    
                    <Button asChild className="w-full bg-primary-blue hover:bg-primary-blue/90 text-white">
                      <Link to="/contact">
                        {language === 'nl' ? 'Bestellen' : 'Order'} <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
        
        {/* Bundle Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto">
            <div className="bg-primary-blue text-white rounded-2xl p-8 text-center">
              <div className="mb-6">
                <img 
                  src={bundle.image} 
                  alt={bundle.name} 
                  className="w-full h-64 object-cover rounded-lg mb-4 mx-auto max-w-md"
                />
                <Package className="h-16 w-16 text-accent-orange mx-auto mb-4" />
              </div>
              <h3 className="text-3xl font-bold mb-3">{bundle.name}</h3>
              <p className="text-xl mb-4">{bundle.description}</p>
              <div className="text-4xl font-bold text-accent-orange mb-6">{bundle.price}</div>
              
              <div className="mb-6 max-w-md mx-auto">
                <h4 className="font-bold mb-3">{language === 'nl' ? 'Inclusief:' : 'Includes:'}</h4>
                <ul className="space-y-2 text-left">
                  {bundle.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <Check className="h-5 w-5 text-accent-orange mr-2 mt-0.5 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <p className="text-accent-orange font-bold mb-6">{bundle.note}</p>
              
              <Button asChild className="bg-accent-orange hover:bg-accent-orange/90 text-white">
                <Link to="/contact">
                  {language === 'nl' ? 'Bestellen' : 'Order'} <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-16 bg-gray-light">
          <div className="container mx-auto text-center">
            <h2 className="mb-4">{cta.title}</h2>
            <p className="text-xl text-gray-dark mb-8 max-w-2xl mx-auto">{cta.subtitle}</p>
            <Button asChild className="bg-primary-blue hover:bg-primary-blue/90 text-white">
              <Link to="/contact">
                {cta.button} <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Pakketten;
