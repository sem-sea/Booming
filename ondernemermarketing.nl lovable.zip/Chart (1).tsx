
import React from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  TooltipProps
} from 'recharts';

export interface ChartProps {
  type: 'line' | 'bar' | 'area';
  config: LineConfig | BarConfig | AreaConfig;
  height?: number | string;
}

export interface LineConfig {
  data: any[];
  xAxisKey: string;
  lines: { key: string; color: string }[];
  valueFormatter?: (value: number) => string;
}

export interface BarConfig {
  data: any[];
  xAxisKey: string;
  yAxisKey: string;
  valueFormatter?: (value: number) => string;
  colors?: string[];
}

export interface AreaConfig {
  data: any[];
  categories: string[];
  index: string;
  colors?: string[];
  valueFormatter?: (value: number) => string;
}

export const Chart: React.FC<ChartProps> = ({ type, config, height = 300 }) => {
  switch (type) {
    case 'line':
      return renderLineChart(config as LineConfig, height);
    case 'bar':
      return renderBarChart(config as BarConfig, height);
    case 'area':
      return renderAreaChart(config as AreaConfig, height);
    default:
      return null;
  }
};

const renderLineChart = (config: LineConfig, height: number | string) => {
  const { data, xAxisKey, lines, valueFormatter } = config;
  
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey={xAxisKey} />
        <YAxis tickFormatter={valueFormatter} />
        <Tooltip 
          content={({ active, payload, label }) => {
            if (active && payload && payload.length) {
              return (
                <div className="bg-background border border-border p-2 shadow-md rounded-md">
                  <p className="font-medium">{label}</p>
                  {payload.map((entry, index) => (
                    <p key={`item-${index}`} style={{ color: entry.color }}>
                      {entry.name}: {valueFormatter ? valueFormatter(Number(entry.value)) : entry.value}
                    </p>
                  ))}
                </div>
              );
            }
            return null;
          }}
        />
        <Legend />
        {lines.map((line, index) => (
          <Line
            key={index}
            type="monotone"
            dataKey={line.key}
            stroke={line.color}
            activeDot={{ r: 8 }}
          />
        ))}
      </LineChart>
    </ResponsiveContainer>
  );
};

const renderBarChart = (config: BarConfig, height: number | string) => {
  const { data, xAxisKey, yAxisKey, valueFormatter, colors = ['#8884d8'] } = config;
  
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey={xAxisKey} />
        <YAxis tickFormatter={valueFormatter} />
        <Tooltip 
          content={({ active, payload, label }) => {
            if (active && payload && payload.length) {
              return (
                <div className="bg-background border border-border p-2 shadow-md rounded-md">
                  <p className="font-medium">{label}</p>
                  {payload.map((entry, index) => (
                    <p key={`item-${index}`} style={{ color: entry.color }}>
                      {entry.name}: {valueFormatter ? valueFormatter(Number(entry.value)) : entry.value}
                    </p>
                  ))}
                </div>
              );
            }
            return null;
          }}
        />
        <Legend />
        <Bar dataKey={yAxisKey} fill={colors[0]}>
          {data.map((_, index) => (
            <Bar 
              key={`cell-${index}`}
              dataKey={yAxisKey}
              fill={colors[index % colors.length]} 
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
};

const renderAreaChart = (config: AreaConfig, height: number | string) => {
  const { data, categories, index, colors = ['#8884d8', '#82ca9d'], valueFormatter } = config;
  
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey={index} />
        <YAxis tickFormatter={valueFormatter} />
        <Tooltip 
          content={({ active, payload, label }) => {
            if (active && payload && payload.length) {
              return (
                <div className="bg-background border border-border p-2 shadow-md rounded-md">
                  <p className="font-medium">{label}</p>
                  {payload.map((entry, index) => (
                    <p key={`item-${index}`} style={{ color: entry.color }}>
                      {entry.name}: {valueFormatter ? valueFormatter(Number(entry.value)) : entry.value}
                    </p>
                  ))}
                </div>
              );
            }
            return null;
          }}
        />
        <Legend />
        {categories.map((category, idx) => (
          <Area
            key={category}
            type="monotone"
            dataKey={category}
            stackId="1"
            stroke={colors[idx % colors.length]}
            fill={colors[idx % colors.length]}
          />
        ))}
      </AreaChart>
    </ResponsiveContainer>
  );
};

export default Chart;
