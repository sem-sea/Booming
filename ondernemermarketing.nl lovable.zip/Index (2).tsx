
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import Header from '../components/Header';
import Hero from '../components/Hero';
import Services from '../components/Services';
import CompareServicesCTA from '../components/CompareServicesCTA';
import LeadMagnets from '../components/LeadMagnets';
import Testimonials from '../components/Testimonials';
import CTASection from '../components/CTASection';
import Footer from '../components/Footer';
import CookieConsent from '../components/CookieConsent';
import CallButton from '../components/CallButton';
import SEO from '../components/SEO';
import { ArrowUp } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';

const Index = () => {
  const { language } = useLanguage();
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Ondernemermarketing.nl",
    "url": "https://www.ondernemermarketing.nl",
    "logo": "https://www.ondernemermarketing.nl/lovable-uploads/bf6accc4-838f-4f65-9b6a-1ef2f9fd9e46.png",
    "description": "Marketing bureau voor ondernemers. Wij regelen je funnels, email marketing en automatisering zodat jij meer klanten krijgt.",
    "address": {
      "@type": "PostalAddress",
      "addressCountry": "NL"
    },
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+31-6-1301-3266",
      "contactType": "Customer Service",
      "availableLanguage": ["Dutch", "English"]
    },
    "sameAs": [
      "https://www.linkedin.com/company/ondernemermarketing"
    ]
  };

  return (
    <div className="min-h-screen">
      <SEO 
        title="Ondernemermarketing.nl – Marketing zonder gedoe"
        description="Je wilt klanten. Niet leren marketen. Ondernemermarketing.nl regelt je funnels, e-mails en intakeflow – zodat jij kunt ondernemen."
        url="https://www.ondernemermarketing.nl"
        structuredData={organizationSchema}
      />
      <Header />
      <Hero />
      <Services />
      <CompareServicesCTA />
      <LeadMagnets />
      <Testimonials language={language} />
      <CTASection />
      <Footer />

      {/* Sticky CTA for mobile */}
      <div className="sticky-cta">
        <p className="text-primary-blue font-medium">
          {language === 'nl' ? 'Klaar voor meer klanten?' : 'Ready for more customers?'}
        </p>
        <Button asChild size="sm" className="primary-cta">
          <Link to="/contact">
            {language === 'nl' ? 'Gratis intake' : 'Free intake'}
          </Link>
        </Button>
      </div>

      {/* Call Button */}
      <CallButton />

      {/* Scroll to top button */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-20 right-4 z-50 p-2 rounded-full bg-primary-blue text-white shadow-lg hover:bg-primary-teal transition-colors"
          aria-label="Scroll to top"
        >
          <ArrowUp size={20} />
        </button>
      )}

      {/* Cookie Consent */}
      <CookieConsent />
    </div>
  );
};

export default Index;
