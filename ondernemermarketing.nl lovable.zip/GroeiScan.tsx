import React, { useState, useRef } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { Download, Scan, ChartLine, ArrowRight } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { useLanguage } from '@/contexts/LanguageContext';

// Form schema for user information
const userInfoSchema = z.object({
  name: z.string().min(1, "Naam is verplicht"),
  email: z.string().email("Ongeldig e-mailadres"),
  company: z.string().min(1, "Bedrijfsnaam is verplicht"),
  website: z.string().url("Ongeldige URL").or(z.literal("")),
  industry: z.string().min(1, "Industrie is verplicht"),
});

type UserInfo = z.infer<typeof userInfoSchema>;

// Schema for scan questions
const scanQuestionsSchema = z.object({
  q1: z.enum(["1", "2", "3", "4", "5"]),
  q2: z.enum(["1", "2", "3", "4", "5"]),
  q3: z.enum(["1", "2", "3", "4", "5"]),
  q4: z.enum(["1", "2", "3", "4", "5"]),
  q5: z.enum(["1", "2", "3", "4", "5"]),
  q6: z.enum(["1", "2", "3", "4", "5"]),
  q7: z.enum(["1", "2", "3", "4", "5"]),
  goals: z.string(),
});

type ScanQuestions = z.infer<typeof scanQuestionsSchema>;

const GroeiScan = () => {
  const { toast } = useToast();
  const { language } = useLanguage();
  const [currentStep, setCurrentStep] = useState(0);
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const [results, setResults] = useState<any>(null);
  const printRef = useRef<HTMLDivElement>(null);
  
  const userInfoForm = useForm<UserInfo>({
    resolver: zodResolver(userInfoSchema),
    defaultValues: {
      name: "",
      email: "",
      company: "",
      website: "",
      industry: "",
    },
  });
  
  const scanQuestionsForm = useForm<ScanQuestions>({
    resolver: zodResolver(scanQuestionsSchema),
    defaultValues: {
      q1: "3",
      q2: "3",
      q3: "3",
      q4: "3",
      q5: "3",
      q6: "3",
      q7: "3",
      goals: "",
    },
  });
  
  const submitUserInfo = (data: UserInfo) => {
    setUserInfo(data);
    setCurrentStep(1);
  };
  
  const getScoreLabel = (score: number) => {
    if (score < 2) return language === 'nl' ? 'Kritiek' : 'Critical';
    if (score < 3) return language === 'nl' ? 'Zwak' : 'Weak';
    if (score < 4) return language === 'nl' ? 'Gemiddeld' : 'Average';
    if (score < 4.5) return language === 'nl' ? 'Goed' : 'Good';
    return language === 'nl' ? 'Uitstekend' : 'Excellent';
  };
  
  const getScoreDescription = (category: string, score: number) => {
    const descriptions = {
      nl: {
        strategy: {
          low: "Je marketingstrategie heeft dringend aandacht nodig. Er ontbreekt een duidelijke richting en doelen.",
          medium: "Je hebt een basisstrategie, maar deze kan verder worden uitgewerkt met duidelijkere doelen en planning.",
          high: "Je hebt een solide marketingstrategie met duidelijke doelen en uitvoering.",
        },
        funnel: {
          low: "Je verkoopfunnel is onvolledig of werkt niet effectief.",
          medium: "Je verkoopfunnel is opgezet maar heeft optimalisatie nodig om conversies te verhogen.",
          high: "Je verkoopfunnel is goed geoptimaliseerd en levert consistente resultaten.",
        },
        content: {
          low: "Je contentmarketing is minimaal of ontbreekt een duidelijke strategie.",
          medium: "Je produceert content maar deze kan beter afgestemd worden op je doelgroep en doelen.",
          high: "Je contentmarketing is sterk, met relevante en waardevolle content voor je doelgroep.",
        },
        social: {
          low: "Je sociale mediapresentie is beperkt of ineffectief.",
          medium: "Je bent actief op sociale media maar mist consistentie of een duidelijke strategie.",
          high: "Je sociale mediastrategie is effectief en bereikt de juiste doelgroep.",
        },
        seo: {
          low: "Je website is niet geoptimaliseerd voor zoekmachines.",
          medium: "Je hebt basis SEO-implementatie maar mist diepgang of technische optimalisatie.",
          high: "Je SEO-strategie is goed geïmplementeerd met sterke rankings en organisch verkeer.",
        },
      },
      en: {
        strategy: {
          low: "Your marketing strategy needs urgent attention. There's a lack of clear direction and goals.",
          medium: "You have a basic strategy, but it could be further developed with clearer goals and planning.",
          high: "You have a solid marketing strategy with clear goals and execution.",
        },
        funnel: {
          low: "Your sales funnel is incomplete or not working effectively.",
          medium: "Your sales funnel is set up but needs optimization to increase conversions.",
          high: "Your sales funnel is well optimized and delivers consistent results.",
        },
        content: {
          low: "Your content marketing is minimal or lacks a clear strategy.",
          medium: "You produce content but it could be better aligned with your audience and goals.",
          high: "Your content marketing is strong, with relevant and valuable content for your target audience.",
        },
        social: {
          low: "Your social media presence is limited or ineffective.",
          medium: "You're active on social media but lack consistency or a clear strategy.",
          high: "Your social media strategy is effective and reaches the right audience.",
        },
        seo: {
          low: "Your website is not optimized for search engines.",
          medium: "You have basic SEO implementation but lack depth or technical optimization.",
          high: "Your SEO strategy is well implemented with strong rankings and organic traffic.",
        },
      }
    };
    
    const lang = descriptions[language];
    const cat = category as keyof typeof lang;
    
    if (score < 2.5) return lang[cat].low;
    if (score < 4) return lang[cat].medium;
    return lang[cat].high;
  };
  
  const getRecommendations = (category: string, score: number) => {
    const recommendations = {
      nl: {
        strategy: {
          low: ["Ontwikkel een duidelijke marketingstrategie met specifieke doelen", "Definieer je unieke waardepropositie", "Stel concrete KPI's op om voortgang te meten"],
          medium: ["Verfijn je marketingdoelen om specifieker en meetbaarder te worden", "Ontwikkel een duidelijker beeld van je ideale klant", "Implementeer regelmatige evaluaties van je marketingresultaten"],
          high: ["Blijf je strategie regelmatig evalueren en bijstellen", "Experimenteer met nieuwe kanalen en tactieken", "Overweeg geavanceerde analyses voor diepere inzichten"],
        },
        funnel: {
          low: ["Maak een duidelijke customer journey map", "Implementeer basis leadgeneratie en nurturing", "Zorg voor duidelijke call-to-actions op je website"],
          medium: ["Optimaliseer je landingspagina's voor betere conversie", "Implementeer leadscoring om kwaliteit te meten", "Verbeter je email marketing automation flows"],
          high: ["Test en optimaliseer je funnel continu met A/B tests", "Implementeer geavanceerde personalisatie", "Integreer retargeting strategieën"],
        },
        content: {
          low: ["Ontwikkel een content kalender", "Focus op content die waarde biedt aan je doelgroep", "Begin met basis SEO-optimalisatie van je content"],
          medium: ["Diversifieer je content formats (video, podcasts, blogs)", "Ontwikkel een duidelijke tone-of-voice", "Implementeer een content distributie strategie"],
          high: ["Experimenteer met geavanceerde content formats", "Overweeg user-generated content", "Implementeer content personalisatie"],
        },
        social: {
          low: ["Kies 2-3 platforms die het best bij je doelgroep passen", "Ontwikkel een consistente posting strategie", "Begin met basis community management"],
          medium: ["Verfijn je sociale media content strategie per platform", "Implementeer social listening tools", "Begin met betaalde sociale media campagnes"],
          high: ["Optimaliseer je advertentie targeting", "Experimenteer met nieuwe social media formats", "Implementeer influencer marketing strategieën"],
        },
        seo: {
          low: ["Zorg voor technische basis SEO-optimalisatie", "Optimaliseer je belangrijkste webpagina's", "Begin met lokale SEO als dit relevant is"],
          medium: ["Ontwikkel een keyword strategie", "Verbeter je site structuur en interne linking", "Werk aan het verbeteren van je site snelheid"],
          high: ["Implementeer een content strategie gericht op SEO", "Werk aan het verkrijgen van kwaliteitsbacklinks", "Optimaliseer voor voice search en structured data"],
        },
      },
      en: {
        strategy: {
          low: ["Develop a clear marketing strategy with specific goals", "Define your unique value proposition", "Set concrete KPIs to measure progress"],
          medium: ["Refine your marketing goals to be more specific and measurable", "Develop a clearer picture of your ideal customer", "Implement regular evaluations of your marketing results"],
          high: ["Continue to regularly evaluate and adjust your strategy", "Experiment with new channels and tactics", "Consider advanced analytics for deeper insights"],
        },
        funnel: {
          low: ["Create a clear customer journey map", "Implement basic lead generation and nurturing", "Ensure clear call-to-actions on your website"],
          medium: ["Optimize your landing pages for better conversion", "Implement lead scoring to measure quality", "Improve your email marketing automation flows"],
          high: ["Continuously test and optimize your funnel with A/B tests", "Implement advanced personalization", "Integrate retargeting strategies"],
        },
        content: {
          low: ["Develop a content calendar", "Focus on content that provides value to your target audience", "Start with basic SEO optimization of your content"],
          medium: ["Diversify your content formats (video, podcasts, blogs)", "Develop a clear tone of voice", "Implement a content distribution strategy"],
          high: ["Experiment with advanced content formats", "Consider user-generated content", "Implement content personalization"],
        },
        social: {
          low: ["Choose 2-3 platforms that best suit your target audience", "Develop a consistent posting strategy", "Start with basic community management"],
          medium: ["Refine your social media content strategy per platform", "Implement social listening tools", "Start with paid social media campaigns"],
          high: ["Optimize your ad targeting", "Experiment with new social media formats", "Implement influencer marketing strategies"],
        },
        seo: {
          low: ["Ensure technical basic SEO optimization", "Optimize your main web pages", "Start with local SEO if relevant"],
          medium: ["Develop a keyword strategy", "Improve your site structure and internal linking", "Work on improving your site speed"],
          high: ["Implement a content strategy focused on SEO", "Work on obtaining quality backlinks", "Optimize for voice search and structured data"],
        },
      }
    };
    
    const lang = recommendations[language];
    const cat = category as keyof typeof lang;
    
    if (score < 2.5) return lang[cat].low;
    if (score < 4) return lang[cat].medium;
    return lang[cat].high;
  };
  
  const calculateResults = (data: ScanQuestions) => {
    // Convert string values to numbers
    const q1 = parseInt(data.q1);
    const q2 = parseInt(data.q2);
    const q3 = parseInt(data.q3);
    const q4 = parseInt(data.q4);
    const q5 = parseInt(data.q5);
    const q6 = parseInt(data.q6);
    const q7 = parseInt(data.q7);
    
    // Calculate scores per category
    const strategyScore = (q1 + q2) / 2;
    const funnelScore = (q3 + q7) / 2;
    const contentScore = q4;
    const socialScore = q5;
    const seoScore = q6;
    
    // Calculate overall score
    const overallScore = (strategyScore + funnelScore + contentScore + socialScore + seoScore) / 5;
    
    const scores = [
      {
        category: 'strategy',
        name: language === 'nl' ? 'Marketing Strategie' : 'Marketing Strategy',
        score: strategyScore,
        label: getScoreLabel(strategyScore),
        description: getScoreDescription('strategy', strategyScore),
        recommendations: getRecommendations('strategy', strategyScore),
      },
      {
        category: 'funnel',
        name: language === 'nl' ? 'Verkoopfunnel' : 'Sales Funnel',
        score: funnelScore,
        label: getScoreLabel(funnelScore),
        description: getScoreDescription('funnel', funnelScore),
        recommendations: getRecommendations('funnel', funnelScore),
      },
      {
        category: 'content',
        name: language === 'nl' ? 'Content Marketing' : 'Content Marketing',
        score: contentScore,
        label: getScoreLabel(contentScore),
        description: getScoreDescription('content', contentScore),
        recommendations: getRecommendations('content', contentScore),
      },
      {
        category: 'social',
        name: language === 'nl' ? 'Sociale Media' : 'Social Media',
        score: socialScore,
        label: getScoreLabel(socialScore),
        description: getScoreDescription('social', socialScore),
        recommendations: getRecommendations('social', socialScore),
      },
      {
        category: 'seo',
        name: language === 'nl' ? 'Zoekmachine Optimalisatie' : 'Search Engine Optimization',
        score: seoScore,
        label: getScoreLabel(seoScore),
        description: getScoreDescription('seo', seoScore),
        recommendations: getRecommendations('seo', seoScore),
      }
    ];
    
    return {
      scores,
      overallScore,
      overallLabel: getScoreLabel(overallScore),
      userGoals: data.goals,
    };
  };
  
  const submitScanQuestions = (data: ScanQuestions) => {
    const calculatedResults = calculateResults(data);
    setResults(calculatedResults);
    setCurrentStep(2);
    
    toast({
      title: language === 'nl' ? 'Scan voltooid' : 'Scan completed',
      description: language === 'nl' 
        ? 'Je kunt nu je marketingrapport bekijken' 
        : 'You can now view your marketing report',
    });
  };
  
  const generatePDF = async () => {
    if (!printRef.current) return;
    
    try {
      const canvas = await html2canvas(printRef.current, {
        scale: 2,
        logging: false,
        useCORS: true,
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });
      
      const imgWidth = 210;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
      pdf.save(language === 'nl' ? 'marketing-groeiscan-rapport.pdf' : 'marketing-growth-scan-report.pdf');
      
      toast({
        title: language === 'nl' ? 'PDF Gedownload' : 'PDF Downloaded',
        description: language === 'nl' 
          ? 'Je rapport is succesvol gedownload' 
          : 'Your report has been successfully downloaded',
      });
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast({
        title: language === 'nl' ? 'Fout bij downloaden' : 'Download error',
        description: language === 'nl' 
          ? 'Er is een fout opgetreden bij het genereren van de PDF' 
          : 'An error occurred while generating the PDF',
        variant: 'destructive',
      });
    }
  };
  
  const content = {
    nl: {
      title: 'Marketing GroeiScan',
      description: 'Ontdek in 2 minuten waar jouw marketing verbeterd kan worden en krijg direct praktische tips.',
      steps: [
        'Vul je gegevens in',
        'Beantwoord 7 korte vragen',
        'Ontvang direct je persoonlijke rapport'
      ],
      userInfo: {
        title: 'Jouw gegevens',
        name: 'Naam',
        email: 'E-mailadres',
        company: 'Bedrijfsnaam',
        website: 'Website (optioneel)',
        industry: 'Industrie',
        next: 'Volgende stap',
      },
      questions: {
        title: 'Marketingscan vragen',
        q1: 'Hoe duidelijk zijn jouw marketingdoelen en -strategie?',
        q2: 'Hoe goed begrijp je jouw ideale klant en zijn/haar behoeftes?',
        q3: 'Hoe effectief is jouw proces voor het genereren van leads?',
        q4: 'Hoe consistent produceer je waardevolle content voor jouw doelgroep?',
        q5: 'Hoe effectief is jouw sociale media presentie en engagement?',
        q6: 'Hoe goed is jouw website geoptimaliseerd voor zoekmachines?',
        q7: 'Hoe goed converteer je leads naar klanten?',
        goals: 'Wat zijn jouw belangrijkste marketingdoelen voor de komende 6 maanden?',
        scale: ['Zeer zwak', 'Zwak', 'Gemiddeld', 'Goed', 'Uitstekend'],
        complete: 'Voltooi scan',
      },
      results: {
        title: 'Jouw Marketing GroeiScan Rapport',
        overview: 'Overzicht',
        score: 'Totaalscore',
        detailedResults: 'Gedetailleerde resultaten',
        recommendations: 'Aanbevelingen',
        downloadPDF: 'Download als PDF',
        nextSteps: 'Volgende stappen',
        bookCall: 'Plan een gratis strategiegesprek',
        services: 'Bekijk onze diensten',
      }
    },
    en: {
      title: 'Marketing Growth Scan',
      description: 'Discover in 2 minutes where your marketing can be improved and get practical tips immediately.',
      steps: [
        'Fill in your details',
        'Answer 7 short questions',
        'Receive your personal report immediately'
      ],
      userInfo: {
        title: 'Your information',
        name: 'Name',
        email: 'Email address',
        company: 'Company name',
        website: 'Website (optional)',
        industry: 'Industry',
        next: 'Next step',
      },
      questions: {
        title: 'Marketing scan questions',
        q1: 'How clear are your marketing goals and strategy?',
        q2: 'How well do you understand your ideal customer and their needs?',
        q3: 'How effective is your lead generation process?',
        q4: 'How consistently do you produce valuable content for your target audience?',
        q5: 'How effective is your social media presence and engagement?',
        q6: 'How well is your website optimized for search engines?',
        q7: 'How well do you convert leads into customers?',
        goals: 'What are your main marketing goals for the next 6 months?',
        scale: ['Very weak', 'Weak', 'Average', 'Good', 'Excellent'],
        complete: 'Complete scan',
      },
      results: {
        title: 'Your Marketing Growth Scan Report',
        overview: 'Overview',
        score: 'Total score',
        detailedResults: 'Detailed results',
        recommendations: 'Recommendations',
        downloadPDF: 'Download as PDF',
        nextSteps: 'Next steps',
        bookCall: 'Book a free strategy call',
        services: 'View our services',
      }
    }
  };
  
  const text = content[language];
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-40 pb-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-center mb-8">
              <Scan className="mr-3 h-10 w-10 text-accent-orange" />
              <h1 className="text-primary-blue text-3xl md:text-4xl font-bold">{text.title}</h1>
            </div>
            
            <p className="text-center text-gray-dark text-lg mb-8 max-w-3xl mx-auto">
              {text.description}
            </p>
            
            <div className="flex items-center justify-center space-x-4 md:space-x-8 mb-12">
              {text.steps.map((step, index) => (
                <div key={index} className="flex items-center">
                  <div 
                    className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${
                      currentStep > index 
                        ? 'bg-accent-orange text-white' 
                        : index === currentStep 
                          ? 'bg-primary-blue text-white' 
                          : 'bg-gray-medium text-white'
                    }`}
                  >
                    {index + 1}
                  </div>
                  <span className={`text-sm ${index === currentStep ? 'font-bold' : ''}`}>{step}</span>
                </div>
              ))}
            </div>
            
            {currentStep === 0 && (
              <div className="bg-white rounded-xl shadow-lg p-6 md:p-8">
                <h2 className="text-xl font-bold mb-6">{text.userInfo.title}</h2>
                
                <Form {...userInfoForm}>
                  <form onSubmit={userInfoForm.handleSubmit(submitUserInfo)} className="space-y-4">
                    <FormField
                      control={userInfoForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{text.userInfo.name}</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={userInfoForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{text.userInfo.email}</FormLabel>
                          <FormControl>
                            <Input type="email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={userInfoForm.control}
                      name="company"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{text.userInfo.company}</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={userInfoForm.control}
                      name="website"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{text.userInfo.website}</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={userInfoForm.control}
                      name="industry"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{text.userInfo.industry}</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="pt-4">
                      <Button type="submit" className="primary-cta w-full">
                        {text.userInfo.next} <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
            )}
            
            {currentStep === 1 && (
              <div className="bg-white rounded-xl shadow-lg p-6 md:p-8">
                <h2 className="text-xl font-bold mb-6">{text.questions.title}</h2>
                
                <Form {...scanQuestionsForm}>
                  <form onSubmit={scanQuestionsForm.handleSubmit(submitScanQuestions)} className="space-y-8">
                    {[
                      { name: "q1", label: text.questions.q1 },
                      { name: "q2", label: text.questions.q2 },
                      { name: "q3", label: text.questions.q3 },
                      { name: "q4", label: text.questions.q4 },
                      { name: "q5", label: text.questions.q5 },
                      { name: "q6", label: text.questions.q6 },
                      { name: "q7", label: text.questions.q7 },
                    ].map((question, index) => (
                      <FormField
                        key={index}
                        control={scanQuestionsForm.control}
                        name={question.name as keyof ScanQuestions}
                        render={({ field }) => (
                          <FormItem className="space-y-3">
                            <FormLabel>{question.label}</FormLabel>
                            <div className="flex justify-between items-center">
                              {text.questions.scale.map((label, i) => (
                                <Label
                                  key={i}
                                  className={`flex flex-col items-center cursor-pointer p-2 rounded transition-colors ${
                                    field.value === String(i + 1) 
                                      ? 'bg-accent-orange text-white' 
                                      : 'hover:bg-gray-light'
                                  }`}
                                  onClick={() => field.onChange(String(i + 1))}
                                >
                                  <span className="text-xl font-bold mb-1">{i + 1}</span>
                                  <span className="text-xs text-center">{label}</span>
                                </Label>
                              ))}
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    ))}
                    
                    <FormField
                      control={scanQuestionsForm.control}
                      name="goals"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{text.questions.goals}</FormLabel>
                          <FormControl>
                            <Textarea {...field} className="min-h-[100px]" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="primary-cta w-full">
                      {text.questions.complete}
                    </Button>
                  </form>
                </Form>
              </div>
            )}
            
            {currentStep === 2 && results && (
              <div ref={printRef}>
                <div className="bg-white rounded-xl shadow-lg p-6 md:p-8 mb-6">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center">
                      <ChartLine className="mr-2 h-6 w-6 text-accent-orange" />
                      <h2 className="text-2xl font-bold">{text.results.title}</h2>
                    </div>
                    
                    <Button onClick={generatePDF} variant="outline" className="flex items-center">
                      <Download className="mr-2 h-5 w-5" />
                      {text.results.downloadPDF}
                    </Button>
                  </div>
                  
                  {userInfo && (
                    <div className="mb-8">
                      <div className="font-bold">{userInfo.name}</div>
                      <div>{userInfo.company}</div>
                      <div>{userInfo.email}</div>
                      {userInfo.website && <div>{userInfo.website}</div>}
                    </div>
                  )}
                  
                  <h3 className="text-xl font-bold mb-4">{text.results.overview}</h3>
                  <div className="mb-8 p-6 bg-gray-light rounded-lg text-center">
                    <div className="text-sm text-gray-medium mb-1">{text.results.score}</div>
                    <div className="text-4xl font-bold text-primary-blue mb-2">
                      {results.overallScore.toFixed(1)}/5
                    </div>
                    <div className="text-xl font-medium">{results.overallLabel}</div>
                  </div>
                  
                  <h3 className="text-xl font-bold mb-4">{text.results.detailedResults}</h3>
                  
                  <div className="space-y-8 mb-8">
                    {results.scores.map((item: any, index: number) => (
                      <div key={index} className="border-b pb-6 last:border-0 last:pb-0">
                        <div className="flex justify-between items-center mb-4">
                          <h4 className="text-lg font-bold">{item.name}</h4>
                          <div className="flex items-center">
                            <span className="mr-2">{item.label}</span>
                            <span className="bg-primary-blue text-white rounded-full w-8 h-8 flex items-center justify-center font-bold">
                              {item.score.toFixed(1)}
                            </span>
                          </div>
                        </div>
                        
                        <p className="mb-4">{item.description}</p>
                        
                        <div>
                          <h5 className="font-bold mb-2 text-accent-orange">
                            {text.results.recommendations}:
                          </h5>
                          <ul className="list-disc pl-5 space-y-1">
                            {item.recommendations.map((rec: string, i: number) => (
                              <li key={i}>{rec}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {results.userGoals && (
                    <div className="mb-8">
                      <h4 className="font-bold mb-2">
                        {language === 'nl' ? 'Jouw doelen' : 'Your goals'}:
                      </h4>
                      <p className="italic bg-gray-light p-4 rounded">{results.userGoals}</p>
                    </div>
                  )}
                  
                  <h3 className="text-xl font-bold mb-4">{text.results.nextSteps}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button asChild className="primary-cta">
                      <a href="/contact">
                        {text.results.bookCall}
                      </a>
                    </Button>
                    <Button asChild variant="outline">
                      <a href="/aanbod/vergelijk">
                        {text.results.services}
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
      
      <Footer language={language} />
    </div>
  );
};

export default GroeiScan;
