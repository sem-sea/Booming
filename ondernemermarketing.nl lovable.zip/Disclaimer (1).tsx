
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '@/contexts/LanguageContext';

const Disclaimer = () => {
  const { language } = useLanguage();
  
  const content = {
    nl: {
      title: 'Disclaimer',
      lastUpdated: 'Laatst bijgewerkt: December 2024',
      sections: [
        {
          title: '1. Algemene disclaimer',
          content: `
            <p>De informatie op deze website wordt verstrekt op basis van "zoals het is" zonder enige vorm van garantie. OndernemerMarketing.nl streeft ernaar de informatie op deze website zo accuraat en actueel mogelijk te houden, maar kan niet garanderen dat alle informatie te allen tijde volledig en correct is.</p>
          `
        },
        {
          title: '2. Geen garantie op resultaten',
          content: `
            <p>OndernemerMarketing.nl geeft geen garantie dat de verstrekte diensten tot specifieke resultaten zullen leiden. Hoewel wij ons uiterste best doen om effectieve marketingoplossingen te bieden, zijn resultaten afhankelijk van vele factoren die buiten onze controle liggen.</p>
            <p>Alle genoemde resultaten, voorbeelden en case studies zijn indicatief en geen garantie voor toekomstige prestaties.</p>
          `
        },
        {
          title: '3. Aansprakelijkheid',
          content: `
            <p>OndernemerMarketing.nl is niet aansprakelijk voor:</p>
            <ul>
              <li>Directe, indirecte, incidentele of gevolgschade</li>
              <li>Verlies van omzet, winst of gegevens</li>
              <li>Bedrijfsonderbreking</li>
              <li>Schade door computervirussen of technische problemen</li>
            </ul>
          `
        },
        {
          title: '4. Links naar externe websites',
          content: `
            <p>Deze website kan links bevatten naar externe websites. OndernemerMarketing.nl heeft geen controle over de inhoud van deze websites en is niet verantwoordelijk voor de inhoud, het privacybeleid of de praktijken van deze externe sites.</p>
          `
        },
        {
          title: '5. Wijzigingen',
          content: `
            <p>OndernemerMarketing.nl behoudt zich het recht voor om deze disclaimer op elk moment te wijzigen zonder voorafgaande kennisgeving. Het is uw verantwoordelijkheid om deze disclaimer regelmatig te controleren op wijzigingen.</p>
          `
        },
        {
          title: '6. Toepasselijk recht',
          content: `
            <p>Op deze disclaimer is Nederlands recht van toepassing. Geschillen worden voorgelegd aan de bevoegde rechter in Rotterdam.</p>
          `
        }
      ]
    },
    en: {
      title: 'Disclaimer',
      lastUpdated: 'Last updated: December 2024',
      sections: [
        {
          title: '1. General disclaimer',
          content: `
            <p>The information on this website is provided on an "as is" basis without any warranty. OndernemerMarketing.nl strives to keep the information on this website as accurate and current as possible, but cannot guarantee that all information is complete and correct at all times.</p>
          `
        },
        {
          title: '2. No guarantee of results',
          content: `
            <p>OndernemerMarketing.nl does not guarantee that the services provided will lead to specific results. While we do our utmost to provide effective marketing solutions, results depend on many factors that are beyond our control.</p>
            <p>All mentioned results, examples and case studies are indicative and no guarantee of future performance.</p>
          `
        },
        {
          title: '3. Liability',
          content: `
            <p>OndernemerMarketing.nl is not liable for:</p>
            <ul>
              <li>Direct, indirect, incidental or consequential damage</li>
              <li>Loss of revenue, profit or data</li>
              <li>Business interruption</li>
              <li>Damage from computer viruses or technical problems</li>
            </ul>
          `
        },
        {
          title: '4. Links to external websites',
          content: `
            <p>This website may contain links to external websites. OndernemerMarketing.nl has no control over the content of these websites and is not responsible for the content, privacy policy or practices of these external sites.</p>
          `
        },
        {
          title: '5. Changes',
          content: `
            <p>OndernemerMarketing.nl reserves the right to modify this disclaimer at any time without prior notice. It is your responsibility to check this disclaimer regularly for changes.</p>
          `
        },
        {
          title: '6. Applicable law',
          content: `
            <p>Dutch law applies to this disclaimer. Disputes will be submitted to the competent court in Rotterdam.</p>
          `
        }
      ]
    }
  };

  const { title, lastUpdated, sections } = content[language];

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-28">
        <section className="py-12 bg-gray-light">
          <div className="container mx-auto">
            <h1 className="text-center mb-2">{title}</h1>
            <p className="text-center text-gray-dark">{lastUpdated}</p>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container mx-auto max-w-4xl">
            {sections.map((section, index) => (
              <div key={index} className="mb-8">
                <h2 className="text-2xl font-bold text-primary-blue mb-4">{section.title}</h2>
                <div 
                  className="prose prose-lg max-w-none text-gray-dark"
                  dangerouslySetInnerHTML={{ __html: section.content }}
                />
              </div>
            ))}
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Disclaimer;
