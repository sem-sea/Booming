import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Mail, Phone, MapPin } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const Contact = () => {
  const { language } = useLanguage();

  const content = {
    nl: {
      title: 'Contact',
      subtitle: 'Neem contact met ons op',
      description:
        'Wil je weten wat wij voor jou kunnen betekenen? Vul het formulier in of neem direct contact met ons op.',
      form: {
        title: 'Stuur ons een bericht'
      },
      contact: {
        title: 'Contactgegevens',
        email: 'info@ondernemermarketing.nl',
        phone: '+31 6 1301 3266',
        address: 'Breedveldsingel 1<br>3055PG Rotterdam<br>Nederland'
      },
      faq: {
        title: 'Veelgestelde vragen',
        questions: [
          {
            question: 'Hoe snel kunnen jullie starten?',
            answer:
              'Meestal kunnen we binnen 2 dagen na het intakegesprek starten met de implementatie van je marketingstrategie.'
          },
          {
            question: 'Werken jullie met contracten?',
            answer:
              'Voor de Social Media Funnel Pack werken we met een eenmalig project. Voor andere diensten werken we met een minimale periode van 3 maanden, daarna maandelijks opzegbaar.'
          },
          {
            question: 'Wat als ik niet tevreden ben?',
            answer:
              'We werken met duidelijke resultaatafspraken. Als we deze niet halen, kijken we samen naar een passende oplossing of compensatie.'
          }
        ]
      }
    },
    en: {
      title: 'Contact',
      subtitle: 'Get in touch with us',
      description:
        'Want to know what we can do for you? Fill out the form or contact us directly.',
      form: {
        title: 'Send us a message'
      },
      contact: {
        title: 'Contact details',
        email: 'info@ondernemermarketing.nl',
        phone: '+31 6 1301 3266',
        address: 'Breedveldsingel 1<br>3055PG Rotterdam<br>The Netherlands'
      },
      faq: {
        title: 'Frequently asked questions',
        questions: [
          {
            question: 'How fast can you start?',
            answer:
              'Usually we can start implementing your marketing strategy within 2 days after the intake interview.'
          },
          {
            question: 'Do you work with contracts?',
            answer:
              "For the Social Media Funnel Pack we work with a one-time project. For other services we work with a minimum period of 3 months, after which it's cancellable monthly."
          },
          {
            question: "What if I'm not satisfied?",
            answer:
              "We work with clear performance agreements. If we don't meet these, we'll look together for a suitable solution or compensation."
          }
        ]
      }
    }
  };

  const { title, subtitle, description, form, contact, faq } = content[language];

  return (
    <div className="min-h-screen">
      <Header />

      <main className="pt-28">
        {/* Hero Section */}
        <section className="py-12 md:py-16 bg-gray-light">
          <div className="container mx-auto text-center">
            <h1 className="mb-4">{title}</h1>
            <h2 className="text-xl md:text-2xl font-bold mb-4 text-primary-blue">{subtitle}</h2>
            <p className="max-w-2xl mx-auto text-gray-dark">{description}</p>
          </div>
        </section>

        {/* Contact Form Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto">
            <div className="flex flex-col lg:flex-row gap-12">
              {/* Form (Replaced with Brevo iframe) */}
              <div className="lg:w-2/3">
                <h3 className="text-xl font-bold mb-6 text-primary-blue">{form.title}</h3>
                <div className="w-full">
                  <iframe
                    src="https://1de007b5.sibforms.com/serve/MUIFAOothCQvA7J9t8D27XNLoQQzmcbb3Dwu0hnKQwyYdy-rb6bGR6_oFD1meTh1YelAN6gmwmILWxPAz-YG-EV4SYU5SCwtIsuSd0Bw5UGoZTeBDOnrJBIQePCObxCC8Cp-k2_UTrOX4xMVNo60ortFYXoS77BN4xurRE-HKEYrSuBwwFsKLTh_t6xy521LpcplT3xra_o2RXq6"
                    style={{
                      width: '100%',
                      minHeight: '1000px',
                      border: 'none',
                      overflow: 'hidden'
                    }}
                    loading="lazy"
                    title="Contactformulier"
                  ></iframe>
                </div>
              </div>

              {/* Contact Details */}
              <div className="lg:w-1/3 bg-gray-light rounded-xl p-8">
                <h3 className="text-xl font-bold mb-6 text-primary-blue">{contact.title}</h3>

                <div className="space-y-6">
                  <div className="flex items-start">
                    <Mail className="h-6 w-6 text-accent-orange mr-4 mt-1" />
                    <div>
                      <p className="font-medium mb-1">{language === 'nl' ? 'E-mail' : 'Email'}</p>
                      <a href={`mailto:${contact.email}`} className="text-primary-blue hover:underline">
                        {contact.email}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <Phone className="h-6 w-6 text-accent-orange mr-4 mt-1" />
                    <div>
                      <p className="font-medium mb-1">{language === 'nl' ? 'Telefoon' : 'Phone'}</p>
                      <a href={`tel:${contact.phone.replace(/\s/g, '')}`} className="text-primary-blue hover:underline">
                        {contact.phone}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <MapPin className="h-6 w-6 text-accent-orange mr-4 mt-1" />
                    <div>
                      <p className="font-medium mb-1">{language === 'nl' ? 'Adres' : 'Address'}</p>
                      <div dangerouslySetInnerHTML={{ __html: contact.address }} />
                    </div>
                  </div>
                </div>

                {/* Map */}
                <div className="mt-8">
                  <div className="bg-gray-medium h-48 rounded-lg overflow-hidden">
                    <img
                      src="/lovable-uploads/4aa69807-6024-4c17-be50-0a6bd7f3cfb9.png"
                      alt="Rotterdam office"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-16 bg-gray-light">
          <div className="container mx-auto">
            <h2 className="mb-8 text-center">{faq.title}</h2>

            <div className="max-w-3xl mx-auto">
              {faq.questions.map((item, index) => (
                <div key={index} className="mb-6">
                  <h3 className="text-lg font-bold mb-2 text-primary-blue">{item.question}</h3>
                  <p className="text-gray-dark">{item.answer}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Contact;
