
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight, Target, Zap, TrendingUp } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';

const Services = () => {
  const { language, t } = useLanguage();

  const services = [
    {
      icon: Target,
      title: {
        nl: 'Social Media Funnel Pack', 
        en: 'Social Media Funnel Pack'
      },
      description: {
        nl: 'Een profiel dat niet informeert, maar converteert. Inclusief wervende profieltekst en DM-scripts.',
        en: 'A profile that doesn\'t inform, but converts. Including compelling profile text and DM scripts.'
      },
      price: '€600',
      image: '/lovable-uploads/8cd60c1b-0323-4872-bf95-8063f71492ee.png',
      link: '/pakketten'
    },
    {
      icon: Zap,
      title: {
        nl: 'Lead Magnet Landingspagina',
        en: 'Lead Magnet Landing Page'
      },
      description: {
        nl: 'Een pagina die je magnet laat werken en leads oplevert. Volledig geoptimaliseerd voor conversie.',
        en: 'A page that makes your magnet work and generates leads. Fully optimized for conversion.'
      },
      price: '€950',
      image: '/lovable-uploads/12f5314d-f5e2-4038-8fde-5c5ab0bef4b8.png',
      link: '/pakketten'
    },
    {
      icon: TrendingUp,
      title: {
        nl: 'Website Light',
        en: 'Website Light'
      },
      description: {
        nl: 'Binnen 1 week live met een professionele website. Tot 5 pagina\'s met conversiegerichte opbouw. Hulp bij domein en e-mail. ',
        en: 'Live within 1 week with a professional website. Up to 5 pages with conversion-focused structure.'
      },
      price: '€99',
      image: '/lovable-uploads/3a5b5085-513f-4587-8e42-b13eee3cde80.png',
      link: '/pakketten'
    }
  ];

  return (
    <section id="services" className="py-16 bg-white">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="mb-4">Snelle Pakketten</h2>
          <p className="text-xl text-gray-dark max-w-3xl mx-auto">
            {t('services.subtitle')}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div key={index} className="bg-gray-light rounded-2xl p-8 hover:shadow-lg transition-shadow duration-300">
                <div className="mb-6">
                  <img 
                    src={service.image} 
                    alt={service.title[language]} 
                    className="w-full h-48 object-cover rounded-lg mb-4"
                  />
                  <Icon className="h-12 w-12 text-accent-orange mb-4" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-primary-blue">
                  {service.title[language]}
                </h3>
                <p className="text-gray-dark mb-6">
                  {service.description[language]}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-primary-blue">{service.price}</span>
                  <Button asChild variant="outline" size="sm">
                    <Link to={service.link}>
                      {language === 'nl' ? 'Bekijk dienst' : 'View service'}
                    </Link>
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="text-center mt-12">
          <Button asChild className="primary-cta">
            <Link to="/pakketten">
              {language === 'nl' ? 'Bekijk alle pakketten' : 'View all packages'} <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Services;
