
import React from 'react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useLanguage } from '@/contexts/LanguageContext';

interface LanguageSwitcherProps {
  className?: string;
  onLanguageChange?: (language: 'nl' | 'en') => void;
}

const LanguageSwitcher = ({ className, onLanguageChange }: LanguageSwitcherProps) => {
  const { language, setLanguage } = useLanguage();

  const handleLanguageChange = (selectedLanguage: 'nl' | 'en') => {
    setLanguage(selectedLanguage);
    if (onLanguageChange) {
      onLanguageChange(selectedLanguage);
    }
  };

  return (
    <div className={cn('flex items-center gap-2', className)}>
      <Button
        variant="ghost"
        size="sm"
        className={`px-2 ${language === 'nl' ? 'font-bold' : 'font-normal opacity-60'}`}
        onClick={() => handleLanguageChange('nl')}
      >
        NL
      </Button>
      <span className="text-gray-dark">/</span>
      <Button
        variant="ghost"
        size="sm"
        className={`px-2 ${language === 'en' ? 'font-bold' : 'font-normal opacity-60'}`}
        onClick={() => handleLanguageChange('en')}
      >
        EN
      </Button>
    </div>
  );
};

export default LanguageSwitcher;
