
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface CTASectionProps {
  language?: 'nl' | 'en';
}

const CTASection = ({ language = 'nl' }: CTASectionProps) => {
  const content = {
    nl: {
      title: 'Klaar om marketing uit te besteden?',
      description: 'Plan een vrijblijvend intakegesprek en ontdek hoe wij jouw marketing kunnen laten groeien.',
      primaryCta: 'Plan gratis intake',
      secondaryCta: 'Bekijk eerst resultaten',
      features: [
        'Persoonlijke marketingstrategie',
        'Voorspelbare leadgeneratie',
        'Volledig uitbestede marketinguitvoering',
        'ROI-gedreven resultaten'
      ]
    },
    en: {
      title: 'Ready to outsource marketing?',
      description: 'Schedule a no-obligation intake call and discover how we can grow your marketing.',
      primaryCta: 'Schedule free intake',
      secondaryCta: 'View results first',
      features: [
        'Personal marketing strategy',
        'Predictable lead generation',
        'Fully outsourced marketing execution',
        'ROI-driven results'
      ]
    }
  };

  const { title, description, primaryCta, secondaryCta, features } = content[language];

  return (
    <section className="section-padding bg-white">
      <div className="container mx-auto">
        <div className="bg-gray-light rounded-2xl overflow-hidden">
          <div className="flex flex-col lg:flex-row">
            {/* Left side: Text content */}
            <div className="lg:w-7/12 p-8 md:p-12">
              <h2 className="text-primary-blue mb-4">{title}</h2>
              <p className="text-gray-dark mb-6 max-w-xl">{description}</p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-10 gap-y-3 mb-8">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center">
                    <svg className="w-5 h-5 mr-2 text-accent-orange" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span className="text-gray-dark">{feature}</span>
                  </div>
                ))}
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild className="primary-cta">
                  <Link to="/contact">
                    {primaryCta} <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>

              </div>
            </div>
            
            {/* Right side: Image */}
            <div className="lg:w-5/12 relative">
              <img 
                src="/lovable-uploads/57623f4c-b048-4084-ab9b-a2c896628472.png" 
                alt="Marketing consultation" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-primary-blue bg-opacity-20 backdrop-blur-sm"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
