
import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';

const LeadMagnets = () => {
  const { language } = useLanguage();
  
  const content = {
    nl: {
      title: 'Gratis tools om je marketing te verbeteren',
      subtitle: 'Waardevolle resources',
      description: 'Ontdek waar je staat met jouw marketing en wat de volgende stappen zijn om meer klanten te krijgen.',
      tools: [
        {
          title: 'Marketing GroeiScan',
          description: 'Ontdek in 2 minuten waar je marketing verbeterd kan worden.',
          cta: 'Start de scan',
          icon: '📈',
          url: '/groeiscan'
        },
        {
          title: 'Winstgroei Calculator',
          description: 'Bereken hoeveel extra omzet je kunt genereren met betere marketing.',
          cta: 'Bereken je potentieel',
          icon: '💰',
          url: '/calculator'
        },
        {
          title: 'Template Bundel',
          description: 'Direct toepasbare templates voor e-mails, social posts en meer.',
          cta: 'Download gratis',
          icon: '📋',
          url: '/tools/template-bundel'
        }
      ]
    },
    en: {
      title: 'Free tools to improve your marketing',
      subtitle: 'Valuable resources',
      description: 'Discover where you stand with your marketing and what the next steps are to get more customers.',
      tools: [
        {
          title: 'Marketing Growth Scan',
          description: 'Discover in 2 minutes where your marketing can be improved.',
          cta: 'Start the scan',
          icon: '📈',
          url: '/groeiscan'
        },
        {
          title: 'Profit Growth Calculator',
          description: 'Calculate how much extra revenue you can generate with better marketing.',
          cta: 'Calculate your potential',
          icon: '💰',
          url: '/calculator'
        },
        {
          title: 'Template Bundle',
          description: 'Directly applicable templates for emails, social posts and more.',
          cta: 'Download free',
          icon: '📋',
          url: '/tools/template-bundel'
        }
      ]
    }
  };

  const { title, subtitle, description, tools } = content[language];

  return (
    <section id="tools" className="section-padding bg-gray-light">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h3 className="text-primary-blue font-medium mb-2">{subtitle}</h3>
          <h2 className="mb-4">{title}</h2>
          <p className="max-w-2xl mx-auto text-gray-dark">{description}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {tools.map((tool, index) => (
            <div 
              key={index}
              className="bg-white rounded-xl p-8 shadow-md hover:shadow-xl transition-shadow duration-300"
            >
              <div className="text-4xl mb-6">{tool.icon}</div>
              <h3 className="text-xl font-bold mb-3 text-primary-blue">{tool.title}</h3>
              <p className="text-gray-dark mb-6">{tool.description}</p>
              <Button asChild className="primary-cta w-full">
                <Link to={tool.url}>
                  {tool.cta}
                </Link>
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default LeadMagnets;
