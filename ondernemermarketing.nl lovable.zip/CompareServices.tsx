
import React, { useState } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Button } from '@/components/ui/button';
import { ArrowRight, Check, X } from 'lucide-react';

const CompareServices = () => {
  const [language, setLanguage] = useState<'nl' | 'en'>('nl');
  
  const content = {
    nl: {
      title: 'Vergelijk onze diensten',
      subtitle: 'Kies de perfecte oplossing voor jouw bedrijf',
      description: 'Ontdek welke marketingoplossing het beste bij jou past. Van opstarten tot volledig uitbesteden, we hebben voor elk niveau een passende aanpak.',
      cta: 'Niet zeker wat je nodig hebt? Plan een gesprek',
      services: [
        {
          name: 'Kickstart Funnel',
          price: 'Vanaf €3.500',
          description: 'Perfect voor ondernemers die willen starten met een effectieve funnel zonder gedoe.',
          features: [
            { name: 'Strategische lead magnets', included: true },
            { name: 'E-mail nurturing reeks', included: true },
            { name: 'Verkoopgesprek strategie', included: true },
            { name: 'Technische implementatie', included: true },
            { name: 'A/B testing', included: false },
            { name: 'Contentcreatie', included: 'Beperkt' },
            { name: 'SEO-optimalisatie', included: false },
            { name: 'Performance marketing', included: false },
            { name: 'Persoonlijke marketeer', included: false },
            { name: 'Maandelijkse optimalisatie', included: false }
          ],
          buttonText: 'Meer over Kickstart Funnel',
          url: '/aanbod/kickstart-funnel'
        },
        {
          name: 'Groei Machine',
          price: 'Vanaf €4.500/maand',
          description: 'Voor ondernemers die serieuze groei willen realiseren met content en performance marketing.',
          features: [
            { name: 'Strategische lead magnets', included: true },
            { name: 'E-mail nurturing reeks', included: true },
            { name: 'Verkoopgesprek strategie', included: true },
            { name: 'Technische implementatie', included: true },
            { name: 'A/B testing', included: true },
            { name: 'Contentcreatie', included: true },
            { name: 'SEO-optimalisatie', included: true },
            { name: 'Performance marketing', included: true },
            { name: 'Persoonlijke marketeer', included: false },
            { name: 'Maandelijkse optimalisatie', included: true }
          ],
          buttonText: 'Meer over Groei Machine',
          url: '/aanbod/groei-machine',
          highlight: true
        },
        {
          name: 'Volledig Uitbesteed',
          price: 'Vanaf €7.500/maand',
          description: 'Voor ondernemers die hun marketing volledig willen uitbesteden voor maximale focus op hun bedrijf.',
          features: [
            { name: 'Strategische lead magnets', included: true },
            { name: 'E-mail nurturing reeks', included: true },
            { name: 'Verkoopgesprek strategie', included: true },
            { name: 'Technische implementatie', included: true },
            { name: 'A/B testing', included: true },
            { name: 'Contentcreatie', included: true },
            { name: 'SEO-optimalisatie', included: true },
            { name: 'Performance marketing', included: true },
            { name: 'Persoonlijke marketeer', included: true },
            { name: 'Maandelijkse optimalisatie', included: true }
          ],
          buttonText: 'Meer over Volledig Uitbesteed',
          url: '/aanbod/volledig-uitbesteed'
        }
      ]
    },
    en: {
      title: 'Compare our services',
      subtitle: 'Choose the perfect solution for your business',
      description: 'Discover which marketing solution suits you best. From getting started to fully outsourced, we have an appropriate approach for every level.',
      cta: 'Not sure what you need? Schedule a call',
      services: [
        {
          name: 'Kickstart Funnel',
          price: 'From €3,500',
          description: 'Perfect for entrepreneurs who want to start with an effective funnel without the hassle.',
          features: [
            { name: 'Strategic lead magnets', included: true },
            { name: 'Email nurturing series', included: true },
            { name: 'Sales call strategy', included: true },
            { name: 'Technical implementation', included: true },
            { name: 'A/B testing', included: false },
            { name: 'Content creation', included: 'Limited' },
            { name: 'SEO optimization', included: false },
            { name: 'Performance marketing', included: false },
            { name: 'Personal marketer', included: false },
            { name: 'Monthly optimization', included: false }
          ],
          buttonText: 'More about Kickstart Funnel',
          url: '/aanbod/kickstart-funnel'
        },
        {
          name: 'Growth Machine',
          price: 'From €4,500/month',
          description: 'For entrepreneurs who want to achieve serious growth with content and performance marketing.',
          features: [
            { name: 'Strategic lead magnets', included: true },
            { name: 'Email nurturing series', included: true },
            { name: 'Sales call strategy', included: true },
            { name: 'Technical implementation', included: true },
            { name: 'A/B testing', included: true },
            { name: 'Content creation', included: true },
            { name: 'SEO optimization', included: true },
            { name: 'Performance marketing', included: true },
            { name: 'Personal marketer', included: false },
            { name: 'Monthly optimization', included: true }
          ],
          buttonText: 'More about Growth Machine',
          url: '/aanbod/groei-machine',
          highlight: true
        },
        {
          name: 'Fully Outsourced',
          price: 'From €7,500/month',
          description: 'For entrepreneurs who want to fully outsource their marketing for maximum focus on their business.',
          features: [
            { name: 'Strategic lead magnets', included: true },
            { name: 'Email nurturing series', included: true },
            { name: 'Sales call strategy', included: true },
            { name: 'Technical implementation', included: true },
            { name: 'A/B testing', included: true },
            { name: 'Content creation', included: true },
            { name: 'SEO optimization', included: true },
            { name: 'Performance marketing', included: true },
            { name: 'Personal marketer', included: true },
            { name: 'Monthly optimization', included: true }
          ],
          buttonText: 'More about Fully Outsourced',
          url: '/aanbod/volledig-uitbesteed'
        }
      ]
    }
  };
  
  const { title, subtitle, description, cta, services } = content[language];
  
  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-28">
        {/* Hero Section */}
        <section className="py-12 md:py-16 bg-gray-light">
          <div className="container mx-auto text-center">
            <h1 className="mb-4">{title}</h1>
            <h2 className="text-xl md:text-2xl font-bold mb-4 text-primary-blue">{subtitle}</h2>
            <p className="max-w-2xl mx-auto text-gray-dark">{description}</p>
          </div>
        </section>
        
        {/* Comparison Table */}
        <section className="py-16 bg-white">
          <div className="container mx-auto">
            <div className="overflow-x-auto">
              <table className="min-w-full border-collapse">
                <thead>
                  <tr className="border-b border-gray-medium">
                    <th className="py-4 px-6 text-left"></th>
                    {services.map((service, index) => (
                      <th 
                        key={index} 
                        className={`py-4 px-6 text-center ${service.highlight ? 'bg-primary-blue text-white rounded-t-lg' : ''}`}
                      >
                        <div className="text-xl font-bold mb-2">{service.name}</div>
                        <div className={`text-lg ${service.highlight ? 'text-white' : 'text-accent-orange'}`}>{service.price}</div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="py-6 px-6 border-b border-gray-medium font-medium">
                      {language === 'nl' ? 'Omschrijving' : 'Description'}
                    </td>
                    {services.map((service, index) => (
                      <td 
                        key={index} 
                        className={`py-6 px-6 text-center border-b border-gray-medium ${service.highlight ? 'bg-blue-50' : ''}`}
                      >
                        <p className="text-sm">{service.description}</p>
                      </td>
                    ))}
                  </tr>
                  
                  {/* Features */}
                  {services[0].features.map((feature, featureIndex) => (
                    <tr key={featureIndex}>
                      <td className="py-4 px-6 border-b border-gray-medium font-medium">
                        {feature.name}
                      </td>
                      {services.map((service, serviceIndex) => {
                        const included = service.features[featureIndex].included;
                        return (
                          <td 
                            key={serviceIndex} 
                            className={`py-4 px-6 text-center border-b border-gray-medium ${service.highlight ? 'bg-blue-50' : ''}`}
                          >
                            {included === true ? (
                              <Check className="mx-auto text-accent-orange h-6 w-6" />
                            ) : included === false ? (
                              <X className="mx-auto text-gray-dark h-6 w-6" />
                            ) : (
                              <span>{included}</span>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                  
                  {/* CTA row */}
                  <tr>
                    <td className="py-6 px-6"></td>
                    {services.map((service, index) => (
                      <td key={index} className={`py-6 px-6 text-center ${service.highlight ? 'bg-blue-50' : ''}`}>
                        <Button 
                          asChild
                          className={service.highlight ? 'primary-cta' : 'secondary-cta'}
                        >
                          <a href={service.url}>
                            {service.buttonText} <ArrowRight className="ml-2 h-4 w-4" />
                          </a>
                        </Button>
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
            

          </div>
        </section>
      </main>
      
      <Footer language={language} />
    </div>
  );
};

export default CompareServices;
