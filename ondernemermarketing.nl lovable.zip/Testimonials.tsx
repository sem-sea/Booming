
import React from 'react';
import { Button } from '@/components/ui/button';
import { Star, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface TestimonialsProps {
  language?: 'nl' | 'en';
}

const Testimonials = ({ language = 'nl' }: TestimonialsProps) => {
  const content = {
    nl: {
      title: 'Wat onze klanten zeggen',
      subtitle: 'Echte resultaten van echte ondernemers',
      cta: 'Ook zulke resultaten?',
      button: 'Plan gratis intake'
    },
    en: {
      title: 'What our clients say',
      subtitle: 'Real results from real entrepreneurs',
      cta: 'Want similar results?',
      button: 'Schedule free intake'
    }
  };

  const testimonials = [
    {
      name: 'Sarah van der Berg',
      company: 'Business Coach',
      text: {
        nl: 'Binnen 3 maanden van 2 naar 15 nieuwe klanten per maand. De LinkedIn strategie die Ben heeft opgezet werkt echt fantastisch.',
        en: 'Within 3 months from 2 to 15 new clients per month. The LinkedIn strategy that Ben set up works really fantastic.'
      },
      rating: 5,
      image: '/lovable-uploads/0970519e-7452-40f9-830d-5c8bca26f492.png'
    },
    {
      name: 'Mark Jansen',
      company: 'IT Consultant',
      text: {
        nl: 'Eindelijk een marketingbureau dat doet wat ze beloven. Mijn agenda staat nu vol met kwalitatieve leads.',
        en: 'Finally a marketing agency that does what they promise. My calendar is now full of quality leads.'
      },
      rating: 5,
      image: '/lovable-uploads/1e5f3aed-6ac5-4346-bdf9-f26f7e5be761.png'
    },
    {
      name: 'Lisa Vermeulen',
      company: 'Trainer',
      text: {
        nl: 'De one-page funnel heeft mijn conversie met 340% verhoogd. Ik had dit veel eerder moeten doen.',
        en: 'The one-page funnel increased my conversion by 340%. I should have done this much earlier.'
      },
      rating: 5,
      image: '/lovable-uploads/4aa69807-6024-4c17-be50-0a6bd7f3cfb9.png'
    }
  ];

  const { title, subtitle, cta, button } = content[language];

  return (
    <section id="results" className="py-16 bg-gray-light">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="mb-4">{title}</h2>
          <p className="text-xl text-gray-dark">{subtitle}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-md">
              <div className="flex items-center mb-4">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name} 
                  className="w-16 h-16 rounded-full object-cover mr-4"
                  loading="lazy"
                />
                <div>
                  <h4 className="font-bold text-primary-blue">{testimonial.name}</h4>
                  <p className="text-sm text-gray-dark">{testimonial.company}</p>
                </div>
              </div>
              
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              
              <p className="text-gray-dark italic">"{testimonial.text[language]}"</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <h3 className="text-2xl font-bold mb-6 text-primary-blue">{cta}</h3>
          <Button asChild className="bg-accent-orange hover:bg-orange-600 text-white">
            <Link to="/contact">
              {button} <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
