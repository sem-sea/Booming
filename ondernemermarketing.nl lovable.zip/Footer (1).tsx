
import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';

interface FooterProps {
  language?: 'nl' | 'en';
}

const Footer: React.FC<FooterProps> = ({ language: propLanguage }) => {
  const { language: contextLanguage } = useLanguage();
  const language = propLanguage || contextLanguage;

  const content = {
    nl: {
      company: 'OndernemerMarketing',
      about: 'Over ons',
      services: 'Diensten',
      contact: 'Contact',
      phone: 'Telefoon',
      email: 'E-mail',
      address: 'Adres',
      followUs: 'Volg ons',
      copyright: '© 2025 OndernemerMarketing. Alle rechten voorbehouden.',
      privacy: 'Privacybeleid',
      terms: 'Algemene voorwaarden',
      disclaimer: 'Disclaimer'
    },
    en: {
      company: 'OndernemerMarketing',
      about: 'About us',
      services: 'Services',
      contact: 'Contact',
      phone: 'Phone',
      email: 'Email',
      address: 'Address',
      followUs: 'Follow us',
      copyright: '© 2025 OndernemerMarketing. All rights reserved.',
      privacy: 'Privacy Policy',
      terms: 'Terms & Conditions',
      disclaimer: 'Disclaimer'
    }
  };

  const { company, about, services, contact, phone, email, address, followUs, copyright, privacy, terms, disclaimer } = content[language];

  return (
    <footer className="bg-primary-blue text-white py-12">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold mb-4">{company}</h3>
            <p className="text-gray-300 mb-4">
              {language === 'nl' 
                ? 'Wij helpen ondernemers met effectieve marketing die echt werkt.'
                : 'We help entrepreneurs with effective marketing that really works.'
              }
            </p>
            <div className="space-y-2 text-sm">
              <p><strong>{phone}:</strong> +31 6 1301 3266</p>
              <p><strong>{email}:</strong> info@ondernemermarketing.nl</p>
              <p><strong>{address}:</strong> Breedveldsingel 1<br />3055PG Rotterdam<br />Nederland</p>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{language === 'nl' ? 'Snelle links' : 'Quick Links'}</h4>
            <ul className="space-y-2">
              <li><Link to="/aanbod/vergelijk" className="text-gray-300 hover:text-white transition-colors">Diensten</Link></li>
              <li><Link to="/pakketten" className="text-gray-300 hover:text-white transition-colors">Pakketten</Link></li>
              <li><Link to="/google-ads-uitbesteden" className="text-gray-300 hover:text-white transition-colors">Google Ads Uitbesteden</Link></li>
              <li><Link to="/#tools" className="text-gray-300 hover:text-white transition-colors">Tools</Link></li>
              <li><Link to="/blog" className="text-gray-300 hover:text-white transition-colors">Blog</Link></li>
              <li><Link to="/over-ons" className="text-gray-300 hover:text-white transition-colors">{about}</Link></li>
              <li><Link to="/contact" className="text-gray-300 hover:text-white transition-colors">{contact}</Link></li>
            </ul>
          </div>
          
          {/* Legal */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{language === 'nl' ? 'Juridisch' : 'Legal'}</h4>
            <ul className="space-y-2">
              <li><Link to="/privacy-policy" className="text-gray-300 hover:text-white transition-colors">{privacy}</Link></li>
              <li><Link to="/terms" className="text-gray-300 hover:text-white transition-colors">{terms}</Link></li>
              <li><Link to="/disclaimer" className="text-gray-300 hover:text-white transition-colors">{disclaimer}</Link></li>
            </ul>
          </div>
          
          {/* Social */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{followUs}</h4>
            <div className="flex space-x-4">
              <a href="https://linkedin.com/company/ondernemermarketing" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-white transition-colors">
                LinkedIn
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-primary-teal mt-8 pt-8 text-center">
          <p className="text-gray-300 text-sm">© 2025 OndernemerMarketing.nl. Alle rechten voorbehouden.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
