
import React from 'react';
import { Helmet } from 'react-helmet-async';

interface BlogArticleProps {
  post: {
    id: number;
    title: { nl: string; en: string };
    excerpt: { nl: string; en: string };
    content: { nl: string; en: string };
    image: string;
    category: { nl: string; en: string };
    date: { nl: string; en: string };
    slug: string;
    author?: string;
    readingTime?: number;
  };
  language: 'nl' | 'en';
}

const BlogArticle = ({ post, language }: BlogArticleProps) => {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toISOString();
  };

  const schemaMarkup = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    "headline": post.title[language],
    "description": post.excerpt[language],
    "image": `https://www.ondernemermarketing.nl${post.image}`,
    "author": {
      "@type": "Person",
      "name": post.author || "Ben van Ondernemermarketing.nl"
    },
    "publisher": {
      "@type": "Organization",
      "name": "Ondernemermarketing.nl",
      "logo": {
        "@type": "ImageObject",
        "url": "https://www.ondernemermarketing.nl/lovable-uploads/bf6accc4-838f-4f65-9b6a-1ef2f9fd9e46.png"
      }
    },
    "datePublished": formatDate("2025-05-01"),
    "dateModified": formatDate("2025-05-01"),
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": `https://www.ondernemermarketing.nl/blog/${post.slug}`
    }
  };

  return (
    <article>
      <Helmet>
        <title>{post.title[language]} | Ondernemermarketing.nl</title>
        <meta name="description" content={post.excerpt[language]} />
        <meta property="og:title" content={post.title[language]} />
        <meta property="og:description" content={post.excerpt[language]} />
        <meta property="og:image" content={`https://www.ondernemermarketing.nl${post.image}`} />
        <meta property="og:url" content={`https://www.ondernemermarketing.nl/blog/${post.slug}`} />
        <meta property="og:type" content="article" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={post.title[language]} />
        <meta name="twitter:description" content={post.excerpt[language]} />
        <meta name="twitter:image" content={`https://www.ondernemermarketing.nl${post.image}`} />
        <link rel="canonical" href={`https://www.ondernemermarketing.nl/blog/${post.slug}`} />
        <script type="application/ld+json">
          {JSON.stringify(schemaMarkup)}
        </script>
      </Helmet>
      
      <div className="mb-8">
        <img 
          src={post.image} 
          alt={post.title[language]} 
          className="w-full h-64 md:h-96 object-cover rounded-xl mb-8"
          loading="lazy"
        />
        <div className="flex items-center gap-4 mb-4">
          <span className="text-sm px-3 py-1 bg-gray-light rounded-full">
            {post.category[language]}
          </span>
          <span className="text-sm text-gray-dark">{post.date[language]}</span>
          {post.readingTime && (
            <span className="text-sm text-gray-dark">{post.readingTime} min leestijd</span>
          )}
        </div>
        <h1 className="text-3xl md:text-4xl font-bold mb-4 text-primary-blue">
          {post.title[language]}
        </h1>
        <p className="text-lg text-gray-dark mb-8">{post.excerpt[language]}</p>
      </div>
      
      <div 
        className="prose prose-lg max-w-none prose-headings:text-primary-blue prose-links:text-accent-orange"
        dangerouslySetInnerHTML={{ __html: post.content[language] }}
      />
    </article>
  );
};

export default BlogArticle;
