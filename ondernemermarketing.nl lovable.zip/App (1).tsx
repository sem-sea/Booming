
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { HelmetProvider } from 'react-helmet-async';
import { LanguageProvider, useLanguage } from "./contexts/LanguageContext";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import ServiceDetail from "./pages/ServiceDetail";
import ToolDetail from "./pages/ToolDetail";
import Blog from "./pages/Blog";
import AboutUs from "./pages/AboutUs";
import Contact from "./pages/Contact";
import CompareServices from "./pages/CompareServices";
import Calculator from "./pages/Calculator";
import GroeiScan from "./pages/GroeiScan";
import Pakketten from "./pages/Pakketten";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import Terms from "./pages/Terms";
import Disclaimer from "./pages/Disclaimer";
import GoogleAdsLanding from "./pages/GoogleAdsLanding";
import HighConvertingLanding from "./pages/HighConvertingLanding";

const queryClient = new QueryClient();

// Wrapper component to use the language context
const AppRoutes = () => {
  const { language } = useLanguage();
  
  return (
    <Routes>
      <Route path="/" element={<Index />} />
      <Route path="/pakketten" element={<Pakketten />} />
      <Route path="/privacy-policy" element={<PrivacyPolicy />} />
      <Route path="/terms" element={<Terms />} />
      <Route path="/disclaimer" element={<Disclaimer />} />
      <Route path="/google-ads-uitbesteden" element={<GoogleAdsLanding />} />
      <Route path="/marketing-pakketten" element={<HighConvertingLanding />} />
      <Route path="/aanbod/:serviceSlug" element={<ServiceDetail />} />
      <Route path="/tools/:toolSlug" element={<ToolDetail />} />
      <Route path="/blog" element={<Blog />} />
      <Route path="/blog/:slug" element={<Blog />} />
      <Route path="/over-ons" element={<AboutUs />} />
      <Route path="/about-us" element={<AboutUs />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/aanbod/vergelijk" element={<CompareServices />} />
      <Route path="/services/compare" element={<CompareServices />} />
      <Route path="/calculator" element={<Calculator />} />
      <Route path="/groeiscan" element={<GroeiScan />} />
      {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <HelmetProvider>
      <TooltipProvider>
        <LanguageProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <AppRoutes />
          </BrowserRouter>
        </LanguageProvider>
      </TooltipProvider>
    </HelmetProvider>
  </QueryClientProvider>
);

export default App;
