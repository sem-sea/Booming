
import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowRight } from 'lucide-react';

const ToolDetail = () => {
  const {toolSlug } = useParams();
  const [language, setLanguage] = useState<'nl' | 'en'>('nl');
  const [email, setEmail] = useState('');
  const [step, setStep] = useState(1);
  
  const tools = {
    'groeiscan': {
      nl: {
        title: 'Marketing GroeiScan',
        description: 'Ontdek in 2 minuten waar jouw marketing verbeterd kan worden en krijg direct praktische tips.',
        benefit: 'Na het invullen van deze korte scan ontvang je:',
        benefits: [
          'Een persoonlijke score op 5 cruciale marketinggebieden',
          'Direct inzicht in waar je de meeste groei kunt behalen',
          'Praktische tips die je meteen kunt implementeren',
          'Een gratis adviesgesprek om je resultaten te bespreken'
        ],
        steps: [
          'Vul je gegevens in',
          'Beantwoord 7 korte vragen',
          'Ontvang direct je persoonlijke rapport'
        ],
        cta: 'Start de scan',
        ctaNext: 'Volgende stap',
        emailPlaceholder: 'Jouw e-mailadres',
        nameLabel: 'Naam',
        emailLabel: 'E-mail',
        companyLabel: 'Bedrijfsnaam',
        success: 'Bedankt! Check je inbox voor je persoonlijke rapport.'
      },
      en: {
        title: 'Marketing Growth Scan',
        description: 'Discover in 2 minutes where your marketing can be improved and get practical tips immediately.',
        benefit: 'After completing this short scan, you will receive:',
        benefits: [
          'A personal score on 5 crucial marketing areas',
          'Direct insight into where you can achieve the most growth',
          'Practical tips you can implement right away',
          'A free consultation to discuss your results'
        ],
        steps: [
          'Fill in your details',
          'Answer 7 short questions',
          'Receive your personal report immediately'
        ],
        cta: 'Start the scan',
        ctaNext: 'Next step',
        emailPlaceholder: 'Your email address',
        nameLabel: 'Name',
        emailLabel: 'Email',
        companyLabel: 'Company name',
        success: 'Thank you! Check your inbox for your personal report.'
      }
    },
    'calculator': {
      nl: {
        title: 'Winstgroei Calculator',
        description: 'Bereken hoeveel extra omzet je kunt genereren met betere marketing.',
        benefit: 'Onze calculator laat je zien:',
        benefits: [
          'Hoeveel potentiële omzet je nu misloopt',
          'Wat het effect is van een verbeterde conversie',
          'Wat een beter leadgeneratie systeem voor je kan betekenen',
          'Je potentiële ROI bij professionele marketing'
        ],
        steps: [
          'Vul je huidige cijfers in',
          'Bekijk je potentiële groei',
          'Ontvang een uitgebreid rapport per e-mail'
        ],
        cta: 'Start de berekening',
        ctaNext: 'Bereken mijn potentieel',
        emailPlaceholder: 'Jouw e-mailadres',
        nameLabel: 'Naam',
        emailLabel: 'E-mail',
        companyLabel: 'Bedrijfsnaam',
        success: 'Je berekening is klaar! Check je inbox voor het volledige rapport.'
      },
      en: {
        title: 'Profit Growth Calculator',
        description: 'Calculate how much extra revenue you can generate with better marketing.',
        benefit: 'Our calculator shows you:',
        benefits: [
          'How much potential revenue you are missing out on',
          'The effect of improved conversion',
          'What a better lead generation system can do for you',
          'Your potential ROI with professional marketing'
        ],
        steps: [
          'Fill in your current numbers',
          'View your potential growth',
          'Receive a comprehensive report by email'
        ],
        cta: 'Start the calculation',
        ctaNext: 'Calculate my potential',
        emailPlaceholder: 'Your email address',
        nameLabel: 'Name',
        emailLabel: 'Email',
        companyLabel: 'Company name',
        success: 'Your calculation is ready! Check your inbox for the full report.'
      }
    }
  };
  
  // Default to groeiscan if no match found
  const currentTool = tools[toolSlug as keyof typeof tools] || tools['groeiscan'];
  const content = currentTool[language];
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 3) {
      setStep(step + 1);
    } else {
      // Submit form using our new ContactForm component for consistency
      console.log('Form submitted with email:', email);
      // In a real implementation, this would use the same Brevo integration
    }
  };
  
  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-28">
        <section className="py-12 md:py-20 bg-gray-light">
          <div className="container mx-auto">
            <div className="flex flex-col md:flex-row gap-12">
              <div className="md:w-1/2">
                <h1 className="text-primary-blue mb-4">{content.title}</h1>
                <p className="text-xl mb-6">{content.description}</p>
                
                <h3 className="font-medium mb-4">{content.benefit}</h3>
                <ul className="space-y-3 mb-8">
                  {content.benefits.map((benefit, index) => (
                    <li key={index} className="flex">
                      <svg className="w-5 h-5 mr-2 text-accent-orange" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <span>{benefit}</span>
                    </li>
                  ))}
                </ul>
                
                <div className="flex items-center space-x-6 mb-8">
                  {content.steps.map((stepText, index) => (
                    <div key={index} className="flex items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${step > index ? 'bg-accent-orange text-white' : index + 1 === step ? 'bg-primary-blue text-white' : 'bg-gray-medium text-gray-dark'}`}>
                        {index + 1}
                      </div>
                      <span className={`text-sm ${index + 1 === step ? 'font-bold' : ''}`}>{stepText}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="md:w-1/2">
                {step < 3 ? (
                  <div className="bg-white p-8 rounded-xl shadow-md">
                    <h3 className="text-xl font-bold mb-6 text-primary-blue">
                      {step === 1 ? (language === 'nl' ? 'Begin hier' : 'Start here') : 
                       step === 2 ? (language === 'nl' ? 'Nog een paar vragen' : 'A few more questions') : ''}
                    </h3>
                    
                    <form onSubmit={handleSubmit}>
                      {step === 1 && (
                        <>
                          <div className="mb-4">
                            <label htmlFor="name" className="block mb-2">{content.nameLabel}</label>
                            <Input id="name" type="text" required />
                          </div>
                          <div className="mb-4">
                            <label htmlFor="email" className="block mb-2">{content.emailLabel}</label>
                            <Input 
                              id="email" 
                              type="email" 
                              placeholder={content.emailPlaceholder} 
                              value={email}
                              onChange={(e) => setEmail(e.target.value)}
                              required 
                            />
                          </div>
                        </>
                      )}
                      
                      {step === 2 && (
                        <>
                          <div className="mb-4">
                            <label htmlFor="company" className="block mb-2">{content.companyLabel}</label>
                            <Input id="company" type="text" required />
                          </div>
                          <div className="mb-4">
                            <label className="block mb-2">{language === 'nl' ? 'Aantal huidige leads per maand' : 'Current leads per month'}</label>
                            <Input type="number" min="0" required />
                          </div>
                        </>
                      )}
                      
                      <Button type="submit" className="primary-cta w-full mt-6">
                        {content.ctaNext} <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </form>
                  </div>
                ) : (
                  <div className="bg-white p-8 rounded-xl shadow-md text-center">
                    <div className="w-16 h-16 rounded-full bg-accent-orange mx-auto mb-6 flex items-center justify-center">
                      <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <h3 className="text-xl font-bold mb-4 text-primary-blue">
                      {language === 'nl' ? 'Gelukt!' : 'Success!'}
                    </h3>
                    <p className="mb-6">{content.success}</p>
                    <Button asChild className="primary-cta">
                      <a href="/contact">
                        {language === 'nl' ? 'Plan je gratis gesprek' : 'Schedule your free consultation'} <ArrowRight className="ml-2 h-4 w-4" />
                      </a>
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer language={language} />
    </div>
  );
};

export default ToolDetail;
