
export const blogContent = {
  "waarom-je-marketing-je-nu-klanten-kost": {
    nl: `
      <h2>Marketing die klanten wegjaagt: herken jij deze fouten?</h2>
      
      <p>Je doet je best met marketing. Je post regelmatig op LinkedIn, je hebt een website, misschien wel wat advertenties gedraaid. Maar in plaats van meer klanten, krijg je minder reacties. In plaats van groei, zie je stagnatie. Wat gaat er mis?</p>
      
      <p>Het problème zit vaak niet in wat je doet, maar in hoe je het doet. Marketing die klanten wegjaagt heeft een aantal herkenbare patronen. En het goede nieuws? Die kun je omdraaien.</p>
      
      <h3>1. Je praat over jezelf in plaats van over hun probleem</h3>
      
      <p>De meeste ondernemers maken deze fout: ze praten over hun ervaring, hun kwalificaties, hun bedrijf. "Wij zijn al 15 jaar actief", "Ons team bestaat uit experts", "Wij bieden de beste service".</p>
      
      <p>Maar je klant denkt niet aan jou. Je klant denkt aan zijn probleem. Hij wordt 's nachts wakker van de zorgen over zijn omzet. Hij ergert zich aan het gebrek aan nieuwe klanten. Hij voelt zich overweldigd door alle marketingopties.</p>
      
      <p><strong>De oplossing:</strong> Begin elk gesprek, elke post, elke advertentie met hun probleem. "Heb je al weken geen nieuwe klanten binnen?" werkt beter dan "Wij zijn marketingexperts".</p>
      
      <h3>2. Je bombardeert ze met informatie</h3>
      
      <p>Je wilt laten zien dat je veel weet. Dus deel je uitgebreide artikelen, gedetailleerde infographics, complete handleidingen. Het probleem? Je overweldigt je potentiële klanten.</p>
      
      <p>Mensen willen geen informatie. Ze willen resultaten. Ze willen dat hun probleem opgelost wordt, niet dat ze er een studie van moeten maken.</p>
      
      <p><strong>De oplossing:</strong> Deel minder, maar maak het actionable. Een tip die ze vandaag nog kunnen uitvoeren is waardevoller dan een masterclass die ze nooit gaan volgen.</p>
      
      <h3>3. Je maakt het te complex</h3>
      
      <p>"Eerst analyseren we je huidige funnel, dan optimaliseren we je lead magnets, vervolgens implementeren we een geautomatiseerde nurture sequence..." Stop. Je hebt ze al verloren bij "analyseren".</p>
      
      <p>Complexiteit is de vijand van conversie. Hoe ingewikkelder je je aanpak laat klinken, hoe minder mensen durven te beginnen.</p>
      
      <p><strong>De oplossing:</strong> Maak het simpel. "We zorgen dat je meer klanten krijgt" is beter dan een uitleg van je 47-stappen proces.</p>
      
      <h3>4. Je jaagt op iedereen</h3>
      
      <p>"Geschikt voor alle ondernemers", "Voor iedereen die meer klanten wil", "Perfect voor elke branche". Dit klinkt inclusief, maar werkt averechts.</p>
      
      <p>Als je aanpak voor iedereen is, is het voor niemand echt relevant. Je klant wil zich gezien voelen, niet als onderdeel van een grote groep.</p>
      
      <p><strong>De oplossing:</strong> Kies een specifieke doelgroep en spreek ze direct aan. "Voor coaches die moeite hebben met LinkedIn" werkt beter dan "Voor iedereen die online wil groeien".</p>
      
      <h3>5. Je vergeet de emotie</h3>
      
      <p>Feiten en cijfers zijn belangrijk, maar mensen kopen op emotie. Ze willen zich veilig voelen, succesvol, gerust. Je marketing moet die gevoelens aanspreken.</p>
      
      <p>In plaats van "Wij verhogen je conversie met 40%" kun je zeggen "Stel je voor: elke dag nieuwe klanten, zonder dat je er zelf tijd in hoeft te steken".</p>
      
      <h3>De omslag maken</h3>
      
      <p>Marketing die werkt, doet het tegenovergestelde van wat de meeste ondernemers doen:</p>
      
      <ul>
        <li>Het begint bij hun probleem, niet bij jouw oplossing</li>
        <li>Het maakt dingen simpeler, niet complexer</li>
        <li>Het spreekt specifieke mensen aan, niet iedereen</li>
        <li>Het raakt emoties, niet alleen de ratio</li>
        <li>Het geeft duidelijkheid, niet informatie-overload</li>
      </ul>
      
      <p>Kijk eens naar je huidige marketing. Herken je deze fouten? Dan wordt het tijd voor een andere aanpak. Een aanpak die klanten aantrekt in plaats van wegjaagt.</p>
      
      <p>Want het verschil tussen marketing die werkt en marketing die niet werkt, zit vaak in de details. Details die je klanten doen stoppen... of juist doen doorklikken.</p>
    `,
    en: `
      <h2>Marketing that scares customers away: do you recognize these mistakes?</h2>
      
      <p>You're trying hard with marketing. You post regularly on LinkedIn, you have a website, maybe you've even run some ads. But instead of more customers, you're getting fewer responses. Instead of growth, you see stagnation. What's going wrong?</p>
      
      <p>The problem often isn't what you're doing, but how you're doing it. Marketing that scares customers away has recognizable patterns. The good news? You can turn those around.</p>
      
      <h3>1. You talk about yourself instead of their problem</h3>
      
      <p>Most entrepreneurs make this mistake: they talk about their experience, qualifications, their company. "We've been active for 15 years", "Our team consists of experts", "We offer the best service".</p>
      
      <p>But your customer isn't thinking about you. Your customer is thinking about their problem. They wake up at night worrying about their revenue. They're frustrated by the lack of new customers. They feel overwhelmed by all the marketing options.</p>
      
      <p><strong>The solution:</strong> Start every conversation, post, or ad with their problem. "Haven't had new customers in weeks?" works better than "We are marketing experts".</p>
      
      <h3>2. You bombard them with information</h3>
      
      <p>You want to show you know a lot. So you share extensive articles, detailed infographics, complete guides. The problem? You overwhelm your potential customers.</p>
      
      <p>People don't want information. They want results. They want their problem solved, not to make a study of it.</p>
      
      <p><strong>The solution:</strong> Share less, but make it actionable. A tip they can implement today is more valuable than a masterclass they'll never attend.</p>
      
      <h3>3. You make it too complex</h3>
      
      <p>"First we analyze your current funnel, then we optimize your lead magnets, then we implement an automated nurture sequence..." Stop. You lost them at "analyze".</p>
      
      <p>Complexity is the enemy of conversion. The more complicated you make your approach sound, the fewer people dare to start.</p>
      
      <p><strong>The solution:</strong> Keep it simple. "We make sure you get more customers" is better than explaining your 47-step process.</p>
      
      <h3>4. You're hunting everyone</h3>
      
      <p>"Suitable for all entrepreneurs", "For everyone who wants more customers", "Perfect for every industry". This sounds inclusive, but works counterproductively.</p>
      
      <p>If your approach is for everyone, it's truly relevant to no one. Your customer wants to feel seen, not as part of a large group.</p>
      
      <p><strong>The solution:</strong> Choose a specific target group and address them directly. "For coaches struggling with LinkedIn" works better than "For everyone wanting to grow online".</p>
      
      <h3>5. You forget the emotion</h3>
      
      <p>Facts and figures are important, but people buy on emotion. They want to feel safe, successful, at ease. Your marketing must appeal to those feelings.</p>
      
      <p>Instead of "We increase your conversion by 40%" you could say "Imagine: new customers every day, without you having to invest time in it".</p>
      
      <h3>Making the shift</h3>
      
      <p>Marketing that works does the opposite of what most entrepreneurs do:</p>
      
      <ul>
        <li>It starts with their problem, not your solution</li>
        <li>It makes things simpler, not more complex</li>
        <li>It speaks to specific people, not everyone</li>
        <li>It touches emotions, not just logic</li>
        <li>It provides clarity, not information overload</li>
      </ul>
      
      <p>Look at your current marketing. Do you recognize these mistakes? Then it's time for a different approach. An approach that attracts customers instead of scaring them away.</p>
      
      <p>Because the difference between marketing that works and marketing that doesn't often lies in the details. Details that make your customers stop... or keep clicking.</p>
    `
  },
  "wat-kost-het-je-om-geen-funnel-te-hebben": {
    nl: `
      <h2>De verborgen kosten van geen funnel hebben</h2>
      
      <p>Je denkt misschien: "Een funnel? Dat is toch gewoon marketing jargon?" Maar wat als ik je vertel dat het ontbreken van een funnel je elke maand duizenden euro's kost? Niet in uitgaven, maar in gemiste kansen.</p>
      
      <p>Laten we eerlijk zijn: je krijgt al leads binnen. Mensen bezoeken je website, vullen soms een contactformulier in, of reageren op je LinkedIn posts. Maar hoeveel van die mensen worden daadwerkelijk klant? En hoeveel verdwijnen voorgoed?</p>
      
      <h3>De realiteit zonder funnel</h3>
      
      <p>Zonder een goed werkende funnel gebeurt dit:</p>
      
      <p><strong>90% van je leads verdwijnt:</strong> Iemand bezoekt je website, vindt het interessant, maar heeft nog geen direct probleem. Ze gaan weg en vergeten je. Voor altijd.</p>
      
      <p><strong>Je verliest de timing:</strong> Van die 10% die contact opneemt, doen ze dat vaak op het verkeerde moment. Ze zijn nog niet klaar om te kopen, of ze hebben net een ander bureau ingeschakeld.</p>
      
      <p><strong>Je concurrenten pakken je leads af:</strong> Terwijl jij wacht tot ze terugkomen, werken zij met funnels die je potentiële klanten warm houden en op het juiste moment converteren.</p>
      
      <h3>Rekenvoorbeeld: wat kost dit je echt?</h3>
      
      <p>Laten we een praktijkvoorbeeld nemen. Stel je voor:</p>
      
      <ul>
        <li>Je website krijgt 200 bezoekers per maand</li>
        <li>2% wordt lead (4 mensen)</li>
        <li>Van die 4 wordt er 1 klant</li>
        <li>Gemiddelde klantwaarde: €3.000</li>
        <li>Maandelijkse omzet uit website: €3.000</li>
      </ul>
      
      <p>Nu stellen we een funnel in:</p>
      
      <ul>
        <li>Dezelfde 200 bezoekers</li>
        <li>15% wordt lead door een goede lead magnet (30 mensen)</li>
        <li>Door automatische opvolging en timing wordt 10% klant (3 mensen)</li>
        <li>Maandelijkse omzet: €9.000</li>
      </ul>
      
      <p><strong>Verschil: €6.000 per maand. €72.000 per jaar.</strong></p>
      
      <p>En dit is nog een conservatief voorbeeld. Veel van onze klanten zien hun conversie met 300-500% stijgen.</p>
      
      <h3>Maar het gaat om meer dan geld</h3>
      
      <p>Een funnel bespaart je ook tijd en stress:</p>
      
      <p><strong>Geen constante prospectie meer:</strong> In plaats van elke dag nieuwe leads te moeten zoeken, komen ze automatisch binnen.</p>
      
      <p><strong>Kwaliteitsgesprekken:</strong> Mensen die uit je funnel komen zijn al warm. Ze kennen je, vertrouwen je, en weten wat je doet.</p>
      
      <p><strong>Voorspelbare omzet:</strong> Je weet hoeveel leads er maandelijks binnenkomt, en dus hoeveel omzet je kunt verwachten.</p>
      
      <h3>De timing factor</h3>
      
      <p>Hier is iets wat veel ondernemers niet doorhebben: mensen kopen niet als jij wilt verkopen. Ze kopen als zij er klaar voor zijn.</p>
      
      <p>Zonder funnel mis je al die mensen die over 3, 6, of 12 maanden klaar zijn. Met een funnel blijf je top-of-mind tot het juiste moment daar is.</p>
      
      <h3>Wat doet een goede funnel?</h3>
      
      <p>Een effectieve funnel:</p>
      
      <ul>
        <li><strong>Vangt leads:</strong> Met een relevante lead magnet die waarde biedt</li>
        <li><strong>Bouwt vertrouwen:</strong> Door consistente, waardevolle content</li>
        <li><strong>Houdt timing bij:</strong> Door te volgen waar mensen in hun koopproces zitten</li>
        <li><strong>Converteert automatisch:</strong> Op het moment dat mensen klaar zijn</li>
        <li><strong>Blijft werken:</strong> Ook als jij slaapt, op vakantie bent, of ziek bent</li>
      </ul>
      
      <h3>De echte vraag</h3>
      
      <p>De vraag is niet of je een funnel nodig hebt. De vraag is: kun je het je veroorloven om er nog langer geen te hebben?</p>
      
      <p>Elke maand zonder funnel is een maand waarin je geld op tafel laat liggen. Waarin je concurrenten sterker worden. Waarin je meer tijd besteedt aan prospectie in plaats van aan je vak.</p>
      
      <p>Het goede nieuws? Een funnel hoeft niet complex te zijn. Vaak is simpeler beter. En de ROI is bijna altijd positief binnen 30-60 dagen.</p>
      
      <p>Dus de volgende keer dat je twijfelt of je een funnel nodig hebt, denk dan aan die €72.000 per jaar. En vraag jezelf af: wat zou jij met dat geld doen?</p>
    `,
    en: `
      <h2>The hidden costs of not having a funnel</h2>
      
      <p>You might think: "A funnel? That's just marketing jargon, right?" But what if I told you that not having a funnel costs you thousands of euros every month? Not in expenses, but in missed opportunities.</p>
      
      <p>Let's be honest: you're already getting leads. People visit your website, sometimes fill out a contact form, or respond to your LinkedIn posts. But how many of those people actually become customers? And how many disappear forever?</p>
      
      <h3>The reality without a funnel</h3>
      
      <p>Without a well-functioning funnel, this happens:</p>
      
      <p><strong>90% of your leads disappear:</strong> Someone visits your website, finds it interesting, but doesn't have an immediate problem. They leave and forget you. Forever.</p>
      
      <p><strong>You lose the timing:</strong> Of the 10% who do make contact, they often do so at the wrong time. They're not ready to buy yet, or they just hired another agency.</p>
      
      <p><strong>Your competitors steal your leads:</strong> While you're waiting for them to come back, they're working with funnels that keep your potential customers warm and convert them at the right moment.</p>
      
      <h3>Example calculation: what does this really cost you?</h3>
      
      <p>Let's take a practical example. Imagine:</p>
      
      <ul>
        <li>Your website gets 200 visitors per month</li>
        <li>2% becomes a lead (4 people)</li>
        <li>Of those 4, 1 becomes a customer</li>
        <li>Average customer value: €3,000</li>
        <li>Monthly revenue from website: €3,000</li>
      </ul>
      
      <p>Now we set up a funnel:</p>
      
      <ul>
        <li>Same 200 visitors</li>
        <li>15% becomes a lead through a good lead magnet (30 people)</li>
        <li>Through automatic follow-up and timing, 10% becomes a customer (3 people)</li>
        <li>Monthly revenue: €9,000</li>
      </ul>
      
      <p><strong>Difference: €6,000 per month. €72,000 per year.</strong></p>
      
      <p>And this is still a conservative example. Many of our clients see their conversion increase by 300-500%.</p>
      
      <h3>But it's about more than money</h3>
      
      <p>A funnel also saves you time and stress:</p>
      
      <p><strong>No more constant prospecting:</strong> Instead of having to find new leads every day, they come in automatically.</p>
      
      <p><strong>Quality conversations:</strong> People coming from your funnel are already warm. They know you, trust you, and know what you do.</p>
      
      <p><strong>Predictable revenue:</strong> You know how many leads come in monthly, and thus how much revenue you can expect.</p>
      
      <h3>The timing factor</h3>
      
      <p>Here's something many entrepreneurs don't realize: people don't buy when you want to sell. They buy when they're ready.</p>
      
      <p>Without a funnel, you miss all those people who will be ready in 3, 6, or 12 months. With a funnel, you stay top-of-mind until the right moment arrives.</p>
      
      <h3>What does a good funnel do?</h3>
      
      <p>An effective funnel:</p>
      
      <ul>
        <li><strong>Captures leads:</strong> With a relevant lead magnet that provides value</li>
        <li><strong>Builds trust:</strong> Through consistent, valuable content</li>
        <li><strong>Tracks timing:</strong> By monitoring where people are in their buying process</li>
        <li><strong>Converts automatically:</strong> When people are ready</li>
        <li><strong>Keeps working:</strong> Even when you're sleeping, on vacation, or sick</li>
      </ul>
      
      <h3>The real question</h3>
      
      <p>The question isn't whether you need a funnel. The question is: can you afford not to have one any longer?</p>
      
      <p>Every month without a funnel is a month where you're leaving money on the table. Where your competitors get stronger. Where you spend more time prospecting instead of on your craft.</p>
      
      <p>The good news? A funnel doesn't have to be complex. Often simpler is better. And the ROI is almost always positive within 30-60 days.</p>
      
      <p>So next time you doubt whether you need a funnel, think about that €72,000 per year. And ask yourself: what would you do with that money?</p>
    `
  }
  // Add more blog content for other articles...
};
