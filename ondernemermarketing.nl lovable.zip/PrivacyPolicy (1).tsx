
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '@/contexts/LanguageContext';

const PrivacyPolicy = () => {
  const { language } = useLanguage();
  
  const content = {
    nl: {
      title: 'Privacy Policy',
      lastUpdated: 'Laatst bijgewerkt: December 2024',
      sections: [
        {
          title: '1. Algemene informatie',
          content: `
            <p>OndernemerMarketing.nl, gevestigd aan Breedveldsingel 1, 3055 PG Rotterdam, is verantwoordelijk voor de verwerking van persoonsgegevens zoals weergegeven in deze privacyverklaring.</p>
            <p><strong>Contactgegevens:</strong><br>
            E-mail: info@ondernemermarketing.nl<br>
            Telefoon: +31 6 1301 3266</p>
          `
        },
        {
          title: '2. Persoonsgegevens die wij verwerken',
          content: `
            <p>OndernemerMarketing.nl verwerkt persoonsgegevens van personen die:</p>
            <ul>
              <li>Gebruik maken van onze diensten</li>
              <li>Contact met ons opnemen</li>
              <li>Zich aanmelden voor onze nieuwsbrief</li>
              <li>Deelnemen aan evenementen of webinars</li>
            </ul>
            <p>De persoonsgegevens die wij verwerken zijn: naam, e-mailadres, telefoonnummer, bedrijfsnaam, IP-adres en overige gegevens die u actief verstrekt.</p>
          `
        },
        {
          title: '3. Doeleinden en rechtsgronden',
          content: `
            <p>Wij verwerken uw persoonsgegevens voor de volgende doeleinden:</p>
            <ul>
              <li>Het leveren van onze diensten</li>
              <li>Het beantwoorden van vragen en verzoeken</li>
              <li>Het versturen van marketingcommunicatie (alleen met toestemming)</li>
              <li>Het analyseren van websitegebruik ter verbetering</li>
            </ul>
          `
        },
        {
          title: '4. Cookies',
          content: `
            <p>OndernemerMarketing.nl gebruikt functionele, analytische en marketing cookies. Een cookie is een klein tekstbestand dat bij het eerste bezoek aan deze website wordt opgeslagen in de browser van uw computer, tablet of smartphone.</p>
            <p>U kunt zich afmelden voor cookies door uw internetbrowser zo in te stellen dat deze geen cookies meer opslaat. Daarnaast kunt u ook alle informatie die eerder is opgeslagen via de instellingen van uw browser verwijderen.</p>
          `
        },
        {
          title: '5. Beveiliging',
          content: `
            <p>Wij nemen de bescherming van uw gegevens serieus en nemen passende maatregelen om misbruik, verlies, onbevoegde toegang, ongewenste openbaarmaking en ongeoorloofde wijziging tegen te gaan.</p>
          `
        },
        {
          title: '6. Uw rechten',
          content: `
            <p>U heeft het recht om:</p>
            <ul>
              <li>Uw persoonsgegevens in te zien, te corrigeren of te verwijderen</li>
              <li>Uw toestemming voor de gegevensverwerking in te trekken</li>
              <li>Bezwaar te maken tegen de verwerking van uw persoonsgegevens</li>
              <li>Een klacht in te dienen bij de Autoriteit Persoonsgegevens</li>
            </ul>
          `
        },
        {
          title: '7. Contact',
          content: `
            <p>Als u vragen heeft over deze privacyverklaring of over de verwerking van uw persoonsgegevens, neem dan contact met ons op via info@ondernemermarketing.nl.</p>
          `
        }
      ]
    },
    en: {
      title: 'Privacy Policy',
      lastUpdated: 'Last updated: December 2024',
      sections: [
        {
          title: '1. General information',
          content: `
            <p>OndernemerMarketing.nl, located at Breedveldsingel 1, 3055 PG Rotterdam, is responsible for the processing of personal data as shown in this privacy statement.</p>
            <p><strong>Contact details:</strong><br>
            Email: info@ondernemermarketing.nl<br>
            Phone: +31 6 1301 3266</p>
          `
        },
        {
          title: '2. Personal data we process',
          content: `
            <p>OndernemerMarketing.nl processes personal data of persons who:</p>
            <ul>
              <li>Use our services</li>
              <li>Contact us</li>
              <li>Sign up for our newsletter</li>
              <li>Participate in events or webinars</li>
            </ul>
            <p>The personal data we process are: name, email address, phone number, company name, IP address and other data you actively provide.</p>
          `
        },
        {
          title: '3. Purposes and legal grounds',
          content: `
            <p>We process your personal data for the following purposes:</p>
            <ul>
              <li>Providing our services</li>
              <li>Answering questions and requests</li>
              <li>Sending marketing communications (only with consent)</li>
              <li>Analyzing website usage for improvement</li>
            </ul>
          `
        },
        {
          title: '4. Cookies',
          content: `
            <p>OndernemerMarketing.nl uses functional, analytical and marketing cookies. A cookie is a small text file that is stored in the browser of your computer, tablet or smartphone when you first visit this website.</p>
            <p>You can opt out of cookies by setting your internet browser so that it no longer stores cookies. In addition, you can also delete all information that was previously saved via your browser settings.</p>
          `
        },
        {
          title: '5. Security',
          content: `
            <p>We take the protection of your data seriously and take appropriate measures to prevent misuse, loss, unauthorized access, unwanted disclosure and unauthorized modification.</p>
          `
        },
        {
          title: '6. Your rights',
          content: `
            <p>You have the right to:</p>
            <ul>
              <li>View, correct or delete your personal data</li>
              <li>Withdraw your consent for data processing</li>
              <li>Object to the processing of your personal data</li>
              <li>File a complaint with the Dutch Data Protection Authority</li>
            </ul>
          `
        },
        {
          title: '7. Contact',
          content: `
            <p>If you have questions about this privacy statement or about the processing of your personal data, please contact us at info@ondernemermarketing.nl.</p>
          `
        }
      ]
    }
  };

  const { title, lastUpdated, sections } = content[language];

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-28">
        <section className="py-12 bg-gray-light">
          <div className="container mx-auto">
            <h1 className="text-center mb-2">{title}</h1>
            <p className="text-center text-gray-dark">{lastUpdated}</p>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container mx-auto max-w-4xl">
            {sections.map((section, index) => (
              <div key={index} className="mb-8">
                <h2 className="text-2xl font-bold text-primary-blue mb-4">{section.title}</h2>
                <div 
                  className="prose prose-lg max-w-none text-gray-dark"
                  dangerouslySetInnerHTML={{ __html: section.content }}
                />
              </div>
            ))}
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default PrivacyPolicy;
