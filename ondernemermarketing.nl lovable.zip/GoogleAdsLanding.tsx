import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowRight, Check, TrendingUp, Target, Users, Clock, Star, Shield, Phone, Mail } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

const GoogleAdsLanding = () => {
  const features = [
    {
      icon: Target,
      title: 'Doelgroep targeting',
      description: 'Bereik precies de juiste klanten op het juiste moment'
    },
    {
      icon: TrendingUp,
      title: 'Meetbare resultaten',
      description: 'Realtime inzicht in kosten per lead en conversies'
    },
    {
      icon: Clock,
      title: 'Snelle setup',
      description: 'Live binnen 7 dagen, geen gedoe met instellingen'
    },
    {
      icon: Users,
      title: 'Ervaren team',
      description: 'Google Ads specialisten met bewezen resultaten'
    }
  ];

  const testimonials = [
    {
      name: 'Mark van der Berg',
      company: 'VDB Installaties',
      text: 'Binnen 2 weken 15 nieuwe klanten. Eindelijk marketing die werkt.',
      rating: 5
    },
    {
      name: 'Sarah Jansen',
      company: 'Jansen Coaching',
      text: 'Van 0 naar 25 leads per maand. Beste investering ooit.',
      rating: 5
    },
    {
      name: 'Tom Hendriks',
      company: 'Hendriks Advies',
      text: 'Kosten per lead gehalveerd en kwaliteit omhoog. Top!',
      rating: 5
    }
  ];

  const kickstartFeatures = [
    'Keyword onderzoek & selectie',
    'Advertentie teksten schrijven',
    'Tracking & conversie setup',
    'Google Ads account inrichting',
    'Maandelijkse optimalisatie (1,5-2,5u)',
    'Maandrapportage via e-mail'
  ];

  const groeiFeatures = [
    'Alles uit Kickstart pakket',
    'Wekelijkse optimalisatie',
    'A/B testing van advertenties',
    'Landing page feedback',
    'Conversie dashboard',
    'Call tracking setup',
    'Uitgebreide rapportage',
    'Prioriteit support'
  ];

  return (
    <div className="min-h-screen bg-white">
      <SEO 
        title="Google Ads Uitbesteden - Meer Leads, Minder Stress | OndernemerMarketing"
        description="Wij regelen jouw Google Ads. Jij krijgt leads. Vanaf €450 setup + €250/maand. 7 dagen live, geen gedoe. Plan gratis intake."
        url="https://www.ondernemermarketing.nl/google-ads-uitbesteden"
      />

      {/* Hero Section */}
      <section className="py-20" style={{ backgroundColor: '#f6f7fb' }}>
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center">
            {/* Left Column - Text */}
            <div className="w-full lg:w-1/2 mb-10 lg:mb-0 pr-0 lg:pr-8">
              {/* Logo */}
              <div className="mb-8">
                <img 
                  src="/lovable-uploads/bf6accc4-838f-4f65-9b6a-1ef2f9fd9e46.png" 
                  alt="Ondernemermarketing.nl Logo" 
                  className="h-20 md:h-28 w-auto"
                  loading="eager"
                />
              </div>
              <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight text-gray-dark">
                Meer leads.<br />
                <span className="text-accent-orange">Minder marketing stress.</span>
              </h1>
              <p className="text-lg md:text-xl lg:text-2xl mb-8 max-w-3xl leading-relaxed text-gray-dark">
                Wij regelen jouw Google Ads compleet. Jij krijgt leads zonder gedoe met keywords, budgetten of optimalisaties.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-12">
                <Button asChild size="lg" className="bg-accent-orange hover:bg-accent-orange/90 text-white px-6 md:px-8 py-3 md:py-4 text-base md:text-lg">
                  <Link to="/contact">
                    Plan gratis intake <ArrowRight className="ml-2 h-4 md:h-5 w-4 md:w-5" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="border-primary-blue text-primary-blue hover:bg-primary-blue hover:text-white px-6 md:px-8 py-3 md:py-4 text-base md:text-lg">
                  <a href="#pakketten">
                    Bekijk pakketten
                  </a>
                </Button>
              </div>
            </div>

            {/* Right Column - Image */}
            <div className="w-full lg:w-1/2 relative">
              <div className="bg-white p-4 rounded-2xl shadow-lg">
                <img 
                  src="/lovable-uploads/cfaeade8-1f53-4306-b087-eb79af690f67.png"
                  alt="Professional woman working with phone and camera"
                  className="w-full rounded-lg"
                  loading="eager"
                />
                <div className="absolute -bottom-4 md:-bottom-6 -left-4 md:-left-6 bg-white p-3 md:p-4 rounded-lg shadow-lg border border-gray-200">
                  <p className="font-semibold text-primary-blue text-sm md:text-base">+287%</p>
                  <p className="text-xs md:text-sm text-gray-600">Meer leads</p>
                </div>
                <div className="absolute -top-4 md:-top-6 -right-4 md:-right-6 bg-white p-3 md:p-4 rounded-lg shadow-lg border border-gray-200">
                  <p className="font-semibold text-accent-orange text-sm md:text-base">-75%</p>
                  <p className="text-xs md:text-sm text-gray-600">Marketing tijd</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-12 md:py-16 bg-gray-light">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-8 text-gray-dark">
            Herken je dit?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 max-w-4xl mx-auto">
            <div className="bg-white p-4 md:p-6 rounded-xl shadow-md">
              <div className="text-3xl md:text-4xl mb-4">😤</div>
              <h3 className="font-bold mb-2 text-primary-blue">Google Ads is complex</h3>
              <p className="text-gray-dark text-sm md:text-base">Keywords, budgetten, biedstrategieën... waar begin je?</p>
            </div>
            <div className="bg-white p-4 md:p-6 rounded-xl shadow-md">
              <div className="text-3xl md:text-4xl mb-4">💸</div>
              <h3 className="font-bold mb-2 text-primary-blue">Geld weggooien</h3>
              <p className="text-gray-dark text-sm md:text-base">Advertentiebudget op zonder resultaat. Pijnlijk.</p>
            </div>
            <div className="bg-white p-4 md:p-6 rounded-xl shadow-md">
              <div className="text-3xl md:text-4xl mb-4">⏰</div>
              <h3 className="font-bold mb-2 text-primary-blue">Geen tijd</h3>
              <p className="text-gray-dark text-sm md:text-base">Dagelijks optimaliseren? Je hebt al geen tijd voor je bedrijf.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="py-12 md:py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-4 text-gray-dark">
              Wij regelen het. Jij krijgt leads.
            </h2>
            <p className="text-lg md:text-xl text-gray-dark max-w-3xl mx-auto">
              Geen cursussen, geen tools, geen gedoe. Gewoon resultaat.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="text-center">
                  <div className="bg-accent-orange/10 rounded-full w-12 h-12 md:w-16 md:h-16 flex items-center justify-center mx-auto mb-4">
                    <Icon className="h-6 w-6 md:h-8 md:w-8 text-accent-orange" />
                  </div>
                  <h3 className="font-bold mb-2 text-primary-blue text-sm md:text-base">{feature.title}</h3>
                  <p className="text-gray-dark text-sm">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Results Section */}
      <section className="py-12 md:py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-4 text-gray-dark">
              Bewezen resultaten
            </h2>
            <p className="text-lg md:text-xl text-gray-dark">
              Ondernemers die het uitbesteedden aan ons
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-12">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white">
                <CardContent className="p-4 md:p-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 md:h-5 md:w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-dark mb-4 italic text-sm md:text-base">"{testimonial.text}"</p>
                  <div>
                    <p className="font-bold text-primary-blue text-sm md:text-base">{testimonial.name}</p>
                    <p className="text-xs md:text-sm text-gray-600">{testimonial.company}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="bg-white rounded-xl p-6 md:p-8 max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 text-center">
              <div>
                <div className="text-3xl md:text-4xl font-bold text-primary-blue mb-2">150+</div>
                <p className="text-gray-dark text-sm md:text-base">Tevreden klanten</p>
              </div>
              <div>
                <div className="text-3xl md:text-4xl font-bold text-primary-blue mb-2">€2.1M</div>
                <p className="text-gray-dark text-sm md:text-base">Omzet gegenereerd</p>
              </div>
              <div>
                <div className="text-3xl md:text-4xl font-bold text-primary-blue mb-2">4.9/5</div>
                <p className="text-gray-dark text-sm md:text-base">Gemiddelde beoordeling</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pakketten" className="py-12 md:py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-4 text-gray-dark">
              Kies jouw pakket
            </h2>
            <p className="text-lg md:text-xl text-gray-dark">
              Transparante prijzen, geen verborgen kosten
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8 max-w-5xl mx-auto">
            {/* Kickstart Package */}
            <Card className="relative bg-white border-2 border-gray-200 hover:border-primary-blue transition-colors">
              <CardHeader className="text-center pb-6">
                <div className="bg-primary-blue text-white px-4 py-2 rounded-full text-sm font-medium inline-block mb-4">
                  Meest gekozen
                </div>
                <CardTitle className="text-xl md:text-2xl font-bold text-primary-blue">Google Ads Kickstart</CardTitle>
                <CardDescription className="text-gray-dark text-sm md:text-base">
                  Perfect om snel te starten met voorspelbare resultaten
                </CardDescription>
                <div className="mt-6">
                  <div className="text-3xl md:text-4xl font-bold text-primary-blue">€450</div>
                  <div className="text-xs md:text-sm text-gray-600 mb-2">eenmalige setup</div>
                  <div className="text-xl md:text-2xl font-bold text-accent-orange">€250/maand</div>
                  <div className="text-xs md:text-sm text-gray-600">maandelijks opzegbaar</div>
                  <div className="text-xs md:text-sm text-red-600 font-medium mt-2">
                    *Exclusief advertentiebudget
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-gray-light p-4 rounded-lg mb-6">
                  <p className="text-xs md:text-sm text-gray-dark">
                    <strong>Setup:</strong> Live binnen 7 dagen<br />
                    <strong>Optimalisatie:</strong> 1,5-2,5 uur per maand
                  </p>
                </div>
                {kickstartFeatures.map((feature, index) => (
                  <div key={index} className="flex items-center">
                    <Check className="h-4 w-4 md:h-5 md:w-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-gray-dark text-sm md:text-base">{feature}</span>
                  </div>
                ))}
                <div className="pt-6">
                  <Button asChild className="w-full bg-primary-blue hover:bg-primary-blue/90 text-white">
                    <Link to="/contact">
                      Start met Kickstart <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Groei Package */}
            <Card className="relative bg-white border-2 border-accent-orange hover:border-accent-orange/70 transition-colors">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <div className="bg-accent-orange text-white px-6 py-2 rounded-full text-sm font-medium">
                  Maximale groei
                </div>
              </div>
              <CardHeader className="text-center pb-6 pt-8">
                <CardTitle className="text-xl md:text-2xl font-bold text-primary-blue">Google Ads Groei Pack</CardTitle>
                <CardDescription className="text-gray-dark text-sm md:text-base">
                  Voor bedrijven die serieus willen groeien (budget €500-€2.000/maand)
                </CardDescription>
                <div className="mt-6">
                  <div className="text-3xl md:text-4xl font-bold text-accent-orange">€600/maand</div>
                  <div className="text-xs md:text-sm text-gray-600">alles inbegrepen</div>
                  <div className="text-xs md:text-sm text-red-600 font-medium mt-2">
                    *Exclusief advertentiebudget
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-accent-orange/5 p-4 rounded-lg mb-6 border border-accent-orange/20">
                  <p className="text-xs md:text-sm text-gray-dark">
                    <strong>Wekelijkse optimalisatie</strong><br />
                    Inclusief A/B testing en conversie-optimalisatie
                  </p>
                </div>
                {groeiFeatures.map((feature, index) => (
                  <div key={index} className="flex items-center">
                    <Check className="h-4 w-4 md:h-5 md:w-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-gray-dark text-sm md:text-base">{feature}</span>
                  </div>
                ))}
                <div className="pt-6">
                  <Button asChild className="w-full bg-accent-orange hover:bg-accent-orange/90 text-white">
                    <Link to="/contact">
                      Start met Groei Pack <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="text-center mt-8">
            <p className="text-gray-600 mb-4 text-sm md:text-base">Niet zeker welk pakket past bij jou?</p>
            <Button asChild variant="outline" size="lg" className="text-primary-blue border-primary-blue hover:bg-primary-blue hover:text-white">
              <Link to="/contact">
                Plan gratis adviesgesprek
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="py-12 md:py-16 bg-gray-light">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl font-bold mb-8 text-gray-dark">
              Waarom ondernemers voor ons kiezen
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            <div className="text-center">
              <Shield className="h-10 w-10 md:h-12 md:w-12 text-primary-blue mx-auto mb-4" />
              <h3 className="font-bold mb-2 text-primary-blue text-sm md:text-base">Google Partner</h3>
              <p className="text-gray-dark text-sm">Gecertificeerd Google Ads Partner met bewezen expertise</p>
            </div>
            <div className="text-center">
              <Phone className="h-10 w-10 md:h-12 md:w-12 text-primary-blue mx-auto mb-4" />
              <h3 className="font-bold mb-2 text-primary-blue text-sm md:text-base">Nederlandse support</h3>
              <p className="text-gray-dark text-sm">Bereikbaar via telefoon, WhatsApp en e-mail</p>
            </div>
            <div className="text-center">
              <TrendingUp className="h-10 w-10 md:h-12 md:w-12 text-primary-blue mx-auto mb-4" />
              <h3 className="font-bold mb-2 text-primary-blue text-sm md:text-base">Geen lange contracten</h3>
              <p className="text-gray-dark text-sm">Maandelijks opzegbaar, resultaten vanaf dag 1</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-12 md:py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold mb-12 text-center text-gray-dark">
            Veelgestelde vragen
          </h2>
          
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="bg-gray-light p-4 md:p-6 rounded-xl">
              <h3 className="font-bold mb-2 text-primary-blue text-sm md:text-base">Hoe snel zie ik resultaten?</h3>
              <p className="text-gray-dark text-sm md:text-base">Je advertenties staan live binnen 7 dagen. De eerste leads kun je binnen 48 uur verwachten, afhankelijk van je markt en budget.</p>
            </div>
            <div className="bg-gray-light p-4 md:p-6 rounded-xl">
              <h3 className="font-bold mb-2 text-primary-blue text-sm md:text-base">Wat als ik niet tevreden ben?</h3>
              <p className="text-gray-dark text-sm md:text-base">Je kunt maandelijks opzeggen. Geen lange contracten, geen gedoe. Wel verwachten we minimaal 3 maanden om optimale resultaten te behalen.</p>
            </div>
            <div className="bg-gray-light p-4 md:p-6 rounded-xl">
              <h3 className="font-bold mb-2 text-primary-blue text-sm md:text-base">Hoeveel advertentiebudget heb ik nodig?</h3>
              <p className="text-gray-dark text-sm md:text-base">Voor Kickstart minimaal €300/maand. Voor Groei Pack minimaal €500/maand. Dit is naast onze maandelijkse kosten.</p>
            </div>
            <div className="bg-gray-light p-4 md:p-6 rounded-xl">
              <h3 className="font-bold mb-2 text-primary-blue text-sm md:text-base">Krijg ik inzicht in de resultaten?</h3>
              <p className="text-gray-dark text-sm md:text-base">Ja! Je krijgt maandelijks een duidelijk rapport met kosten per lead, conversies en ROI. Bij Groei Pack ook realtime dashboard toegang.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-12 md:py-16 bg-gradient-to-br from-primary-blue to-primary-teal text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-6">
            Stop met geld weggooien aan slechte advertenties
          </h2>
          <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto">
            Laat ons je Google Ads regelen. Jij focust op je klanten, wij zorgen voor nieuwe leads.
          </p>
          <div className="bg-accent-orange/20 backdrop-blur-sm rounded-xl p-4 md:p-6 max-w-md mx-auto mb-8">
            <p className="text-base md:text-lg font-semibold mb-2">⚠️ Beperkt aantal plekken</p>
            <p className="text-xs md:text-sm opacity-90">We nemen slechts 5 nieuwe klanten per maand aan om kwaliteit te garanderen</p>
          </div>
          <Button asChild size="lg" className="bg-accent-orange hover:bg-accent-orange/90 text-white px-6 md:px-8 py-3 md:py-4 text-base md:text-lg">
            <Link to="/contact">
              Claim jouw plek - Plan gratis intake <ArrowRight className="ml-2 h-4 w-4 md:h-5 md:w-5" />
            </Link>
          </Button>
          <p className="text-xs md:text-sm mt-4 opacity-75">Gratis intake gesprek • Geen verplichtingen</p>
        </div>
      </section>

      {/* Contact Info */}
      <section className="py-6 md:py-8 bg-gray-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <div className="flex flex-col md:flex-row justify-center items-center gap-4 md:gap-6">
            <div className="flex items-center">
              <Phone className="h-4 w-4 md:h-5 md:w-5 mr-2" />
              <span className="text-sm md:text-base">+31 6 1301 3266</span>
            </div>
            <div className="flex items-center">
              <Mail className="h-4 w-4 md:h-5 md:w-5 mr-2" />
              <span className="text-sm md:text-base">info@ondernemermarketing.nl</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default GoogleAdsLanding;
