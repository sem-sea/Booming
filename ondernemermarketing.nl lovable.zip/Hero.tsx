
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface HeroProps {
  language?: 'nl' | 'en';
}

const Hero = ({ language = 'nl' }: HeroProps) => {
  const content = {
    nl: {
      title: 'Je wilt klanten. \n\n\n\nNiet leren marketen.',
      subtitle: 'Wij regelen je marketing. Jij onderneemt.',
      description: 'Geen marketinggedoe, maar een voorspelbare stroom aan klanten. Laat ons jouw marketing regelen terwijl jij doet waar je goed in bent.',
      primaryCta: 'Plan gratis intake',
      secondaryCta: 'Bereken Je Potentieel',
    },
    en: {
      title: 'You want customers. Not marketing lessons.',
      subtitle: 'We handle your marketing. You run your business.',
      description: 'No marketing hassle, just a predictable flow of customers. Let us handle your marketing while you focus on what you do best.',
      primaryCta: 'Plan gratis intake',
      secondaryCta: 'Calculate Your Potential',
    }
  };

  const { title, subtitle, description, primaryCta, secondaryCta } = content[language];

  return (
    <section className="pt-28 pb-16 md:pt-36 md:pb-24 bg-gray-light overflow-hidden">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row items-center">
          {/* Left Column - Text */}
          <div className="w-full md:w-1/2 mb-10 md:mb-0 pr-0 md:pr-8 animate-fade-in">
            <h1 className="mb-4 text-gray-dark">
              <span className="text-primary-blue">{title}</span>
            </h1>
            <h2 className="text-xl md:text-2xl font-bold mb-6 text-accent-orange">
              {subtitle}
            </h2>
            <p className="mb-8 text-gray-dark max-w-xl">
              {description}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild className="primary-cta">
                <Link to="/contact">
                  {primaryCta} <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outline" className="secondary-cta">
                <Link to="/calculator">
                  {secondaryCta}
                </Link>
              </Button>
            </div>
          </div>

          {/* Right Column - Image */}
          <div className="w-full md:w-1/2 relative animate-fade-in">
            <div className="bg-white p-4 rounded-2xl shadow-lg">
              <img 
                src="/lovable-uploads/57623f4c-b048-4084-ab9b-a2c896628472.png" 
                alt="Marketing resultaten" 
                className="w-full rounded-lg"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-lg shadow-lg border border-gray-medium">
                <p className="font-semibold text-primary-blue">+287%</p>
                <p className="text-sm text-gray-dark">Meer leads</p>
              </div>
              <div className="absolute -top-6 -right-6 bg-white p-4 rounded-lg shadow-lg border border-gray-medium">
                <p className="font-semibold text-accent-orange">-32%</p>
                <p className="text-sm text-gray-dark">Marketing tijd</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
