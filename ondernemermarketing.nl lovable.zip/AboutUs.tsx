
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';

const AboutUs = () => {
  const { language } = useLanguage();
  
  const content = {
    nl: {
      title: 'Over Ons',
      subtitle: 'Wij zijn OndernemerMarketing',
      story: {
        title: 'Ons verhaal',
        paragraphs: [
          'OndernemerMarketing is opgericht uit frustratie. Frustratie over marketingbureaus die ingewikkelde strategieën verkopen en ondernemers opzadelen met marketingtaken die ze niet willen doen.',
          'Als ondernemer wil je klanten, geen marketingcursus. Je wilt resultaten, geen eindeloze contentkalenders die je zelf moet invullen. En je wilt zekerheid, geen experimenteel "maar eens kijken of het werkt".',
          'Daarom doen wij het anders. Wij nemen de volledige marketing van je over en zorgen voor voorspelbare klantengroei. Geen losse flodders, maar een compleet systeem dat werkt.'
        ]
      },
      mission: {
        title: 'Onze missie',
        text: 'Ondernemers bevrijden van marketinggedoe en hen helpen om meer impact te maken met hun bedrijf door het leveren van een voorspelbare stroom aan ideale klanten.'
      },
      team: {
        title: 'Ons team',
        subtitle: 'De mensen achter OndernemerMarketing',
        founder: {
          name: 'Ben Verschuur',
          role: 'Oprichter & Strateeg',
          bio: 'Met 15 jaar ervaring in digitale marketing heeft Ben vele ondernemers geholpen met het bouwen van effectieve marketingsystemen.',
          image: '/lovable-uploads/661b2283-e739-49d1-b6c1-e9ab25830098.png'
        }
      },
      values: {
        title: 'Onze waarden',
        list: [
          {
            title: 'Resultaatgericht',
            description: 'We meten alles en sturen constant bij op basis van data, niet op basis van onderbuikgevoel.'
          },
          {
            title: 'Eerlijkheid',
            description: 'We beloven alleen wat we kunnen waarmaken en zijn transparant over verwachtingen en resultaten.'
          },
          {
            title: 'Ownership',
            description: 'We nemen verantwoordelijkheid voor het succes van onze klanten en doen wat nodig is om resultaten te behalen.'
          },
          {
            title: 'Eenvoud',
            description: 'We maken marketing simpel en begrijpelijk, zonder jargon of onnodige complexiteit.'
          }
        ]
      },
      cta: {
        title: 'Klaar om marketing uit te besteden?',
        button: 'Plan een gratis intake gesprek'
      }
    },
    en: {
      title: 'About Us',
      subtitle: 'We are OndernemerMarketing',
      story: {
        title: 'Our story',
        paragraphs: [
          'OndernemerMarketing was founded out of frustration. Frustration with marketing agencies that sell complicated strategies and burden entrepreneurs with marketing tasks they don\'t want to do.',
          'As an entrepreneur, you want customers, not a marketing course. You want results, not endless content calendars that you have to fill in yourself. And you want certainty, not experimental "let\'s see if it works".',
          'That\'s why we do things differently. We take over your entire marketing and ensure predictable customer growth. No scattered efforts, but a complete system that works.'
        ]
      },
      mission: {
        title: 'Our mission',
        text: 'To free entrepreneurs from marketing hassle and help them make more impact with their business by delivering a predictable flow of ideal customers.'
      },
      team: {
        title: 'Our team',
        subtitle: 'The people behind OndernemerMarketing',
        founder: {
          name: 'Ben Verschuur',
          role: 'Founder & Strategist',
          bio: 'With 15 years of experience in digital marketing, Ben has helped hundreds of entrepreneurs build effective marketing systems.',
          image: '/lovable-uploads/661b2283-e739-49d1-b6c1-e9ab25830098.png'
        }
      },
      values: {
        title: 'Our values',
        list: [
          {
            title: 'Results-driven',
            description: 'We measure everything and constantly adjust based on data, not on gut feeling.'
          },
          {
            title: 'Honesty',
            description: 'We only promise what we can deliver and are transparent about expectations and results.'
          },
          {
            title: 'Ownership',
            description: 'We take responsibility for our clients\' success and do what it takes to achieve results.'
          },
          {
            title: 'Simplicity',
            description: 'We make marketing simple and understandable, without jargon or unnecessary complexity.'
          }
        ]
      },
      cta: {
        title: 'Ready to outsource marketing?',
        button: 'Schedule a free intake call'
      }
    }
  };
  
  const { title, subtitle, story, mission, team, values, cta } = content[language];
  
  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-28">
        {/* Hero Section */}
        <section className="py-12 md:py-20 bg-gray-light">
          <div className="container mx-auto text-center">
            <h1 className="mb-4">{title}</h1>
            <h2 className="text-xl md:text-2xl font-bold mb-8 text-primary-blue">{subtitle}</h2>
            <div className="max-w-4xl mx-auto">
              <img src="/lovable-uploads/1e5f3aed-6ac5-4346-bdf9-f26f7e5be761.png" alt="Team OndernemerMarketing" className="rounded-xl w-full h-64 md:h-96 object-cover shadow-lg" />
            </div>
          </div>
        </section>
        
        {/* Story Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto">
            <div className="max-w-3xl mx-auto">
              <h2 className="mb-8">{story.title}</h2>
              {story.paragraphs.map((paragraph, index) => (
                <p key={index} className="mb-6 text-gray-dark">{paragraph}</p>
              ))}
            </div>
          </div>
        </section>
        
        {/* Mission Section */}
        <section className="py-16 bg-gray-light">
          <div className="container mx-auto text-center">
            <h2 className="mb-6">{mission.title}</h2>
            <p className="text-xl max-w-3xl mx-auto">{mission.text}</p>
          </div>
        </section>
        
        {/* Team Section - Only Founder */}
        <section className="py-16 bg-white">
          <div className="container mx-auto">
            <h2 className="mb-4 text-center">{team.title}</h2>
            <p className="text-center mb-12 text-gray-dark">{team.subtitle}</p>
            
            {/* Founder Section */}
            <div className="text-center">
              <div className="rounded-full overflow-hidden w-48 h-48 mx-auto mb-4">
                <img src={team.founder.image} alt={team.founder.name} className="w-full h-full object-cover" />
              </div>
              <h3 className="text-2xl font-bold mb-1 text-primary-blue">{team.founder.name}</h3>
              <p className="text-accent-orange font-medium mb-3 text-lg">{team.founder.role}</p>
              <p className="text-gray-dark max-w-2xl mx-auto">{team.founder.bio}</p>
            </div>
          </div>
        </section>
        
        {/* Values Section */}
        <section className="py-16 bg-gray-light">
          <div className="container mx-auto">
            <h2 className="mb-12 text-center">{values.title}</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.list.map((value, index) => (
                <div key={index} className="bg-white p-6 rounded-xl shadow-md">
                  <h3 className="text-lg font-bold mb-3 text-primary-blue">{value.title}</h3>
                  <p className="text-gray-dark">{value.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto text-center">
            <h2 className="mb-8">{cta.title}</h2>
            <Button asChild className="primary-cta">
              <Link to="/contact">
                {cta.button} <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default AboutUs;
