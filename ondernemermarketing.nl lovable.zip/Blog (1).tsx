import React, { useState } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import CallButton from '../components/CallButton';
import BlogArticle from '../components/BlogArticle';
import SEO from '../components/SEO';
import { Button } from '@/components/ui/button';
import { ArrowRight, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Link, useParams } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { blogContent } from '@/data/blogContent';

const Blog = () => {
  const { language } = useLanguage();
  const { slug } = useParams();
  const [searchTerm, setSearchTerm] = useState('');
  
  const content = {
    nl: {
      title: 'Blog',
      subtitle: 'Marketing inzichten voor ondernemers',
      description: 'Praktische tips, cases en inzichten om jouw marketing naar een hoger niveau te tillen.',
      searchPlaceholder: 'Zoek artikelen...',
      categories: ['Alle artikelen', 'Funnels', 'Content Marketing', 'SEO', 'Leads', 'Adverteren'],
      latestArticles: 'Nieuwste artikelen',
      popularArticles: 'Meest gelezen',
      readMore: 'Lees meer',
      noResults: 'Geen artikelen gevonden. Probeer een andere zoekopdracht.',
      subscribe: {
        title: 'Ontvang nieuwe inzichten',
        description: 'Meld je aan voor onze nieuwsbrief en ontvang praktische marketingtips in je inbox.',
        placeholder: 'Jouw e-mailadres',
        button: 'Aanmelden'
      }
    },
    en: {
      title: 'Blog',
      subtitle: 'Marketing insights for entrepreneurs',
      description: 'Practical tips, cases, and insights to take your marketing to the next level.',
      searchPlaceholder: 'Search articles...',
      categories: ['All articles', 'Funnels', 'Content Marketing', 'SEO', 'Leads', 'Advertising'],
      latestArticles: 'Latest articles',
      popularArticles: 'Most popular',
      readMore: 'Read more',
      noResults: 'No articles found. Try a different search.',
      subscribe: {
        title: 'Get new insights',
        description: 'Sign up for our newsletter and receive practical marketing tips in your inbox.',
        placeholder: 'Your email address',
        button: 'Subscribe'
      }
    }
  };
  
  const { title, subtitle, description, searchPlaceholder, categories, latestArticles, readMore, subscribe } = content[language];
  
  // Sample blog posts with updated dates to May 2025
  const blogPosts = [
    {
      id: 1,
      title: {
        nl: 'Waarom je marketing je nu klanten kost (in plaats van oplevert)',
        en: 'Why your marketing is costing you customers (instead of delivering them)'
      },
      excerpt: {
        nl: 'Ontdek waarom je huidige marketingaanpak mogelijk meer kwaad dan goed doet en hoe je dit kunt omkeren.',
        en: 'Discover why your current marketing approach might be doing more harm than good and how to turn this around.'
      },
      content: {
        nl: blogContent["waarom-je-marketing-je-nu-klanten-kost"]?.nl || '<p>Content wordt binnenkort toegevoegd.</p>',
        en: blogContent["waarom-je-marketing-je-nu-klanten-kost"]?.en || '<p>Content coming soon.</p>'
      },
      image: '/lovable-uploads/3a5b5085-513f-4587-8e42-b13eee3cde80.png',
      category: {
        nl: 'Strategie',
        en: 'Strategy'
      },
      date: {
        nl: '15 mei 2025',
        en: 'May 15, 2025'
      },
      slug: 'waarom-je-marketing-je-nu-klanten-kost',
      author: 'Ben van Ondernemermarketing.nl',
      readingTime: 8
    },
    {
      id: 2,
      title: {
        nl: 'Wat kost het je om géén funnel te hebben?',
        en: 'What does it cost you to not have a funnel?'
      },
      excerpt: {
        nl: 'Bereken de werkelijke kosten van gemiste kansen door het ontbreken van een effectieve marketingfunnel.',
        en: 'Calculate the real costs of missed opportunities due to the lack of an effective marketing funnel.'
      },
      content: {
        nl: blogContent["wat-kost-het-je-om-geen-funnel-te-hebben"]?.nl || '<p>Content wordt binnenkort toegevoegd.</p>',
        en: blogContent["wat-kost-het-je-om-geen-funnel-te-hebben"]?.en || '<p>Content coming soon.</p>'
      },
      image: '/lovable-uploads/4aa69807-6024-4c17-be50-0a6bd7f3cfb9.png',
      category: {
        nl: 'ROI',
        en: 'ROI'
      },
      date: {
        nl: '10 mei 2025',
        en: 'May 10, 2025'
      },
      slug: 'wat-kost-het-je-om-geen-funnel-te-hebben',
      author: 'Ben van Ondernemermarketing.nl',
      readingTime: 7
    },
    {
      id: 3,
      title: {
        nl: '5 signalen dat je klaar bent om je marketing uit te besteden',
        en: '5 signs you\'re ready to outsource your marketing'
      },
      excerpt: {
        nl: 'Herken je deze signalen? Dan is het mogelijk tijd om je marketing uit te besteden aan professionals.',
        en: 'Recognize these signals? Then it might be time to outsource your marketing to professionals.'
      },
      content: {
        nl: blogContent["5-signalen-dat-je-klaar-bent-voor-uitbesteden"]?.nl || '<p>Content wordt binnenkort toegevoegd.</p>',
        en: blogContent["5-signalen-dat-je-klaar-bent-voor-uitbesteden"]?.en || '<p>Content coming soon.</p>'
      },
      image: '/lovable-uploads/1e5f3aed-6ac5-4346-bdf9-f26f7e5be761.png',
      category: {
        nl: 'Strategie',
        en: 'Strategy'
      },
      date: {
        nl: '5 mei 2025',
        en: 'May 5, 2025'
      },
      slug: '5-signalen-dat-je-klaar-bent-voor-uitbesteden',
      author: 'Ben van Ondernemermarketing.nl',
      readingTime: 6
    },
    {
      id: 4,
      title: {
        nl: 'Waarom je LinkedIn-profiel geen klanten oplevert (en hoe je dat wél fixt)',
        en: 'Why your LinkedIn profile isn\'t delivering customers (and how to fix it)'
      },
      excerpt: {
        nl: 'Transformeer je LinkedIn-profiel van een digitaal visitekaartje naar een krachtige lead generator.',
        en: 'Transform your LinkedIn profile from a digital business card into a powerful lead generator.'
      },
      content: {
        nl: blogContent["waarom-je-linkedin-profiel-geen-klanten-oplevert"]?.nl || '<p>Content wordt binnenkort toegevoegd.</p>',
        en: blogContent["waarom-je-linkedin-profiel-geen-klanten-oplevert"]?.en || '<p>Content coming soon.</p>'
      },
      image: '/lovable-uploads/8cd60c1b-0323-4872-bf95-8063f71492ee.png',
      category: {
        nl: 'Social Media',
        en: 'Social Media'
      },
      date: {
        nl: '1 mei 2025',
        en: 'May 1, 2025'
      },
      slug: 'waarom-je-linkedin-profiel-geen-klanten-oplevert',
      author: 'Ben van Ondernemermarketing.nl',
      readingTime: 5
    },
    {
      id: 5,
      title: {
        nl: 'Marketing uitbesteden: wat levert het op?',
        en: 'Outsourcing marketing: what does it deliver?'
      },
      excerpt: {
        nl: 'Ontdek de concrete voordelen van het uitbesteden van je marketing en wat je kunt verwachten.',
        en: 'Discover the concrete benefits of outsourcing your marketing and what you can expect.'
      },
      content: {
        nl: blogContent["marketing-uitbesteden-wat-levert-het-op"]?.nl || '<p>Content wordt binnenkort toegevoegd.</p>',
        en: blogContent["marketing-uitbesteden-wat-levert-het-op"]?.en || '<p>Content coming soon.</p>'
      },
      image: '/lovable-uploads/12f5314d-f5e2-4038-8fde-5c5ab0bef4b8.png',
      category: {
        nl: 'ROI',
        en: 'ROI'
      },
      date: {
        nl: '28 mei 2025',
        en: 'May 28, 2025'
      },
      slug: 'marketing-uitbesteden-wat-levert-het-op',
      author: 'Ben van Ondernemermarketing.nl',
      readingTime: 8
    },
    {
      id: 6,
      title: {
        nl: 'Van losse flodders naar een marketingmachine in 3 stappen',
        en: 'From scattered efforts to a marketing machine in 3 steps'
      },
      excerpt: {
        nl: 'Leer hoe je van willekeurige marketingacties naar een gestructureerde aanpak gaat die resultaten levert.',
        en: 'Learn how to go from random marketing actions to a structured approach that delivers results.'
      },
      content: {
        nl: blogContent["van-losse-flodders-naar-een-marketingmachine"]?.nl || '<p>Content wordt binnenkort toegevoegd.</p>',
        en: blogContent["van-losse-flodders-naar-een-marketingmachine"]?.en || '<p>Content coming soon.</p>'
      },
      image: '/lovable-uploads/0970519e-7452-40f9-830d-5c8bca26f492.png',
      category: {
        nl: 'Strategie',
        en: 'Strategy'
      },
      date: {
        nl: '24 mei 2025',
        en: 'May 24, 2025'
      },
      slug: 'van-losse-flodders-naar-een-marketingmachine',
      author: 'Ben van Ondernemermarketing.nl',
      readingTime: 7
    },
    {
      id: 7,
      title: {
        nl: 'Case: van geen klanten naar 4 aanvragen per week',
        en: 'Case: from no customers to 4 inquiries per week'
      },
      excerpt: {
        nl: 'Bekijk hoe deze ondernemer zijn klantenflow compleet transformeerde met de juiste marketingstrategie.',
        en: 'See how this entrepreneur completely transformed his customer flow with the right marketing strategy.'
      },
      content: {
        nl: blogContent["case-van-geen-klanten-naar-4-aanvragen-per-week"]?.nl || '<p>Content wordt binnenkort toegevoegd.</p>',
        en: blogContent["case-van-geen-klanten-naar-4-aanvragen-per-week"]?.en || '<p>Content coming soon.</p>'
      },
      image: '/lovable-uploads/57623f4c-b048-4084-ab9b-a2c896628472.png',
      category: {
        nl: 'Case Studies',
        en: 'Case Studies'
      },
      date: {
        nl: '20 mei 2025',
        en: 'May 20, 2025'
      },
      slug: 'case-van-geen-klanten-naar-4-aanvragen-per-week',
      author: 'Ben van Ondernemermarketing.nl',
      readingTime: 6
    },
    {
      id: 8,
      title: {
        nl: 'Hoe jij meer klanten krijgt zonder zichtbaarheidspush',
        en: 'How you get more customers without visibility push'
      },
      excerpt: {
        nl: 'Voor introverten en iedereen die moe is van constant posten: zo krijg je klanten zonder zichtbaarheidsdruk.',
        en: 'For introverts and everyone tired of constant posting: how to get customers without visibility pressure.'
      },
      content: {
        nl: blogContent["hoe-jij-meer-klanten-krijgt-zonder-zichtbaarheidspush"]?.nl || '<p>Content wordt binnenkort toegevoegd.</p>',
        en: blogContent["hoe-jij-meer-klanten-krijgt-zonder-zichtbaarheidspush"]?.en || '<p>Content coming soon.</p>'
      },
      image: '/lovable-uploads/661b2283-e739-49d1-b6c1-e9ab25830098.png',
      category: {
        nl: 'Leads',
        en: 'Leads'
      },
      date: {
        nl: '16 mei 2025',
        en: 'May 16, 2025'
      },
      slug: 'hoe-jij-meer-klanten-krijgt-zonder-zichtbaarheidspush',
      author: 'Ben van Ondernemermarketing.nl',
      readingTime: 5
    },
    {
      id: 9,
      title: {
        nl: 'Wat goede funnels doen — en waarom jij er (nog) geen hebt',
        en: 'What good funnels do — and why you don\'t have one (yet)'
      },
      excerpt: {
        nl: 'Begrijp eindelijk wat een funnel werkelijk doet en waarom de meeste ondernemers er nog geen hebben.',
        en: 'Finally understand what a funnel really does and why most entrepreneurs don\'t have one yet.'
      },
      content: {
        nl: blogContent["wat-goede-funnels-doen-en-waarom-jij-er-nog-geen-hebt"]?.nl || '<p>Content wordt binnenkort toegevoegd.</p>',
        en: blogContent["wat-goede-funnels-doen-en-waarom-jij-er-nog-geen-hebt"]?.en || '<p>Content coming soon.</p>'
      },
      image: '/lovable-uploads/25760631-bfda-4d0f-bc20-48d12080b806.png',
      category: {
        nl: 'Funnels',
        en: 'Funnels'
      },
      date: {
        nl: '12 mei 2025',
        en: 'May 12, 2025'
      },
      slug: 'wat-goede-funnels-doen-en-waarom-jij-er-nog-geen-hebt',
      author: 'Ben van Ondernemermarketing.nl',
      readingTime: 6
    },
    {
      id: 10,
      title: {
        nl: 'De echte reden waarom je website geen klanten oplevert',
        en: 'The real reason why your website isn\'t delivering customers'
      },
      excerpt: {
        nl: 'Het probleem zit niet in het design van je website, maar in iets veel fundamentelers. Ontdek wat.',
        en: 'The problem isn\'t in your website\'s design, but in something much more fundamental. Discover what.'
      },
      content: {
        nl: blogContent["de-echte-reden-waarom-je-website-geen-klanten-oplevert"]?.nl || '<p>Content wordt binnenkort toegevoegd.</p>',
        en: blogContent["de-echte-reden-waarom-je-website-geen-klanten-oplevert"]?.en || '<p>Content coming soon.</p>'
      },
      image: '/lovable-uploads/bf6accc4-838f-4f65-9b6a-1ef2f9fd9e46.png',
      category: {
        nl: 'Conversie',
        en: 'Conversion'
      },
      date: {
        nl: '8 mei 2025',
        en: 'May 8, 2025'
      },
      slug: 'de-echte-reden-waarom-je-website-geen-klanten-oplevert',
      author: 'Ben van Ondernemermarketing.nl',
      readingTime: 7
    }
  ];

  // If we have a slug, show individual blog post
  if (slug) {
    const post = blogPosts.find(p => p.slug === slug);
    
    if (!post) {
      return (
        <div className="min-h-screen">
          <SEO 
            title="Blog post niet gevonden | Ondernemermarketing.nl"
            description="Deze blog post bestaat niet of is verplaatst."
            noindex={true}
          />
          <Header />
          <CallButton />
          <main className="pt-28">
            <div className="container mx-auto py-16">
              <h1 className="text-2xl font-bold mb-4">Blog post niet gevonden</h1>
              <p className="mb-6">Deze blog post bestaat niet of is verplaatst.</p>
              <Button asChild>
                <Link to="/blog">Terug naar blog overzicht</Link>
              </Button>
            </div>
          </main>
          <Footer />
        </div>
      );
    }

    return (
      <div className="min-h-screen">
        <Header />
        <CallButton />
        <main className="pt-28">
          <article className="py-16">
            <div className="container mx-auto max-w-4xl">
              <BlogArticle post={post} language={language} />
              
              <div className="mt-12 pt-8 border-t border-gray-medium">
                <Button asChild variant="outline">
                  <Link to="/blog">
                    ← Terug naar blog overzicht
                  </Link>
                </Button>
              </div>
            </div>
          </article>
        </main>
        <Footer />
      </div>
    );
  }
  
  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Ondernemermarketing.nl",
    "url": "https://www.ondernemermarketing.nl",
    "logo": "https://www.ondernemermarketing.nl/lovable-uploads/bf6accc4-838f-4f65-9b6a-1ef2f9fd9e46.png",
    "description": "Marketing bureau voor ondernemers. Wij regelen je funnels, email marketing en automatisering.",
    "address": {
      "@type": "PostalAddress",
      "addressCountry": "NL"
    }
  };
  
  return (
    <div className="min-h-screen">
      <SEO 
        title={`${title} | Ondernemermarketing.nl`}
        description={description}
        url="https://www.ondernemermarketing.nl/blog"
        structuredData={organizationSchema}
      />
      <Header />
      <CallButton />
      
      <main className="pt-28">
        {/* Blog header */}
        <section className="py-12 bg-gray-light">
          <div className="container mx-auto">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="mb-4">{title}</h1>
              <h2 className="text-xl md:text-2xl font-bold mb-4 text-primary-blue">{subtitle}</h2>
              <p className="mb-8 text-gray-dark">{description}</p>
              
              {/* Search bar */}
              <div className="relative max-w-md mx-auto">
                <Input 
                  type="search"
                  placeholder={searchPlaceholder}
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-dark" />
              </div>
              
              {/* Categories */}
              <div className="flex flex-wrap justify-center gap-2 mt-6">
                {categories.map((category, index) => (
                  <Button 
                    key={index} 
                    variant={index === 0 ? "default" : "outline"} 
                    size="sm"
                  >
                    {category}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </section>
        
        {/* Blog posts */}
        <section className="py-16 bg-white">
          <div className="container mx-auto">
            <h2 className="mb-8">{latestArticles}</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {blogPosts.map(post => (
                <article key={post.id} className="bg-white rounded-xl overflow-hidden border border-gray-medium hover:shadow-lg transition-shadow duration-300">
                  <img 
                    src={post.image} 
                    alt={post.title[language]} 
                    className="w-full h-48 object-cover"
                    loading="lazy"
                  />
                  <div className="p-6">
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-sm px-3 py-1 bg-gray-light rounded-full">{post.category[language]}</span>
                      <span className="text-sm text-gray-dark">{post.date[language]}</span>
                    </div>
                    <h3 className="text-lg font-bold mb-2 text-primary-blue">{post.title[language]}</h3>
                    <p className="text-gray-dark mb-4">{post.excerpt[language]}</p>
                    <Button asChild variant="link" className="p-0 text-accent-orange">
                      <Link to={`/blog/${post.slug}`}>
                        {readMore} <ArrowRight className="ml-1 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
        
        {/* Newsletter */}
        <section className="py-16 bg-gray-light">
          <div className="container mx-auto max-w-xl text-center">
            <h2 className="mb-4">{subscribe.title}</h2>
            <p className="mb-6 text-gray-dark">{subscribe.description}</p>
            <form className="flex flex-col md:flex-row gap-3">
              <Input 
                type="email" 
                placeholder={subscribe.placeholder} 
                className="flex-grow" 
                required 
              />
              <Button asChild type="submit" className="primary-cta">
                <Link to="/contact">
                  {subscribe.button}
                </Link>
              </Button>
            </form>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Blog;
