import React, { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Check, Star, Phone, MessageCircle, Clock, Users, TrendingUp, Target, Zap, Globe, Package } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

const HighConvertingLanding = () => {
  // Google Tag Manager initialization
  useEffect(() => {
    // Google Tag Manager script
    const gtmScript = document.createElement('script');
    gtmScript.innerHTML = `
      (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
      new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
      j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
      'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
      })(window,document,'script','dataLayer','GTM-PVV75624');
    `;
    document.head.appendChild(gtmScript);

    return () => {
      // Cleanup
      if (gtmScript.parentNode) {
        gtmScript.parentNode.removeChild(gtmScript);
      }
    };
  }, []);

  const handleWhatsAppClick = () => {
    const message = encodeURIComponent("Hallo! Ik ben geïnteresseerd in jullie marketingpakketten. Kunnen we een gesprek plannen?");
    window.open(`https://wa.me/31613013266?text=${message}`, '_blank');
  };

  const handleCallClick = () => {
    window.location.href = 'tel:+31613013266';
  };

  const packages = [
    {
      name: 'Social Media Ads',
      originalPrice: '€495 + €190 opzetkosten',
      price: '€195 p/m + €190 opzetkosten',
      savings: '€300 besparing',
      description: 'Een profiel dat niet informeert, maar converteert',
      icon: Target,
      features: [
        '3 Wervende ads die verkopen',
        'Ads strategisch geplaatst',
        '3 bewezen DM-scripts voor gesprekken',
        'Conversie-geoptimaliseerde opzet'
      ],
      image: '/lovable-uploads/8cd60c1b-0323-4872-bf95-8063f71492ee.png',
      popular: false
    },
    {
      name: 'Google Ads ',
      originalPrice: '€549 p/m + €190 opzetkosten',
      price: '€249 p/m + €190 opzetkosten',
      savings: '€300 besparing',
      description: 'Meer klanten uit zoekopdrachten',
      icon: Zap,
      features: [
        'Professionele ads (copy + design)',
        'Geavanceerde campagne',
        'Volledig geoptimaliseerd voor conversie',
        'A/B geteste elementen'
      ],
      image: '/lovable-uploads/12f5314d-f5e2-4038-8fde-5c5ab0bef4b8.png',
      popular: true
    },
    {
      name: 'Groei abonnement',
      originalPrice: '€1.550 p/m + €300 opzetkosten',
      price: '€1.250 p/m + €300 opzetkosten',
      savings: '€300 besparing',
      description: 'Alles op één pagina om direct klanten te krijgen',
      icon: Globe,
      features: [
        'Krachtige website met conversie-psychologie',
        'Doelgroep taregting + belofte combinatie',
        'Strategische leadgeneratie',
        'Naadloze CRM integratie'
      ],
      image: '/lovable-uploads/3a5b5085-513f-4587-8e42-b13eee3cde80.png',
      popular: false
    },
    {
      name: 'Website Light',
      originalPrice: '€199',
      price: '€99',
      savings: '€100 besparing',
      description: 'Binnen 1 week live met een professionele website',
      icon: Globe,
      features: [
        'Tot 5 pagina\'s met conversie-focus',
        'Professioneel design + mobiel geoptimaliseerd',
        'Werkend contactformulier met tracking',
        'Domein + e-mail setup assistentie',
        '14 dagen gratis priority support'
      ],
      image: '/lovable-uploads/4aa69807-6024-4c17-be50-0a6bd7f3cfb9.png',
      popular: false
    }
  ];

  const testimonials = [
    {
      name: "Jean Paul",
      business: "Platenhandel",
      rating: 5,
      text: "Binnen 2 weken 15 nieuwe klanten! Hun advertenties hebben mijn bedrijf laten groeien.",
      result: "+300% leads"
    },
    {
      name: "Marieke Schippers", 
      business: "Duikschool",
      rating: 5,
      text: "Eindelijk een landingspagina die écht werkt. Ons conversiepercentage is verdrievoudigd!",
      result: "+200% conversies"
    },
    {
      name: "Ben",
      business: "Online Winkel", 
      rating: 5,
      text: "Van 0 naar €10.000 omzet per maand in 3 maanden tijd. Ongelooflijk wat goede marketing doet!",
      result: "€10.000/maand"
    }
  ];

  const urgencyDeadline = new Date();
  urgencyDeadline.setDate(urgencyDeadline.getDate() + 3);

  return (
    <>
      <SEO 
        title="🔥 BEPERKTE TIJD: Tot €300 Korting op Marketing Pakketten | Ondernemermarketing.nl"
        description="ACTIE: Professionele marketing pakketten vanaf €99. Binnen 7 dagen live! Social Media Funnels, Landingspagina's & Websites. Beperkte tijd beschikbaar."
        structuredData={{
          "@context": "https://schema.org",
          "@type": "Organization",
          "name": "Ondernemermarketing.nl",
          "description": "Marketing pakketten voor ondernemers - Professionele funnels, landingspagina's en websites",
          "telephone": "+31613013266",
          "url": "https://www.ondernemermarketing.nl",
          "offers": {
            "@type": "AggregateOffer",
            "lowPrice": "99",
            "highPrice": "1250", 
            "priceCurrency": "EUR"
          }
        }}
      />

      {/* Google Tag Manager (noscript) */}
      <noscript>
        <iframe
          src="https://www.googletagmanager.com/ns.html?id=GTM-XXXXXXX"
          height="0"
          width="0"
          style={{ display: 'none', visibility: 'hidden' }}
        />
      </noscript>

      <div className="min-h-screen bg-white">
        {/* Floating Contact Buttons */}
        <div className="fixed right-4 bottom-4 z-50 flex flex-col gap-3">
          <button
            onClick={handleWhatsAppClick}
            className="bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 group"
            aria-label="WhatsApp contact"
          >
            <MessageCircle className="h-6 w-6" />
            <span className="absolute right-16 top-1/2 transform -translate-y-1/2 bg-green-500 text-white px-3 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
              WhatsApp
            </span>
          </button>
          <button
            onClick={handleCallClick}
            className="bg-accent-orange hover:bg-orange-600 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 group"
            aria-label="Bel direct"
          >
            <Phone className="h-6 w-6" />
            <span className="absolute right-16 top-1/2 transform -translate-y-1/2 bg-accent-orange text-white px-3 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
              Bel Nu: +31 6 1301 3266
            </span>
          </button>
        </div>

        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary-blue via-primary-blue to-blue-800 text-white py-16 px-4">
          <div className="container mx-auto text-center max-w-4xl">
            {/* Urgency Banner */}
            <div className="bg-red-600 text-white px-4 py-2 rounded-full inline-block mb-6 animate-pulse">
              <Clock className="inline h-4 w-4 mr-2" />
              ACTIE EINDIGT OVER 3 DAGEN - BEPERKTE PLAATSEN
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              🔥 <span className="text-accent-orange">Van 0 naar €10.000+</span> omzet per maand
            </h1>
            
            <p className="text-xl md:text-2xl mb-8 text-blue-100">
              Professionele marketing pakketten die daadwerkelijk klanten opleveren - <strong>binnen 7 dagen live!</strong>
            </p>

            {/* Social Proof Numbers */}
            <div className="grid grid-cols-3 gap-4 mb-8 max-w-2xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-accent-orange">20+</div>
                <div className="text-sm text-blue-200">Tevreden klanten</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent-orange">€1.1M+</div>
                <div className="text-sm text-blue-200">Gegenereerde omzet</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent-orange">Snel</div>
                <div className="text-sm text-blue-200">Gemiddelde oplevering: 7 dagen</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <Button
                onClick={handleWhatsAppClick}
                className="bg-green-500 hover:bg-green-600 text-white px-8 py-4 text-lg font-bold rounded-full"
              >
                WhatsApp Direct - Gratis Advies
              </Button>
              <Button
                onClick={handleCallClick}
                className="bg-accent-orange hover:bg-orange-600 text-white px-8 py-4 text-lg font-bold rounded-full"
              >
                Bel Nu: +31 6 1301 3266
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex justify-center items-center gap-4 text-blue-200 text-sm">
              <div className="flex items-center">
                <Check className="h-4 w-4 mr-1 text-green-400" />
                Binnen 7 dagen live
              </div>
              <div className="flex items-center">
                <Check className="h-4 w-4 mr-1 text-green-400" />
                Maandelijks opzegbaar
              </div>
              <div className="flex items-center">
                <Check className="h-4 w-4 mr-1 text-green-400" />
                Vele ondernemers succesvol geholpen
              </div>
            </div>
          </div>
        </section>

        {/* Problem Agitation Section */}
        <section className="py-16 px-4 bg-red-50">
          <div className="container mx-auto max-w-4xl text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-8 text-red-700">
              ❌ Herken je dit probleem?
            </h2>
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-red-500">
                <h3 className="font-bold text-lg mb-2">Je website genereert geen klanten</h3>
                <p>Bezoekers kijken en vertrekken weer. Geen leads, geen sales.</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-red-500">
                <h3 className="font-bold text-lg mb-2">Social media posts worden genegeerd</h3>
                <p>Uren werk voor een handvol likes. Geen echte bedrijfsresultaten.</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-red-500">
                <h3 className="font-bold text-lg mb-2">Onduidelijke online boodschap</h3>
                <p>Potentiële klanten snappen niet wat je doet of waarom ze jou zouden kiezen.</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-red-500">
                <h3 className="font-bold text-lg mb-2">Geen systeem voor leadgeneratie</h3>
                <p>Je bent afhankelijk van toeval en mond-tot-mond reclame.</p>
              </div>
            </div>
            <p className="text-xl text-red-700 font-bold">
              Het resultaat? <span className="text-red-800">Gemiste omzet van duizenden euro's per maand!</span>
            </p>
          </div>
        </section>

        {/* Solution Section */}
        <section className="py-16 px-4 bg-green-50">
          <div className="container mx-auto max-w-4xl text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-8 text-green-700">
              ✅ De Oplossing: Bewezen Marketing Systemen
            </h2>
            <p className="text-xl mb-8 text-green-800">
              Onze pakketten transformeren jouw online aanwezigheid in een klantenmagneet - <strong>gegarandeerd binnen 7 dagen!</strong>
            </p>
            
            <div className="bg-white p-8 rounded-2xl shadow-lg mb-8">
              <h3 className="text-2xl font-bold mb-4 text-primary-blue">Waarom werken onze pakketten zo goed?</h3>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Target className="h-8 w-8 text-green-600" />
                  </div>
                  <h4 className="font-bold mb-2">Conversie-Psychologie</h4>
                  <p className="text-sm">Gebaseerd op bewezen psychologische triggers die mensen doen kopen.</p>
                </div>
                <div className="text-center">
                  <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="h-8 w-8 text-green-600" />
                  </div>
                  <h4 className="font-bold mb-2">Data-Gedreven</h4>
                  <p className="text-sm">Elke keuze gebaseerd op 20+ succesvolle projecten en A/B tests.</p>
                </div>
                <div className="text-center">
                  <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Zap className="h-8 w-8 text-green-600" />
                  </div>
                  <h4 className="font-bold mb-2">Snelle Implementatie</h4>
                  <p className="text-sm">Van concept naar live binnen 7 dagen - je tijd is geld waard.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Packages Section with Urgency */}
        <section className="py-16 px-4 bg-white">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center mb-12">
              <div className="bg-red-600 text-white px-6 py-2 rounded-full inline-block mb-4">
                🔥 BEPERKTE TIJD: TOT €300 KORTING
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Kies Jouw <span className="text-accent-orange">Marketing Transformatie</span>
              </h2>
              <p className="text-xl text-gray-600">
                Alle pakketten binnen 7 dagen live + 100% tevredenheidsgarantie. Prijzen excl. BTW en excl. advertentiebudget.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {packages.map((pkg, index) => {
                const Icon = pkg.icon;
                return (
                  <div 
                    key={index} 
                    className={`relative bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border-2 ${
                      pkg.popular ? 'border-accent-orange transform scale-105' : 'border-gray-200'
                    }`}
                  >
                    {pkg.popular && (
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-accent-orange text-white px-4 py-1 rounded-full text-sm font-bold">
                        POPULAIRE KEUZE
                      </div>
                    )}
                    
                    <div className="text-center mb-4">
                      <img 
                        src={pkg.image} 
                        alt={pkg.name}
                        className="w-full h-32 object-cover rounded-lg mb-3"
                      />
                      <Icon className="h-10 w-10 text-accent-orange mx-auto mb-3" />
                    </div>

                    <h3 className="text-lg font-bold text-center mb-2">{pkg.name}</h3>
                    <p className="text-sm text-gray-600 text-center mb-4">{pkg.description}</p>

                    <div className="text-center mb-4">
                      <div className="text-lg text-gray-400 line-through">{pkg.originalPrice}</div>
                      <div className="text-2xl font-bold text-primary-blue">{pkg.price}</div>
                      <div className="text-sm text-green-600 font-bold">{pkg.savings}</div>
                    </div>

                    <ul className="space-y-2 mb-6">
                      {pkg.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start text-sm">
                          <Check className="h-4 w-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
<br></br><br></br><br></br>
                    <Button
                      onClick={handleWhatsAppClick}
                      className={`w-full ${
                        pkg.popular 
                          ? 'bg-accent-orange hover:bg-orange-600' 
                          : 'bg-primary-blue hover:bg-primary-blue/90'
                      } text-white font-bold py-3`}
                    >
                      🚀 Bestel Via WhatsApp
                    </Button>
                  </div>
                );
              })}
            </div>

            {/* Bundle Offer */}
            <div className="mt-12 bg-gradient-to-r from-primary-blue to-blue-800 text-white rounded-2xl p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">🎯 ULTRA DEAL: Volledige Marketing Bundel</h3>
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
            <img src="/lovable-uploads/0970519e-7452-40f9-830d-5c8bca26f492.png" alt="Complete Marketing Pack" className="w-1/2 sm:w-full max-w-sm mx-auto rounded-lg"/>

                </div>
                <div>
                  <div className="text-3xl text-gray-300 line-through mb-2">€2.594 p/m + €1000 opzetkosten</div>
                  <div className="text-5xl font-bold text-accent-orange mb-4">€1.694 p/m</div>
                  <div className="text-xl text-green-300 font-bold mb-6">€1.900 MEGA BESPARING!</div>
                  
                  <div className="text-left mb-6">
                    <h4 className="font-bold mb-3">Complete Marketing Transformatie Inclusief:</h4>
                    <ul className="space-y-2">
                      <li className="flex items-center">
                        <Check className="h-5 w-5 text-green-400 mr-2" />
                        Social Media Ads (€495)
                      </li>
                      <li className="flex items-center">
                        <Check className="h-5 w-5 text-green-400 mr-2" />
                        Google Ads (€549)
                      </li>
                      <li className="flex items-center">
                        <Check className="h-5 w-5 text-green-400 mr-2" />
                        Groei abonnement (€1.550)
                      </li>
                      <li className="flex items-center">
                        <Check className="h-5 w-5 text-green-400 mr-2" />
                        BONUS: GEEN opzetkosten (€1000 waarde). Prijzen zijn excl. BTW en excl. advertentiebudget.
                      </li>
                    </ul>
                  </div>

                  <Button
                    onClick={handleWhatsAppClick}
                    className="bg-accent-orange hover:bg-orange-600 text-white font-bold py-4 px-8 text-lg w-full"
                  >
                    🔥 CLAIM en BESPAAR 
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Social Proof / Testimonials */}
        <section className="py-16 px-4 bg-gray-50">
          <div className="container mx-auto max-w-6xl">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
              🌟 Onze Klanten Zijn <span className="text-accent-orange">Razend Enthousiast</span>
            </h2>
            
            <div className="grid md:grid-cols-3 gap-6 mb-12">
              {testimonials.map((testimonial, index) => (
                <div key={index} className="bg-white p-6 rounded-2xl shadow-lg">
                  <div className="flex items-center mb-4">
                    <div className="flex text-yellow-400">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 fill-current" />
                      ))}
                    </div>
                    <div className="ml-3 bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-bold">
                      {testimonial.result}
                    </div>
                  </div>
                  <p className="text-gray-700 mb-4 italic">"{testimonial.text}"</p>
                  <div className="font-bold text-primary-blue">{testimonial.name}</div>
                  <div className="text-sm text-gray-500">{testimonial.business}</div>
                </div>
              ))}
            </div>

            {/* Guarantee */}
            <div className="bg-green-100 border-2 border-green-500 rounded-2xl p-8 text-center">
              <h3 className="text-2xl font-bold text-green-800 mb-4">
                💯 100% Tevredenheid
              </h3>
              <p className="text-green-700 text-lg">
                Niet tevreden na oplevering? Geld terug. Geen vragen gesteld. 
                <strong> Dit is ons vertrouwen in onze kwaliteit.</strong>
              </p>
            </div>
          </div>
        </section>

        {/* Urgency + Final CTA */}
        <section className="py-16 px-4 bg-red-600 text-white">
          <div className="container mx-auto max-w-4xl text-center">
            <div className="bg-yellow-400 text-black px-6 py-3 rounded-full inline-block mb-6 animate-bounce">
              ⚠️ LAATSTE KANS - ACTIE EINDIGT OVER 3 DAGEN
            </div>
            
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              Pak Nu Je Kans Voor Het Te Laat Is!
            </h2>
            
            <p className="text-xl md:text-2xl mb-8">
              Wacht je nog langer? Dan mis je <strong>€1.000's aan potentiële omzet</strong> elke maand die voorbij gaat.
            </p>

            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <div className="bg-white/10 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-2">❌ Zonder Ons Systeem:</h3>
                <ul className="text-left space-y-1">
                  <li>• Blijf worstelen met lage conversies</li>
                  <li>• Mis maandelijks €1.000's aan omzet</li>
                  <li>• Verspil tijd aan marketing die niet werkt</li>
                  <li>• Zie concurrenten je voorbij streven</li>
                </ul>
              </div>
              <div className="bg-green-600 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-2">✅ Met Ons Systeem:</h3>
                <ul className="text-left space-y-1">
                  <li>• Binnen 7 dagen een klantenmagneet</li>
                  <li>• €10.000+ extra omzet per maand mogelijk</li>
                  <li>• Automatische leadgeneratie 24/7</li>
                  <li>• Word marktleider in jouw niche</li>
                </ul>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={handleWhatsAppClick}
                className="bg-green-500 hover:bg-green-600 text-white px-8 py-4 text-xl font-bold rounded-full transform hover:scale-105 transition-all"
              >
               WhatsApp en bespaar
              </Button>
              <Button
                onClick={handleCallClick}
                className="bg-accent-orange hover:bg-orange-600 text-white px-8 py-4 text-xl font-bold rounded-full transform hover:scale-105 transition-all"
              >
                Bel Direct: +31 6 1301 3266
              </Button>
            </div>

            <p className="text-sm mt-6 text-red-200">
              ⏰ Deze prijzen gelden alleen tot {urgencyDeadline.toLocaleDateString('nl-NL')} - Wacht niet langer!
            </p>
          </div>
        </section>

        {/* Contact Footer */}
        <footer className="bg-primary-blue text-white py-8 px-4">
          <div className="container mx-auto text-center">
            <div className="mb-4">
              <img 
                src="/lovable-uploads/bf6accc4-838f-4f65-9b6a-1ef2f9fd9e46.png"
                alt="Ondernemermarketing.nl"
                className="h-20 mx-auto mb-4"
              />
            </div>
            
            <div className="flex flex-col sm:flex-row justify-center items-center gap-6 mb-6">
              <div className="flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                <span className="font-bold">+31 6 1301 3266</span>
              </div>
              <div className="flex items-center">
                <MessageCircle className="h-5 w-5 mr-2" />
                <span className="font-bold">WhatsApp Direct Contact</span>
              </div>
            </div>

            <p className="text-blue-200 text-sm">
              Ondernemermarketing.nl - Disclaimer

De in deze uiting genoemde resultaten, voorbeelden en klantcases (zoals omzetgroei of aantal leads) zijn illustratief en gebaseerd op ervaringen van eerdere klanten. Resultaten verschillen per situatie en er wordt geen garantie gegeven dat jij dezelfde resultaten behaalt.

Alle aanbiedingen, kortingen en acties zijn tijdelijk en onder voorbehoud van wijzigingen. De vermelde prijzen zijn exclusief btw, tenzij anders vermeld.

De “tevredenheidsgarantie” of “geld-terug garantie” geldt alleen binnen de afgesproken termijn, mits je actief hebt meegewerkt en onze instructies hebt opgevolgd.

Je hebt als consument bij aankoop op afstand recht op 14 dagen bedenktijd, tenzij je uitdrukkelijk instemt met directe uitvoering van de dienst en daarmee afstand doet van dit recht.

Wij gebruiken je gegevens uitsluitend om contact met je op te nemen over je aanvraag. Zie ons privacybeleid voor meer informatie.

Wij zijn niet aansprakelijk voor indirecte schade zoals gederfde winst, gemiste kansen of reputatieschade, tenzij sprake is van opzet of grove schuld. Op alle aanbiedingen en overeenkomsten zijn onze algemene voorwaarden van toepassing.</p>

          </div>
        </footer>
      </div>
    </>
  );
};

export default HighConvertingLanding;