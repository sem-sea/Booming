import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';

type Language = 'nl' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string) => string;
}

// Create the context with a default value
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Common translations used throughout the site
const translations: Record<string, Record<Language, string>> = {
  // Navigation
  'nav.approach': { nl: 'Aanpak', en: 'Approach' },
  'nav.services': { nl: 'Diensten', en: 'Services' },
  'nav.results': { nl: 'Resultaten', en: 'Results' },
  'nav.tools': { nl: 'Tools', en: 'Tools' },
  'nav.blog': { nl: 'Blog', en: 'Blog' },
  'nav.about': { nl: 'Over ons', en: 'About us' },
  'nav.contact': { nl: 'Contact', en: 'Contact' },
  
  // Hero sections
  'hero.title': { nl: 'Marketing Groei', en: 'Marketing Growth' },
  'hero.subtitle': { nl: 'Professionele marketingoplossingen die werken', en: 'Professional marketing solutions that work' },
  
  // CTAs
  'cta.free_intake': { nl: 'Gratis Intake', en: 'Free Intake' },
  'cta.view_services': { nl: 'Bekijk ons aanbod', en: 'View our services' },
  'cta.learn_more': { nl: 'Meer informatie', en: 'Learn more' },
  'cta.download': { nl: 'Download', en: 'Download' },
  
  // Tools
  'tools.scan_title': { nl: 'Marketing GroeiScan', en: 'Marketing Growth Scan' },
  'tools.calculator_title': { nl: 'Winstgroei Calculator', en: 'Profit Growth Calculator' },
  'tools.scan_desc': { nl: 'Ontdek in 2 minuten waar je marketing verbeterd kan worden.', en: 'Discover in 2 minutes where your marketing can be improved.' },
  'tools.calculator_desc': { nl: 'Bereken hoeveel extra omzet je kunt genereren met betere marketing.', en: 'Calculate how much extra revenue you can generate with better marketing.' },
  
  // Footer
  'footer.copyright': { nl: '© 2025 OndernemerMarketing. Alle rechten voorbehouden.', en: '© 2025 OndernemerMarketing. All rights reserved.' },
  
  // Services sections
  'services.kickstart': { nl: 'Kickstart Funnel', en: 'Kickstart Funnel' },
  'services.growth': { nl: 'Groei Machine', en: 'Growth Machine' },
  'services.outsource': { nl: 'Volledig Uitbesteed', en: 'Fully Outsourced' },
  'services.compare': { nl: 'Vergelijk', en: 'Compare' },
  
  // Services
  'services.title': { nl: 'Onze Diensten', en: 'Our Services' },
  'services.subtitle': { nl: 'Professionele marketingoplossingen die werken', en: 'Professional marketing solutions that work' },
};

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  // Try to get the stored language or default to Dutch
  const [language, setLanguageState] = useState<Language>(() => {
    const storedLanguage = localStorage.getItem('language');
    return (storedLanguage as Language) || 'nl';
  });
  
  // Update local storage when language changes
  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage);
    localStorage.setItem('language', newLanguage);
  };
  
  // Translation function
  const t = (key: string): string => {
    if (!translations[key]) {
      console.warn(`Translation key not found: ${key}`);
      return key;
    }
    return translations[key][language];
  };
  
  useEffect(() => {
    // Update HTML lang attribute when language changes
    document.documentElement.lang = language;
  }, [language]);
  
  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

// Custom hook to use the language context
export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
