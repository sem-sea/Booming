
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '@/contexts/LanguageContext';

const Terms = () => {
  const { language } = useLanguage();
  
  const content = {
    nl: {
      title: 'Algemene Voorwaarden',
      lastUpdated: 'Laatst bijgewerkt: December 2024',
      sections: [
        {
          title: '1. Algemeen',
          content: `
            <p>Deze algemene voorwaarden zijn van toepassing op alle aanbiedingen, offertes en overeenkomsten waarbij OndernemerMarketing.nl, gevestigd te Breedveldsingel 1, 3055 PG Rotterdam, diensten verleent.</p>
            <p>Door het aangaan van een overeenkomst met OndernemerMarketing.nl verklaart de opdrachtgever zich akkoord met deze voorwaarden.</p>
          `
        },
        {
          title: '2. Aanbiedingen en totstandkoming overeenkomst',
          content: `
            <p>Alle aanbiedingen zijn vrijblijvend en geldig gedurende 30 dagen, tenzij anders vermeld. Een overeenkomst komt tot stand door schriftelijke bevestiging of door aanvang van de werkzaamheden.</p>
            <p>Wijzigingen in de opdracht kunnen leiden tot aanpassing van de prijs en doorlooptijd.</p>
          `
        },
        {
          title: '3. Uitvoering van de diensten',
          content: `
            <p>OndernemerMarketing.nl zal de overeengekomen diensten naar beste kunnen uitvoeren, conform de afgesproken specificaties en binnen de gestelde termijnen.</p>
            <p>De opdrachtgever verplicht zich om alle benodigde medewerking te verlenen, inclusief het tijdig aanleveren van informatie en materialen.</p>
          `
        },
        {
          title: '4. Prijzen en betaling',
          content: `
            <p>Alle prijzen zijn exclusief BTW, tenzij anders vermeld. Betaling dient te geschieden binnen 14 dagen na factuurdatum.</p>
            <p>Bij overschrijding van de betalingstermijn is de opdrachtgever zonder nadere ingebrekestelling in verzuim.</p>
          `
        },
        {
          title: '5. Intellectueel eigendom',
          content: `
            <p>Alle intellectuele eigendomsrechten op door OndernemerMarketing.nl ontwikkelde materialen berusten bij OndernemerMarketing.nl, tenzij schriftelijk anders overeengekomen.</p>
            <p>De opdrachtgever verkrijgt een gebruiksrecht voor de overeengekomen doeleinden.</p>
          `
        },
        {
          title: '6. Aansprakelijkheid',
          content: `
            <p>De aansprakelijkheid van OndernemerMarketing.nl is beperkt tot het factuurbedrag van de betreffende opdracht, met een maximum van € 2.500.</p>
            <p>OndernemerMarketing.nl is niet aansprakelijk voor indirecte schade, gevolgschade, gederfde winst of schade aan derden.</p>
          `
        },
        {
          title: '7. Overmacht',
          content: `
            <p>OndernemerMarketing.nl is niet gehouden tot het nakomen van enige verplichting indien zij daartoe verhinderd wordt als gevolg van overmacht.</p>
          `
        },
        {
          title: '8. Geschillen',
          content: `
            <p>Op alle overeenkomsten is Nederlands recht van toepassing. Geschillen worden voorgelegd aan de bevoegde rechter in Rotterdam.</p>
          `
        }
      ]
    },
    en: {
      title: 'Terms and Conditions',
      lastUpdated: 'Last updated: December 2024',
      sections: [
        {
          title: '1. General',
          content: `
            <p>These general terms and conditions apply to all offers, quotations and agreements whereby OndernemerMarketing.nl, located at Breedveldsingel 1, 3055 PG Rotterdam, provides services.</p>
            <p>By entering into an agreement with OndernemerMarketing.nl, the client declares to agree with these conditions.</p>
          `
        },
        {
          title: '2. Offers and conclusion of agreement',
          content: `
            <p>All offers are without obligation and valid for 30 days, unless stated otherwise. An agreement is concluded by written confirmation or by commencement of work.</p>
            <p>Changes to the assignment may lead to adjustment of price and lead time.</p>
          `
        },
        {
          title: '3. Execution of services',
          content: `
            <p>OndernemerMarketing.nl will execute the agreed services to the best of its ability, in accordance with the agreed specifications and within the set deadlines.</p>
            <p>The client undertakes to provide all necessary cooperation, including timely delivery of information and materials.</p>
          `
        },
        {
          title: '4. Prices and payment',
          content: `
            <p>All prices are exclusive of VAT, unless stated otherwise. Payment must be made within 14 days of invoice date.</p>
            <p>If the payment term is exceeded, the client is in default without further notice.</p>
          `
        },
        {
          title: '5. Intellectual property',
          content: `
            <p>All intellectual property rights on materials developed by OndernemerMarketing.nl rest with OndernemerMarketing.nl, unless agreed otherwise in writing.</p>
            <p>The client acquires a right of use for the agreed purposes.</p>
          `
        },
        {
          title: '6. Liability',
          content: `
            <p>OndernemerMarketing.nl's liability is limited to the invoice amount of the relevant assignment, with a maximum of € 2,500.</p>
            <p>OndernemerMarketing.nl is not liable for indirect damage, consequential damage, lost profits or damage to third parties.</p>
          `
        },
        {
          title: '7. Force majeure',
          content: `
            <p>OndernemerMarketing.nl is not obliged to fulfill any obligation if it is prevented from doing so as a result of force majeure.</p>
          `
        },
        {
          title: '8. Disputes',
          content: `
            <p>Dutch law applies to all agreements. Disputes will be submitted to the competent court in Rotterdam.</p>
          `
        }
      ]
    }
  };

  const { title, lastUpdated, sections } = content[language];

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-28">
        <section className="py-12 bg-gray-light">
          <div className="container mx-auto">
            <h1 className="text-center mb-2">{title}</h1>
            <p className="text-center text-gray-dark">{lastUpdated}</p>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container mx-auto max-w-4xl">
            {sections.map((section, index) => (
              <div key={index} className="mb-8">
                <h2 className="text-2xl font-bold text-primary-blue mb-4">{section.title}</h2>
                <div 
                  className="prose prose-lg max-w-none text-gray-dark"
                  dangerouslySetInnerHTML={{ __html: section.content }}
                />
              </div>
            ))}
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Terms;
