
import React from 'react';
import { Phone } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const CallButton = () => {
  const { language } = useLanguage();
  
  const content = {
    nl: {
      text: 'Bel direct',
      phone: '+31 6 1301 3266'
    },
    en: {
      text: 'Call now',
      phone: '+31 6 1301 3266'
    }
  };

  const { text, phone } = content[language];

  return (
    <a
      href={`tel:${phone.replace(/\s/g, '')}`}
      className="fixed right-4 bottom-80 z-40 bg-accent-orange hover:bg-orange-600 text-white p-3 rounded-full shadow-lg transition-all duration-300 hover:scale-110 flex items-center gap-2 group"
      aria-label={text}
    >
      <Phone className="h-5 w-5" />
      <span className="hidden group-hover:block whitespace-nowrap text-sm font-medium px-2">
        {text}
      </span>
    </a>
  );
};

export default CallButton;
