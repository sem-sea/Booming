
import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Button } from '@/components/ui/button';
import { ArrowRight, Check } from 'lucide-react';

const ServiceDetail = () => {
  const { serviceSlug } = useParams();
  const [language, setLanguage] = useState<'nl' | 'en'>('nl'); // In a real app, this would use i18n context

  const services = {
    'kickstart-funnel': {
      nl: {
        title: 'Kickstart Funnel',
        description: 'Een complete funnel die leads voor je genereert, opvolgt en converteert naar klanten.',
        longDescription: 'Onze Kickstart Funnel is perfect voor ondernemers die een voorspelbare stroom aan leads willen genereren zonder zelf tijd kwijt te zijn aan marketing. We bouwen een volledige funnel die 24/7 voor je werkt.',
        features: [
          'Strategische lead magnets die jouw ideale klant aantrekt',
          'E-mail nurturing reeks die leads opwarmt',
          'Volledige verkoopgesprek voorbereiding',
          'Geautomatiseerde follow-up systemen',
          'Dashboards voor resultaatmeting',
          'Volledige technische implementatie'
        ],
        price: 'Vanaf €3.500',
        cta: 'Plan een gratis intake gesprek',
        secondaryCta: 'Bekijk eerst resultaten',
        faqs: [
          {
            question: 'Hoe lang duurt het om een funnel te bouwen?',
            answer: 'We bouwen jouw funnel in 3-4 weken, afhankelijk van de complexiteit en jouw beschikbaarheid voor feedback.'
          },
          {
            question: 'Wat voor resultaten kan ik verwachten?',
            answer: 'Onze klanten zien gemiddeld een toename van 35% in leads binnen 60 dagen na implementatie. De exacte resultaten hangen af van jouw markt, aanbod en huidige situatie.'
          },
          {
            question: 'Moet ik zelf content aanleveren?',
            answer: 'Nee, we helpen je bij het ontwikkelen van alle content, van lead magnets tot e-mailreeksen. We hebben een proces om jouw kennis om te zetten in effectieve marketingcontent.'
          }
        ]
      },
      en: {
        title: 'Kickstart Funnel',
        description: 'A complete funnel that generates leads for you, follows up, and converts them into customers.',
        longDescription: 'Our Kickstart Funnel is perfect for entrepreneurs who want a predictable flow of leads without spending time on marketing themselves. We build a complete funnel that works 24/7 for you.',
        features: [
          'Strategic lead magnets that attract your ideal customer',
          'Email nurturing series that warms up leads',
          'Complete sales call preparation',
          'Automated follow-up systems',
          'Dashboards for measuring results',
          'Full technical implementation'
        ],
        price: 'From €3,500',
        cta: 'Schedule a free intake call',
        secondaryCta: 'View results first',
        faqs: [
          {
            question: 'How long does it take to build a funnel?',
            answer: 'We build your funnel in 3-4 weeks, depending on complexity and your availability for feedback.'
          },
          {
            question: 'What results can I expect?',
            answer: 'Our clients see an average increase of 35% in leads within 60 days after implementation. The exact results depend on your market, offer, and current situation.'
          },
          {
            question: 'Do I need to provide content myself?',
            answer: 'No, we help you develop all content, from lead magnets to email sequences. We have a process to convert your knowledge into effective marketing content.'
          }
        ]
      }
    },
    'groei-machine': {
      nl: {
        title: 'Groei Machine',
        description: 'Een compleet marketingsysteem voor groei, inclusief SEO, content en performance marketing.',
        longDescription: 'De Groei Machine is een compleet marketingsysteem voor ondernemers die serieuze groei willen realiseren. We combineren content, SEO, social media en paid advertising in een geïntegreerd systeem.',
        features: [
          'Content strategie en productie',
          'SEO-optimalisatie voor zichtbaarheid',
          'Performance marketing op social media',
          'Maandelijkse groeisessies',
          'Complete uitvoering door ons team',
          'Rapportages en optimalisatie'
        ],
        price: 'Vanaf €4.500/maand',
        cta: 'Plan een gratis intake gesprek',
        secondaryCta: 'Bekijk eerst resultaten',
        faqs: [
          {
            question: 'Is er een minimale contractperiode?',
            answer: 'Ja, we werken met een minimale periode van 3 maanden omdat echte resultaten tijd kosten. Daarna is de samenwerking maandelijks opzegbaar.'
          },
          {
            question: 'Moet ik zelf beschikbaar zijn?',
            answer: 'We hebben minimale input nodig - ongeveer 2 uur per maand voor afstemming en feedback. De rest regelen wij.'
          },
          {
            question: 'Wat als ik al content heb?',
            answer: 'Perfect! We kunnen bestaande content optimaliseren en integreren in de Groei Machine voor nog snellere resultaten.'
          }
        ]
      },
      en: {
        title: 'Growth Machine',
        description: 'A complete marketing system for growth, including SEO, content and performance marketing.',
        longDescription: 'The Growth Machine is a complete marketing system for entrepreneurs who want to achieve serious growth. We combine content, SEO, social media and paid advertising into an integrated system.',
        features: [
          'Content strategy and production',
          'SEO optimization for visibility',
          'Performance marketing on social media',
          'Monthly growth sessions',
          'Complete execution by our team',
          'Reporting and optimization'
        ],
        price: 'From €4,500/month',
        cta: 'Schedule a free intake call',
        secondaryCta: 'View results first',
        faqs: [
          {
            question: 'Is there a minimum contract period?',
            answer: 'Yes, we work with a minimum period of 3 months because real results take time. After that, the collaboration can be cancelled monthly.'
          },
          {
            question: 'Do I need to be available myself?',
            answer: 'We need minimal input - about 2 hours per month for alignment and feedback. We handle the rest.'
          },
          {
            question: 'What if I already have content?',
            answer: 'Perfect! We can optimize existing content and integrate it into the Growth Machine for even faster results.'
          }
        ]
      }
    },
    'volledig-uitbesteed': {
      nl: {
        title: 'Volledig Uitbesteed',
        description: 'Wij zijn jouw marketingafdeling. Complete uitvoering van strategie tot resultaten.',
        longDescription: 'Met Volledig Uitbesteed krijg je een compleet marketingteam tot je beschikking. We nemen alle marketing van je over, van strategie tot uitvoering, en zorgen voor voorspelbare klantengroei.',
        features: [
          'Dedicated marketeer voor jouw bedrijf',
          'Complete marketingstrategie',
          'Funnel implementatie en optimalisatie',
          'Content marketing en social media',
          'Wekelijkse rapportages en optimalisatie',
          'Toegang tot ons volledige team van specialisten'
        ],
        price: 'Vanaf €7.500/maand',
        cta: 'Plan een gratis intake gesprek',
        secondaryCta: 'Bekijk eerst resultaten',
        faqs: [
          {
            question: 'Wie wordt mijn marketeer?',
            answer: 'Je krijgt een ervaren marketeer toegewezen die perfect past bij jouw branche en doelen. Alle marketeers hebben minimaal 5 jaar ervaring.'
          },
          {
            question: 'Kan ik ook incidenteel hulp krijgen?',
            answer: 'Volledig Uitbesteed is een doorlopend partnerschap. Voor eenmalige projecten raden we onze Kickstart Funnel aan.'
          },
          {
            question: 'Hoe meet je resultaten?',
            answer: 'We stellen samen KPI\'s op en meten die wekelijks. Je krijgt toegang tot een dashboard met realtime inzicht in alle metrics.'
          }
        ]
      },
      en: {
        title: 'Fully Outsourced',
        description: 'We are your marketing department. Complete execution from strategy to results.',
        longDescription: 'With Fully Outsourced, you get a complete marketing team at your disposal. We take over all your marketing, from strategy to execution, and ensure predictable customer growth.',
        features: [
          'Dedicated marketer for your company',
          'Complete marketing strategy',
          'Funnel implementation and optimization',
          'Content marketing and social media',
          'Weekly reports and optimization',
          'Access to our full team of specialists'
        ],
        price: 'From €7,500/month',
        cta: 'Schedule a free intake call',
        secondaryCta: 'View results first',
        faqs: [
          {
            question: 'Who will be my marketer?',
            answer: 'You\'ll be assigned an experienced marketer who perfectly fits your industry and goals. All our marketers have at least 5 years of experience.'
          },
          {
            question: 'Can I also get incidental help?',
            answer: 'Fully Outsourced is an ongoing partnership. For one-time projects, we recommend our Kickstart Funnel.'
          },
          {
            question: 'How do you measure results?',
            answer: 'We set up KPIs together and measure them weekly. You get access to a dashboard with real-time insight into all metrics.'
          }
        ]
      }
    }
  };

  // Default to kickstart-funnel if no match found
  const currentService = services[serviceSlug as keyof typeof services] || services['kickstart-funnel'];
  const content = currentService[language];

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-28">
        {/* Hero Section */}
        <section className="py-12 md:py-20 bg-gray-light">
          <div className="container mx-auto">
            <div className="flex flex-col md:flex-row gap-12">
              <div className="md:w-1/2">
                <h1 className="text-primary-blue mb-4">{content.title}</h1>
                <p className="text-xl mb-6">{content.description}</p>
                <p className="mb-8">{content.longDescription}</p>
                
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button className="primary-cta">
                    {content.cta} <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                  <Button variant="outline" className="secondary-cta">
                    {content.secondaryCta}
                  </Button>
                </div>
              </div>
              
              <div className="md:w-1/2">
                <div className="bg-white p-6 rounded-xl shadow-md">
                  <h3 className="text-xl font-bold mb-6 text-primary-blue">{language === 'nl' ? 'Wat je krijgt:' : 'What you get:'}</h3>
                  <ul className="space-y-4">
                    {content.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check className="text-accent-orange mr-3 h-6 w-6 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-8 pt-6 border-t border-gray-medium">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-dark">{language === 'nl' ? 'Investering:' : 'Investment:'}</span>
                      <span className="text-xl font-bold text-primary-blue">{content.price}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* FAQ Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto">
            <h2 className="mb-10 text-center">{language === 'nl' ? 'Veelgestelde vragen' : 'Frequently Asked Questions'}</h2>
            <div className="max-w-3xl mx-auto">
              {content.faqs.map((faq, index) => (
                <div key={index} className="mb-6">
                  <h3 className="text-lg font-bold mb-2 text-primary-blue">{faq.question}</h3>
                  <p className="text-gray-dark">{faq.answer}</p>
                </div>
              ))}
            </div>
            
            <div className="text-center mt-12">
              <Button className="primary-cta">
                {content.cta} <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      <Footer language={language} />
      
      {/* Sticky CTA for mobile */}
      <div className="sticky-cta">
        <p className="text-primary-blue font-medium">
          {language === 'nl' ? 'Klaar voor meer klanten?' : 'Ready for more customers?'}
        </p>
        <Button size="sm" className="primary-cta">
          {language === 'nl' ? 'Gratis intake' : 'Free intake'}
        </Button>
      </div>
    </div>
  );
};

export default ServiceDetail;
