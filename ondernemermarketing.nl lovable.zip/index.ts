
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface ContactFormData {
  name: string;
  email: string;
  phone?: string;
  company?: string;
  message: string;
  formType: 'contact' | 'newsletter' | 'other';
  website?: string; // honeypot field
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const formData: ContactFormData = await req.json();
    
    // Check honeypot field - if filled, it's likely spam
    if (formData.website && formData.website.trim() !== '') {
      console.log('Spam detected via honeypot field');
      return new Response(
        JSON.stringify({ error: 'Submission blocked' }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Determine the contact list based on form type
    let listId;
    switch (formData.formType) {
      case 'contact':
        listId = 2;
        break;
      case 'newsletter':
        listId = 3;
        break;
      default:
        listId = 4; // 'all other'
    }

    const brevoApiKey = "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";

    // Add contact to Brevo list
    const contactResponse = await fetch('https://api.brevo.com/v3/contacts', {
      method: 'POST',
      headers: {
        'accept': 'application/json',
        'api-key': brevoApiKey,
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        email: formData.email,
        attributes: {
          FIRSTNAME: formData.name.split(' ')[0],
          LASTNAME: formData.name.split(' ').slice(1).join(' ') || '',
          SMS: formData.phone || '',
          COMPANY: formData.company || '',
        },
        listIds: [listId],
        updateEnabled: true,
      }),
    });

    // Send email notification
    const emailResponse = await fetch('https://api.brevo.com/v3/smtp/email', {
      method: 'POST',
      headers: {
        'accept': 'application/json',
        'api-key': brevoApiKey,
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        sender: {
          name: 'Ondernemer Marketing',
          email: 'info@ondernemermarketing.nl',
        },
        to: [
          {
            email: 'info@ondernemermarketing.nl',
            name: 'Ondernemer Marketing',
          },
        ],
        subject: `Nieuw ${formData.formType} formulier van ${formData.name}`,
        htmlContent: `
          <h2>Nieuw ${formData.formType} formulier</h2>
          <p><strong>Naam:</strong> ${formData.name}</p>
          <p><strong>Email:</strong> ${formData.email}</p>
          ${formData.phone ? `<p><strong>Telefoon:</strong> ${formData.phone}</p>` : ''}
          ${formData.company ? `<p><strong>Bedrijf:</strong> ${formData.company}</p>` : ''}
          ${formData.message ? `<p><strong>Bericht:</strong><br>${formData.message.replace(/\n/g, '<br>')}</p>` : ''}
        `,
      }),
    });

    if (!emailResponse.ok) {
      throw new Error(`Email API error: ${emailResponse.status}`);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Bericht succesvol verzonden!' 
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );

  } catch (error: any) {
    console.error("Error in send-brevo-email function:", error);
    return new Response(
      JSON.stringify({ 
        error: 'Er is iets misgegaan. Probeer het later opnieuw.' 
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
