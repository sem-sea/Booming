
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Calculator as CalculatorIcon, TrendingUp, DollarSign, Users, Target, ArrowRight } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { useLanguage } from '@/contexts/LanguageContext';
import { Link } from 'react-router-dom';

const Calculator = () => {
  const { language } = useLanguage();

  const [monthlyRevenue, setMonthlyRevenue] = useState<number>(10000);
  const [profitMargin, setProfitMargin] = useState<number>(20);
  const [customerAcquisitionCost, setCustomerAcquisitionCost] = useState<number>(500);
  const [newCustomersPerMonth, setNewCustomersPerMonth] = useState<number>(10);

  const calculateNetProfit = (): number => {
    return monthlyRevenue * (profitMargin / 100);
  };

  const calculateMarketingSpend = (): number => {
    return newCustomersPerMonth * customerAcquisitionCost;
  };

  const calculateReturnOnAdSpend = (): number => {
    const marketingSpend = calculateMarketingSpend();
    if (marketingSpend === 0) return 0;
    return monthlyRevenue / marketingSpend;
  };

  const calculateCustomerLifetimeValue = (): number => {
    const monthlyCustomerValue = monthlyRevenue / newCustomersPerMonth;
    const customerLifespanMonths = 12; // Assuming 1 year
    return monthlyCustomerValue * customerLifespanMonths;
  };

  const netProfit = calculateNetProfit();
  const marketingSpend = calculateMarketingSpend();
  const roas = calculateReturnOnAdSpend();
  const customerLifetimeValue = calculateCustomerLifetimeValue();

  const data = [
    { name: language === 'nl' ? 'Omzet' : 'Revenue', Euro: monthlyRevenue },
    { name: language === 'nl' ? 'Marketing Uitgaven' : 'Marketing Spend', Euro: marketingSpend },
    { name: language === 'nl' ? 'Netto Winst' : 'Net Profit', Euro: netProfit },
    { name: language === 'nl' ? 'Klantwaarde' : 'Customer Value', Euro: customerLifetimeValue },
  ];

  return (
    <div className="min-h-screen">
      <Header />

      <main className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <Card className="max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CalculatorIcon className="h-6 w-6" />
              {language === 'nl' ? 'Winstgroei Calculator' : 'Profit Growth Calculator'}
            </CardTitle>
          </CardHeader>
          <CardContent className="grid gap-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="monthlyRevenue">{language === 'nl' ? 'Maandelijkse Omzet (€)' : 'Monthly Revenue (€)'}</Label>
                <Input
                  type="number"
                  id="monthlyRevenue"
                  value={monthlyRevenue}
                  onChange={(e) => setMonthlyRevenue(Number(e.target.value))}
                />
              </div>
              <div>
                <Label htmlFor="profitMargin">{language === 'nl' ? 'Winstmarge (%)' : 'Profit Margin (%)'}</Label>
                <Input
                  type="number"
                  id="profitMargin"
                  value={profitMargin}
                  onChange={(e) => setProfitMargin(Number(e.target.value))}
                />
              </div>
              <div>
                <Label htmlFor="customerAcquisitionCost">{language === 'nl' ? 'Kosten per Klant (€)' : 'Cost per Customer (€)'}</Label>
                <Input
                  type="number"
                  id="customerAcquisitionCost"
                  value={customerAcquisitionCost}
                  onChange={(e) => setCustomerAcquisitionCost(Number(e.target.value))}
                />
              </div>
              <div>
                <Label htmlFor="newCustomersPerMonth">{language === 'nl' ? 'Nieuwe Klanten p/m' : 'New Customers p/m'}</Label>
                <Input
                  type="number"
                  id="newCustomersPerMonth"
                  value={newCustomersPerMonth}
                  onChange={(e) => setNewCustomersPerMonth(Number(e.target.value))}
                />
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4" />
                    {language === 'nl' ? 'Netto Winst' : 'Net Profit'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">€{netProfit.toFixed(2)}</div>
                  <p className="text-sm text-gray-500">
                    {language === 'nl' ? 'Maandelijkse netto winst na kosten.' : 'Monthly net profit after expenses.'}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4" />
                    {language === 'nl' ? 'Marketing Uitgaven' : 'Marketing Spend'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">€{marketingSpend.toFixed(2)}</div>
                  <p className="text-sm text-gray-500">
                    {language === 'nl' ? 'Totale marketing uitgaven per maand.' : 'Total marketing expenses per month.'}
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-4 w-4" />
                    ROAS (Return on Ad Spend)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{roas.toFixed(2)}x</div>
                  <p className="text-sm text-gray-500">
                    {language === 'nl' ? 'Opbrengst per euro besteed aan marketing.' : 'Return for every euro spent on marketing.'}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    {language === 'nl' ? 'Klantwaarde (CLV)' : 'Customer Lifetime Value (CLV)'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">€{customerLifetimeValue.toFixed(2)}</div>
                  <p className="text-sm text-gray-500">
                    {language === 'nl' ? 'Geschatte waarde van een klant gedurende de levensduur.' : 'Estimated value of a customer over their lifetime.'}
                  </p>
                </CardContent>
              </Card>
            </div>

            <Separator />

            <div>
              <h3 className="text-lg font-semibold mb-4">{language === 'nl' ? 'Gegevens Visualisatie' : 'Data Visualization'}</h3>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="Euro" fill="#3182CE" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <Separator />

            {/* CTA Section */}
            <div className="bg-gray-light rounded-xl p-8 text-center">
              <h3 className="text-xl font-bold mb-4 text-primary-blue">
                {language === 'nl' ? 'Klaar om je resultaten te verbeteren?' : 'Ready to improve your results?'}
              </h3>
              <p className="text-gray-dark mb-6">
                {language === 'nl' 
                  ? 'Ontdek hoe wij je marketing kunnen optimaliseren en je winstgroei kunnen versnellen.' 
                  : 'Discover how we can optimize your marketing and accelerate your profit growth.'}
              </p>
              <Button asChild className="primary-cta">
                <Link to="/contact">
                  {language === 'nl' ? 'Plan een gratis gesprek' : 'Schedule a free consultation'}
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>

      <Footer />
    </div>
  );
};

export default Calculator;
