
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const CompareServicesCTA = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-primary-blue to-primary-teal">
      <div className="container mx-auto">
        <div className="text-center text-white">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Welke marketingoplossing past bij jou?
          </h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto opacity-90">
            Van opstarten tot volledig uitbesteden - ontdek wat het beste bij jouw bedrijf past
          </p>
          
          <div className="flex flex-col md:flex-row items-center justify-center gap-8 mb-8">
            <div className="flex items-center">
              <CheckCircle className="h-6 w-6 mr-2 text-accent-orange" />
              <span>Kickstart Funnel vanaf €3.500</span>
            </div>
            <div className="flex items-center">
              <CheckCircle className="h-6 w-6 mr-2 text-accent-orange" />
              <span>Groei Machine vanaf €4.500/maand</span>
            </div>
            <div className="flex items-center">
              <CheckCircle className="h-6 w-6 mr-2 text-accent-orange" />
              <span>Volledig Uitbesteed vanaf €7.500/maand</span>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button asChild size="lg" className="bg-accent-orange hover:bg-orange-600 text-white border-none">
              <Link to="/aanbod/vergelijk">
                Vergelijk alle diensten <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="bg-transparent border-white text-white hover:bg-white hover:text-primary-blue">
              <Link to="/contact">
                Plan gratis intake
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CompareServicesCTA;
