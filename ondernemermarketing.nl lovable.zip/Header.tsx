
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Link } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { language, t } = useLanguage();
  
  const menuItems = [
    { label: 'Diensten', href: '/aanbod/vergelijk' },
    { label: 'Pakketten', href: '/pakketten' },
    { label: 'Tools', href: '/#tools' },
    { label: 'Over ons', href: '/over-ons' },
    { label: 'Contact', href: '/contact' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  return (
    <header 
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
        isScrolled 
          ? 'bg-white shadow-md py-3' 
          : 'bg-transparent py-5'
      )}
    >
      <div className="container mx-auto flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <img 
            src="/lovable-uploads/bf6accc4-838f-4f65-9b6a-1ef2f9fd9e46.png" 
            alt="Ondernemermarketing.nl Logo" 
            className="h-36 md:h-40"
          />
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          {menuItems.map((item) => (
            item.href.startsWith('#') || item.href.startsWith('/#') ? (
              <a 
                key={item.href} 
                href={item.href}
                className="text-gray-dark hover:text-primary-blue transition-colors font-medium"
              >
                {item.label}
              </a>
            ) : (
              <Link 
                key={item.href} 
                to={item.href}
                className="text-gray-dark hover:text-primary-blue transition-colors font-medium"
              >
                {item.label}
              </Link>
            )
          ))}
          <Button asChild className="primary-cta">
            <Link to="/contact">
              Plan gratis intake
            </Link>
          </Button>
        </nav>

        {/* Mobile Menu Button */}
        <div className="flex items-center md:hidden">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="ml-2"
          >
            {mobileMenuOpen ? <X /> : <Menu />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white">
          <div className="container py-4 flex flex-col space-y-4">
            {menuItems.map((item) => (
              item.href.startsWith('#') || item.href.startsWith('/#') ? (
                <a
                  key={item.href}
                  href={item.href}
                  className="text-gray-dark py-2 border-b border-gray-medium last:border-0"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.label}
                </a>
              ) : (
                <Link
                  key={item.href}
                  to={item.href}
                  className="text-gray-dark py-2 border-b border-gray-medium last:border-0"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.label}
                </Link>
              )
            ))}
            <Button asChild className="primary-cta w-full">
              <Link to="/contact">
                Plan gratis intake
              </Link>
            </Button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
