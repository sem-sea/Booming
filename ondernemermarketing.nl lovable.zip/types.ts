export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      ai_configurations: {
        Row: {
          configuration_name: string
          created_at: string
          created_by: string | null
          id: string
          is_active: boolean | null
          max_tokens: number | null
          model_name: string
          system_prompt: string
          temperature: number | null
          updated_at: string
        }
        Insert: {
          configuration_name: string
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean | null
          max_tokens?: number | null
          model_name?: string
          system_prompt: string
          temperature?: number | null
          updated_at?: string
        }
        Update: {
          configuration_name?: string
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean | null
          max_tokens?: number | null
          model_name?: string
          system_prompt?: string
          temperature?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      api_limits: {
        Row: {
          created_at: string
          daily_limit: number
          id: string
          monthly_limit: number
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          daily_limit?: number
          id?: string
          monthly_limit?: number
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          daily_limit?: number
          id?: string
          monthly_limit?: number
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      api_usage: {
        Row: {
          created_at: string
          function_name: string
          id: string
          request_count: number
          request_date: string
          tokens_used: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          function_name: string
          id?: string
          request_count?: number
          request_date?: string
          tokens_used?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          function_name?: string
          id?: string
          request_count?: number
          request_date?: string
          tokens_used?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      bid_writing_results: {
        Row: {
          ai_model_used: string | null
          created_at: string
          generated_content: string
          id: string
          improvement_suggestions: string[] | null
          quality_score: number | null
          section_type: string
          tender_id: string
          updated_at: string
          user_id: string | null
          word_count: number | null
        }
        Insert: {
          ai_model_used?: string | null
          created_at?: string
          generated_content: string
          id?: string
          improvement_suggestions?: string[] | null
          quality_score?: number | null
          section_type: string
          tender_id: string
          updated_at?: string
          user_id?: string | null
          word_count?: number | null
        }
        Update: {
          ai_model_used?: string | null
          created_at?: string
          generated_content?: string
          id?: string
          improvement_suggestions?: string[] | null
          quality_score?: number | null
          section_type?: string
          tender_id?: string
          updated_at?: string
          user_id?: string | null
          word_count?: number | null
        }
        Relationships: []
      }
      compliance_matrix: {
        Row: {
          action_required: string | null
          compliance_score: number | null
          created_at: string
          deadline: string | null
          id: string
          missing_documents: string[] | null
          requirement_id: string | null
          responsible_person: string | null
          status: string | null
          tender_id: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          action_required?: string | null
          compliance_score?: number | null
          created_at?: string
          deadline?: string | null
          id?: string
          missing_documents?: string[] | null
          requirement_id?: string | null
          responsible_person?: string | null
          status?: string | null
          tender_id: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          action_required?: string | null
          compliance_score?: number | null
          created_at?: string
          deadline?: string | null
          id?: string
          missing_documents?: string[] | null
          requirement_id?: string | null
          responsible_person?: string | null
          status?: string | null
          tender_id?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "compliance_matrix_requirement_id_fkey"
            columns: ["requirement_id"]
            isOneToOne: false
            referencedRelation: "tender_requirements"
            referencedColumns: ["id"]
          },
        ]
      }
      document_analysis_results: {
        Row: {
          ai_model_used: string | null
          analysis_results: Json
          analysis_type: string
          confidence_score: number | null
          created_at: string
          id: string
          input_document_url: string | null
          processing_time_ms: number | null
          tender_id: string
          user_id: string | null
        }
        Insert: {
          ai_model_used?: string | null
          analysis_results: Json
          analysis_type: string
          confidence_score?: number | null
          created_at?: string
          id?: string
          input_document_url?: string | null
          processing_time_ms?: number | null
          tender_id: string
          user_id?: string | null
        }
        Update: {
          ai_model_used?: string | null
          analysis_results?: Json
          analysis_type?: string
          confidence_score?: number | null
          created_at?: string
          id?: string
          input_document_url?: string | null
          processing_time_ms?: number | null
          tender_id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      document_prompts: {
        Row: {
          created_at: string
          document_type: string
          id: string
          prompt_text: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          document_type: string
          id?: string
          prompt_text: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          document_type?: string
          id?: string
          prompt_text?: string
          updated_at?: string
        }
        Relationships: []
      }
      emvi_calculations: {
        Row: {
          ai_model_used: string | null
          competitor_benchmarks: Json
          created_at: string
          criteria_scores: Json
          id: string
          max_possible_score: number | null
          optimization_suggestions: string[] | null
          tender_id: string
          total_score: number | null
          updated_at: string
          user_id: string | null
          win_probability: number | null
        }
        Insert: {
          ai_model_used?: string | null
          competitor_benchmarks?: Json
          created_at?: string
          criteria_scores?: Json
          id?: string
          max_possible_score?: number | null
          optimization_suggestions?: string[] | null
          tender_id: string
          total_score?: number | null
          updated_at?: string
          user_id?: string | null
          win_probability?: number | null
        }
        Update: {
          ai_model_used?: string | null
          competitor_benchmarks?: Json
          created_at?: string
          criteria_scores?: Json
          id?: string
          max_possible_score?: number | null
          optimization_suggestions?: string[] | null
          tender_id?: string
          total_score?: number | null
          updated_at?: string
          user_id?: string | null
          win_probability?: number | null
        }
        Relationships: []
      }
      emvi_scoring: {
        Row: {
          benchmark_score: number | null
          created_at: string
          criterion_name: string
          criterion_weight: number
          id: string
          improvement_suggestions: string[] | null
          max_possible_score: number | null
          optimization_priority: string | null
          our_score: number | null
          risk_assessment: string | null
          tender_id: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          benchmark_score?: number | null
          created_at?: string
          criterion_name: string
          criterion_weight: number
          id?: string
          improvement_suggestions?: string[] | null
          max_possible_score?: number | null
          optimization_priority?: string | null
          our_score?: number | null
          risk_assessment?: string | null
          tender_id: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          benchmark_score?: number | null
          created_at?: string
          criterion_name?: string
          criterion_weight?: number
          id?: string
          improvement_suggestions?: string[] | null
          max_possible_score?: number | null
          optimization_priority?: string | null
          our_score?: number | null
          risk_assessment?: string | null
          tender_id?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      generated_documents: {
        Row: {
          content: string
          created_at: string
          document_type: string
          id: string
          tender_id: string
          user_id: string | null
        }
        Insert: {
          content: string
          created_at?: string
          document_type: string
          id?: string
          tender_id: string
          user_id?: string | null
        }
        Update: {
          content?: string
          created_at?: string
          document_type?: string
          id?: string
          tender_id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      market_intelligence: {
        Row: {
          ai_model_used: string | null
          competitor_analysis: Json
          created_at: string
          id: string
          market_trends: string[] | null
          pricing_insights: Json
          recommendation_score: number | null
          risk_assessment: string | null
          success_factors: string[] | null
          tender_id: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          ai_model_used?: string | null
          competitor_analysis?: Json
          created_at?: string
          id?: string
          market_trends?: string[] | null
          pricing_insights?: Json
          recommendation_score?: number | null
          risk_assessment?: string | null
          success_factors?: string[] | null
          tender_id: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          ai_model_used?: string | null
          competitor_analysis?: Json
          created_at?: string
          id?: string
          market_trends?: string[] | null
          pricing_insights?: Json
          recommendation_score?: number | null
          risk_assessment?: string | null
          success_factors?: string[] | null
          tender_id?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      monitored_tenders: {
        Row: {
          buyer: string
          category: string | null
          deadline: string | null
          description_short: string | null
          discovered_at: string
          estimated_value: string | null
          id: string
          is_relevant: boolean | null
          location: string | null
          monitoring_alert_id: string | null
          publication_date: string | null
          relevance_score: number | null
          source_url: string | null
          tender_id: string
          title: string
        }
        Insert: {
          buyer: string
          category?: string | null
          deadline?: string | null
          description_short?: string | null
          discovered_at?: string
          estimated_value?: string | null
          id?: string
          is_relevant?: boolean | null
          location?: string | null
          monitoring_alert_id?: string | null
          publication_date?: string | null
          relevance_score?: number | null
          source_url?: string | null
          tender_id: string
          title: string
        }
        Update: {
          buyer?: string
          category?: string | null
          deadline?: string | null
          description_short?: string | null
          discovered_at?: string
          estimated_value?: string | null
          id?: string
          is_relevant?: boolean | null
          location?: string | null
          monitoring_alert_id?: string | null
          publication_date?: string | null
          relevance_score?: number | null
          source_url?: string | null
          tender_id?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "monitored_tenders_monitoring_alert_id_fkey"
            columns: ["monitoring_alert_id"]
            isOneToOne: false
            referencedRelation: "tender_monitoring"
            referencedColumns: ["id"]
          },
        ]
      }
      performance_metrics: {
        Row: {
          average_bid_amount: number | null
          average_hours_per_tender: number | null
          calculated_at: string
          id: string
          most_successful_category: string | null
          period_end: string
          period_start: string
          top_performing_team_member: string | null
          total_losses: number | null
          total_revenue: number | null
          total_submissions: number | null
          total_wins: number | null
          win_rate: number | null
        }
        Insert: {
          average_bid_amount?: number | null
          average_hours_per_tender?: number | null
          calculated_at?: string
          id?: string
          most_successful_category?: string | null
          period_end: string
          period_start: string
          top_performing_team_member?: string | null
          total_losses?: number | null
          total_revenue?: number | null
          total_submissions?: number | null
          total_wins?: number | null
          win_rate?: number | null
        }
        Update: {
          average_bid_amount?: number | null
          average_hours_per_tender?: number | null
          calculated_at?: string
          id?: string
          most_successful_category?: string | null
          period_end?: string
          period_start?: string
          top_performing_team_member?: string | null
          total_losses?: number | null
          total_revenue?: number | null
          total_submissions?: number | null
          total_wins?: number | null
          win_rate?: number | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          company_name: string | null
          company_type: string | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          onboarding_completed: boolean | null
          phone: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          company_name?: string | null
          company_type?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          onboarding_completed?: boolean | null
          phone?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          company_name?: string | null
          company_type?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          onboarding_completed?: boolean | null
          phone?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      quality_assessments: {
        Row: {
          assessed_at: string
          document_content: string
          document_type: string
          feedback: Json
          id: string
          quality_score: number
          suggestions: string[] | null
          user_id: string | null
        }
        Insert: {
          assessed_at?: string
          document_content: string
          document_type: string
          feedback: Json
          id?: string
          quality_score: number
          suggestions?: string[] | null
          user_id?: string | null
        }
        Update: {
          assessed_at?: string
          document_content?: string
          document_type?: string
          feedback?: Json
          id?: string
          quality_score?: number
          suggestions?: string[] | null
          user_id?: string | null
        }
        Relationships: []
      }
      response_drafts: {
        Row: {
          content: string
          created_at: string
          id: string
          quality_score: number | null
          section_type: string
          tender_id: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          quality_score?: number | null
          section_type: string
          tender_id: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          quality_score?: number | null
          section_type?: string
          tender_id?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      tender_alerts: {
        Row: {
          alert_name: string
          created_at: string
          id: string
          is_active: boolean
          last_check: string | null
          search_criteria: Json
        }
        Insert: {
          alert_name: string
          created_at?: string
          id?: string
          is_active?: boolean
          last_check?: string | null
          search_criteria: Json
        }
        Update: {
          alert_name?: string
          created_at?: string
          id?: string
          is_active?: boolean
          last_check?: string | null
          search_criteria?: Json
        }
        Relationships: []
      }
      tender_analysis: {
        Row: {
          analysis_date: string
          compliance_check: Json | null
          created_at: string
          extracted_requirements: Json | null
          id: string
          pdf_url: string | null
          recommendations: string[] | null
          risk_assessment: Json | null
          tender_id: string
          title: string
          updated_at: string
          user_id: string | null
          win_probability: number | null
        }
        Insert: {
          analysis_date?: string
          compliance_check?: Json | null
          created_at?: string
          extracted_requirements?: Json | null
          id?: string
          pdf_url?: string | null
          recommendations?: string[] | null
          risk_assessment?: Json | null
          tender_id: string
          title: string
          updated_at?: string
          user_id?: string | null
          win_probability?: number | null
        }
        Update: {
          analysis_date?: string
          compliance_check?: Json | null
          created_at?: string
          extracted_requirements?: Json | null
          id?: string
          pdf_url?: string | null
          recommendations?: string[] | null
          risk_assessment?: Json | null
          tender_id?: string
          title?: string
          updated_at?: string
          user_id?: string | null
          win_probability?: number | null
        }
        Relationships: []
      }
      tender_monitoring: {
        Row: {
          alert_name: string
          categories: string[] | null
          created_at: string
          email_recipients: string[] | null
          id: string
          is_active: boolean
          keywords: string[] | null
          last_scan: string | null
          regions: string[] | null
          scan_frequency: string
          search_query: string
          updated_at: string
        }
        Insert: {
          alert_name: string
          categories?: string[] | null
          created_at?: string
          email_recipients?: string[] | null
          id?: string
          is_active?: boolean
          keywords?: string[] | null
          last_scan?: string | null
          regions?: string[] | null
          scan_frequency?: string
          search_query: string
          updated_at?: string
        }
        Update: {
          alert_name?: string
          categories?: string[] | null
          created_at?: string
          email_recipients?: string[] | null
          id?: string
          is_active?: boolean
          keywords?: string[] | null
          last_scan?: string | null
          regions?: string[] | null
          scan_frequency?: string
          search_query?: string
          updated_at?: string
        }
        Relationships: []
      }
      tender_performance: {
        Row: {
          actual_result: string | null
          buyer: string
          created_at: string
          deadline: string | null
          documents_generated: string[] | null
          estimated_value: number | null
          feedback_received: string | null
          hours_spent: number | null
          id: string
          lessons_learned: string[] | null
          our_bid_amount: number | null
          status: string
          submission_date: string | null
          team_members: string[] | null
          tender_id: string
          tender_title: string
          updated_at: string
          user_id: string | null
          win_probability_predicted: number | null
        }
        Insert: {
          actual_result?: string | null
          buyer: string
          created_at?: string
          deadline?: string | null
          documents_generated?: string[] | null
          estimated_value?: number | null
          feedback_received?: string | null
          hours_spent?: number | null
          id?: string
          lessons_learned?: string[] | null
          our_bid_amount?: number | null
          status: string
          submission_date?: string | null
          team_members?: string[] | null
          tender_id: string
          tender_title: string
          updated_at?: string
          user_id?: string | null
          win_probability_predicted?: number | null
        }
        Update: {
          actual_result?: string | null
          buyer?: string
          created_at?: string
          deadline?: string | null
          documents_generated?: string[] | null
          estimated_value?: number | null
          feedback_received?: string | null
          hours_spent?: number | null
          id?: string
          lessons_learned?: string[] | null
          our_bid_amount?: number | null
          status?: string
          submission_date?: string | null
          team_members?: string[] | null
          tender_id?: string
          tender_title?: string
          updated_at?: string
          user_id?: string | null
          win_probability_predicted?: number | null
        }
        Relationships: []
      }
      tender_requirements: {
        Row: {
          compliance_status: string | null
          created_at: string
          evidence_documents: string[] | null
          id: string
          our_response: string | null
          requirement_text: string
          requirement_type: string
          risk_level: string | null
          tender_id: string
          updated_at: string
          user_id: string | null
          weight_percentage: number | null
        }
        Insert: {
          compliance_status?: string | null
          created_at?: string
          evidence_documents?: string[] | null
          id?: string
          our_response?: string | null
          requirement_text: string
          requirement_type: string
          risk_level?: string | null
          tender_id: string
          updated_at?: string
          user_id?: string | null
          weight_percentage?: number | null
        }
        Update: {
          compliance_status?: string | null
          created_at?: string
          evidence_documents?: string[] | null
          id?: string
          our_response?: string | null
          requirement_text?: string
          requirement_type?: string
          risk_level?: string | null
          tender_id?: string
          updated_at?: string
          user_id?: string | null
          weight_percentage?: number | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_workflows: {
        Row: {
          completed_at: string | null
          completed_steps: number[] | null
          current_step: number | null
          id: string
          started_at: string
          tender_id: string
          updated_at: string
          user_id: string
          workflow_data: Json | null
        }
        Insert: {
          completed_at?: string | null
          completed_steps?: number[] | null
          current_step?: number | null
          id?: string
          started_at?: string
          tender_id: string
          updated_at?: string
          user_id: string
          workflow_data?: Json | null
        }
        Update: {
          completed_at?: string | null
          completed_steps?: number[] | null
          current_step?: number | null
          id?: string
          started_at?: string
          tender_id?: string
          updated_at?: string
          user_id?: string
          workflow_data?: Json | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      calculate_performance_metrics: {
        Args: { end_date?: string; start_date?: string }
        Returns: {
          avg_bid_amount: number
          avg_hours: number
          total_losses: number
          total_revenue: number
          total_submissions: number
          total_wins: number
          win_rate: number
        }[]
      }
      check_api_limits: {
        Args: { _function_name: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: {
        Args: { _user_id: string }
        Returns: boolean
      }
      track_api_usage: {
        Args: {
          _function_name: string
          _tokens_used?: number
          _user_id: string
        }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
