
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import Cookies from 'js-cookie';
import { Link } from 'react-router-dom';

const CookieConsent = () => {
  const [showBanner, setShowBanner] = useState(false);
  const { language } = useLanguage();

  useEffect(() => {
    const consent = Cookies.get('cookie-consent');
    if (!consent) {
      setShowBanner(true);
    }
  }, []);

  const acceptCookies = () => {
    Cookies.set('cookie-consent', 'accepted', { expires: 365 });
    setShowBanner(false);
  };

  const rejectCookies = () => {
    Cookies.set('cookie-consent', 'rejected', { expires: 365 });
    setShowBanner(false);
  };

  if (!showBanner) return null;

  const content = {
    nl: {
      title: 'Deze website gebruikt cookies',
      text: 'Wij gebruiken cookies om uw ervaring te verbeteren en voor analytische doeleinden. Door verder te gaan, gaat u akkoord met ons',
      accept: 'Alles accepteren',
      reject: 'Alleen noodzakelijke',
      privacy: 'cookiebeleid',
      settings: 'Instellingen'
    },
    en: {
      title: 'This website uses cookies',
      text: 'We use cookies to improve your experience and for analytical purposes. By continuing, you agree to our',
      accept: 'Accept all',
      reject: 'Essential only',
      privacy: 'cookie policy',
      settings: 'Settings'
    }
  };

  const { title, text, accept, reject, privacy } = content[language];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t-2 border-gray-200 shadow-lg p-4 md:p-6">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex-1">
            <h3 className="font-bold text-lg mb-2">{title}</h3>
            <p className="text-gray-600 text-sm md:text-base">
              {text}{' '}
              <Link to="/privacy-policy" className="text-primary-blue hover:underline">
                {privacy}
              </Link>
              .
            </p>
          </div>
          <div className="flex gap-3 flex-shrink-0">
            <Button
              onClick={rejectCookies}
              variant="outline"
              size="sm"
              className="border-gray-300"
            >
              {reject}
            </Button>
            <Button
              onClick={acceptCookies}
              size="sm"
              className="primary-cta"
            >
              {accept}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CookieConsent;
