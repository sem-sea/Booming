
import React from 'react';
import { Helmet } from 'react-helmet-async';

interface SEOProps {
  title?: string;
  description?: string;
  image?: string;
  url?: string;
  type?: string;
  structuredData?: object;
  noindex?: boolean;
}

const SEO = ({ 
  title = "Ondernemermarketing.nl – Marketing zonder gedoe",
  description = "Je wilt klanten. Niet leren marketen. Ondernemermarketing.nl regelt je funnels, e-mails en intakeflow – zodat jij kunt ondernemen.",
  image = "https://ondernemermarketing.nl/lovable-uploads/57623f4c-b048-4084-ab9b-a2c896628472.png",
  url = "https://www.ondernemermarketing.nl",
  type = "website",
  structuredData,
  noindex = false
}: SEOProps) => {
  return (
    <Helmet>
      <title>{title}</title>
      <meta name="description" content={description} />
      <meta name="robots" content={noindex ? "noindex,nofollow" : "index,follow"} />
      <link rel="canonical" href={url} />
      
      {/* Open Graph */}
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={image} />
      <meta property="og:url" content={url} />
      <meta property="og:type" content={type} />
      <meta property="og:site_name" content="Ondernemermarketing.nl" />
      
      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={image} />
      
      {/* Additional SEO tags */}
      <meta name="author" content="Ondernemermarketing.nl" />
      <meta name="language" content="nl" />
      <meta name="geo.region" content="NL" />
      <meta name="geo.country" content="Netherlands" />
      
      {structuredData && (
        <script type="application/ld+json">
          {JSON.stringify(structuredData)}
        </script>
      )}
    </Helmet>
  );
};

export default SEO;
