<?php return [ 'dependencies' => [], 'version' => '1.0.0' ];
